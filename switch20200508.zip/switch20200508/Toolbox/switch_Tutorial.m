%==========================================================================
% Function : switch_Experiment
%==========================================================================

function [Passation,errormsg] = switch_Tutorial(participant)

% Initialisation of Passation
%==========================================================================
% Definition of Passation DEBUG, Running, TaskParameters, Runner,
% Participant, DataFolder, Filename
%--------------------------------------------------------------------------
global DEBUG                               % Define DEBUG as a global variable
Passation=[];                              % Define Passation
errormsg =[];                              % Define errormsg
Passation.DEBUG = DEBUG;                   % Define Passation.DEBUG
Passation.Running = dbstack;               % File information (file:Name.m ; name:Name ; line:999)
for i=1:length(Passation.Running)
    Passation.Running(i).fullpath = which(Passation.Running(i).file); % File location (C:\Users\Name\Documents\File.m)
    Passation.Running(i).filedate = getfield(dir(Passation.Running(i).fullpath),'date'); % Saving date (16-oct.-2018 15:07:49)
    Passation.Running(i).mcode    = ...    % Copy all the actual script
        textread(Passation.Running(i).fullpath,'%s','delimiter','\n');           
end
run('switch_TaskParameters');             % Define various parameters
Passation.TaskParameters = ...             % Copy all the TaskParameter script
    textread(which('switch_TaskParameters'),'%s','delimiter','\n');
Passation.Runner = ...                     % Copy all the Runner script
    textread(which('switch_Runner'),'%s','delimiter','\n');
Passation.Participant = participant;
Passation.DataFolder = fullfile(participant.folder,'Data',participant.identifier);
if not(exist(Passation.DataFolder, 'dir')) % Saving data folder exist or not
    if DEBUG
        Passation.DataFolder = fullfile(fileparts(tempname)); % DEBUG => Save in temporary folder
    else
        error('switch:MssingDataFolder','Missing data folder! %s\n', Passation.DataFolder);
    end
end
Passation.Filename=fullfile(...            % Define the filename to save the info
    Passation.DataFolder,sprintf('switch_%s_%s',... % like 
    datestr(now,'yyyymmdd-HHMM'),...       % Datafolder\switch_20181017-1038_lfp
    participant.session));
stopped = false;

% Save Diary (in ...\switch\data\TEST\switch_20181017-1038_lfp)
%==========================================================================
diary(Passation.Filename) % DIARY ON = begining of saving
fprintf('\n'); 
fprintf('=======================================\n');
fprintf('======= START OF THE TUTORIAL =========\n');
fprintf('=======================================\n');
fprintf('\n');
trig.start=52; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS

% Initialisation of Psychtoolbox
%==========================================================================
% Open the Psychtoolbox and display various general information about the
% experiment (participant, exp. condition, keyboard inputs)
%--------------------------------------------------------------------------
if participant.flags.with_fullscreen
    video = OpenPTBScreen([]);             % Screen Definition
else
    video = OpenPTBScreen;
end                                        
if DEBUG                                   % #03 DEBUG mode display and wait for keyboard input
    DrawFormattedText(video.h, 'DEBUG MODE', 'center', 'center', 1); Screen('Flip', video.h); KbStrokeWait;
end
if ~DEBUG         % Remove keyboard outputs to matlab screen: REMOVED BY JB TO DEBUG...
    HideCursor;    % Hide the mouse cursor
    FlushEvents;   % Remove events from the system even queue
    ListenChar(2); % 2 = listen to keyboard input and supress any output of keypresses
end

%==========================================================================
% Important section: defines the structures within and between blocs of
% trials. Store information in Passation.Data=Data;
%--------------------------------------------------------------------------

% Stimuli defintion
%==========================================================================
% STEP 1 : 20 pixel white fixation dot at screen center
% STEP 2 : rule or pre-cue display
%    2.1 : pre-cue (stim type) trials = first display peripheric pre-cues
%          and then the central rule
%    2.2 : pre-cue (rule type) trials = first display central rule and then
%          peripheric pre-cues (see the papers of Buchman and Miller in
%          Neuron)
% STEP 3 : 3 squares (stim+rule)
%--------------------------------------------------------------------------
% #1
fix_dot_Xpos = video.xCenter;                             % Center X position in pixels
fix_dot_Ypos = video.yCenter;                             % Center Y position in pixels

% #2.1
baseRect = [0 0 cue_size cue_size];                       % Rect dimension of 50 by 50 pixels
pre_cue_Xpos_tmp = [video.x*0.4, video.x*0.6];          % Screen X positions of the two pre-cue rectangles  % Adjust x coordinates of both pre-cues
pre_cue_Xpos_stim = nan(4, length(pre_cue_Xpos_tmp));     % Create a matrix for all the squares (4,:)
for i = 1:length(pre_cue_Xpos_tmp)                        % that contains (xmin,ymin,xmax,ymax) of each square
    pre_cue_Xpos_stim(:, i) = CenterRectOnPointd(baseRect, pre_cue_Xpos_tmp(i), video.yCenter); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues
pre_cue_colors(:,:,1)=[1 0 1; 1 1 0]';                    % magenta left; yellow right
pre_cue_colors(:,:,2)=[1 1 0;1 0 1 ]';                    % yellow left ; magenta right

% #2.2
pre_cue_Xpos_rule = CenterRectOnPointd(baseRect, video.x*0.5, video.yCenter);%
pre_cue_rule_color=[1 0 1; 1 1 0]';                       % first colomn= rule= magenta; second= yellow

% #3
cue_Xpos_tmp = [video.x*0.4, video.x*0.5, video.x*0.6]; % Screen X positions of our three rectangles
cue_Xpos = nan(4, length(cue_Xpos_tmp));                  % Create a matrix for all the squares (4,:)
for i = 1:length(cue_Xpos_tmp)                            % that contains (xmin,ymin,xmax,ymax) of each square
    cue_Xpos(:, i) = CenterRectOnPointd(baseRect, cue_Xpos_tmp(i), video.yCenter); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues (dirty code...)
cue_colors(:,:,1)=[1 0 1;1 0 1; 1 1 0]';                  % magenta left; yellow right; rule = magenta
cue_colors(:,:,2)=[1 0 1;1 1 0; 1 1 0]';                  % magenta left; yellow right; rule = yellow
cue_colors(:,:,3)=[1 1 0;1 0 1; 1 0 1]';                  % yellow left ; magenta right; rule = magenta
cue_colors(:,:,4)=[1 1 0;1 1 0; 1 0 1]';                  % yellow left ; magenta right; rule = yellow
% % %        cue_colors choice depends on both cue and side codes: is between 1 and 4
% % %        cue_color code=1 or 2 si rule = 0 par exemple mais = 3 ou 4 si on multiplie side par rule

% Initialisation port audio
%==========================================================================
InitializePsychSound(1)                 % Initialize Sounddriver
Snd_channel = 2;                       % Number of channels
Snd_freq = 48000;                       % Frequency of the sound
pahandle = PsychPortAudio('Open', [], 1, 1, Snd_freq, Snd_channel);
PsychPortAudio('Volume', pahandle, 0.5); % Set the volume
    
% #01 Display and wait for keyboard input
DrawFormattedText(video.h, 'DEBUT DU TUTORIEL', 'center', video.y*0.4, 1); 
DrawFormattedText(video.h, 'Appuyez sur ENTREE pour continuer', 'center', video.y*0.9, 0.5); 
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]);

% #02
draw_tuto(video,0);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]);

% DEROULEMENT ============================================================%

% #01 FIX POINTS ---------------------------------------------------------%
draw_tuto(video,1);
DrawFormattedText(video.h, 'Trois points blancs s''affichent � l''�cran.', 'center', video.y*0.2, 1); 
Screen('DrawDots', video.h, ...
        [fix_dot_Xpos fix_dot_Ypos], fix_dot_SizePix,...
        fix_dot_Color, [0 0], 2);
Screen('DrawDots', video.h, ...
        [pre_cue_Xpos_tmp ; fix_dot_Ypos fix_dot_Ypos],...
        [fix_dot_SizePix fix_dot_SizePix], ...
        [fix_dot_Color'  fix_dot_Color'], [0 0], 2);  
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
% #02 PRE CUE ------------------------------------------------------------%
draw_tuto(video,1);
stim_rule_type=1; % 1=rule after ; 2=rule before
side=1;           % 1=left ; 2=right
rule=1;           % 1= ; 2=
trig.fix =0;
DrawFormattedText(video.h, 'Deux carr�s color�s prennent leurs places...', 'center', video.y*0.2, 1);
draw_precue(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,...
    fix_dot_SizePix,fix_dot_Color,pre_cue_colors,side,...
    pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Xpos_rule,rule,trig.fix); 
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
% #03 CUE ----------------------------------------------------------------%
draw_tuto(video,1);
DrawFormattedText(video.h, '...puis le carr� central appara�t.', 'center', video.y*0.2, 1);
draw_cue(video,rule,cue_colors,side,cue_Xpos);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
% #04 ANSWER -------------------------------------------------------------%
draw_tuto(video,1);
DrawFormattedText(video.h, 'De quel c�t� est le carr� de la m�me couleur que le carr� central ?', 'center', video.y*0.15, 1);
DrawFormattedText(video.h, 'R�pondez avec la main qui correspond.', 'center', video.y*0.2, 1);
DrawFormattedText(video.h, 'Lettre <q> main gauche - - - lettre <m> main droite', 'center', video.y*0.25, 0.5);
draw_cue(video,rule,cue_colors,side,cue_Xpos);
Screen('Flip', video.h); WaitKeyPress();
% #05 CORRECTION ---------------------------------------------------------%
draw_tuto(video,1);
DrawFormattedText(video.h, 'La r�ponse attendue est :', 'center', video.y*0.2, 1);
DrawFormattedText(video.h, '(main gauche)', 'center', video.y*0.25, 1);
draw_cue(video,rule,cue_colors,side,cue_Xpos);
Screen('DrawArc',video.h,[0 1 0],[video.x*0.4-50 video.yCenter-50 video.x*0.4+50 video.yCenter+50],0,360);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 

% OBJECTIFS ==============================================================%
draw_tuto(video,2);
DrawFormattedText(video.h, 'L''objectif est simple :', 'center', video.y*0.25, 1); 
DrawFormattedText(video.h, 'Il faut rapidement rep�rer quel carr� est ', 'center',  video.y*0.35, 1); 
DrawFormattedText(video.h, 'de la m�me couleur que le carr� central. ', 'center',  video.y*0.4, 1); 
DrawFormattedText(video.h, 'Attention, vous devrez �tre tr�s rapide ', 'center',  video.y*0.5, 1);
DrawFormattedText(video.h, 'pour marquer un maximum de points !', 'center',  video.y*0.55, 1);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 

% ASTUCES ================================================================%
draw_tuto(video,3);
DrawFormattedText(video.h, 'ASTUCES POUR �TRE RAPIDE', video.x*0.3, video.y*0.15, 1);
DrawFormattedText(video.h, 'Astuce 1 : La couleur � choisir se r�p�te !', video.x*0.3, video.y*0.25, 1);
Screen('Flip', video.h); WaitKeyPress();
% Rose gauche
draw_tuto(video,3);
DrawFormattedText(video.h, 'ASTUCES POUR �TRE RAPIDE', video.x*0.3, video.y*0.15, 1);
DrawFormattedText(video.h, 'Astuce 1 : La couleur � choisir se r�p�te !', video.x*0.3, video.y*0.25, 1);
side=1; rule=1; 
draw_cue(video,rule,cue_colors,side,cue_Xpos);
Screen('DrawArc',video.h,[0 1 0],[video.x*0.4-50 video.yCenter-50 video.x*0.4+50 video.yCenter+50],0,360);
Rect = CenterRectOnPointd([0 0 800 500], video.xCenter, video.yCenter);
Screen('FrameRect', video.h, 0.5, Rect, 2);
Screen('Flip', video.h); WaitKeyPress();
% Rose droite
draw_tuto(video,3);
DrawFormattedText(video.h, 'ASTUCES POUR �TRE RAPIDE', video.x*0.3, video.y*0.15, 1);
DrawFormattedText(video.h, 'Astuce 1 : La couleur � choisir se r�p�te.', video.x*0.3, video.y*0.25, 1);
side=2; rule=1; 
draw_cue(video,rule,cue_colors,side,cue_Xpos);
Screen('DrawArc',video.h,[0 1 0],[video.x*0.6-50 video.yCenter-50 video.x*0.6+50 video.yCenter+50],0,360);
Rect = CenterRectOnPointd([0 0 800 500], video.xCenter, video.yCenter);
Screen('FrameRect', video.h, 0.5, Rect, 2);
Screen('Flip', video.h); WaitKeyPress();
% Rose gauche
draw_tuto(video,3);
DrawFormattedText(video.h, 'ASTUCES POUR �TRE RAPIDE', video.x*0.3, video.y*0.15, 1);
DrawFormattedText(video.h, 'Astuce 1 : La couleur � choisir se r�p�te.', video.x*0.3, video.y*0.25, 1);
side=1; rule=1; 
draw_cue(video,rule,cue_colors,side,cue_Xpos);
Screen('DrawArc',video.h,[0 1 0],[video.x*0.4-50 video.yCenter-50 video.x*0.4+50 video.yCenter+50],0,360);
Rect = CenterRectOnPointd([0 0 800 500], video.xCenter, video.yCenter);
Screen('FrameRect', video.h, 0.5, Rect, 2);
Screen('Flip', video.h); WaitKeyPress();
% Rose droite
draw_tuto(video,3);
DrawFormattedText(video.h, 'ASTUCES POUR �TRE RAPIDE', video.x*0.3, video.y*0.15, 1);
DrawFormattedText(video.h, 'Astuce 1 : La couleur � choisir se r�p�te.', video.x*0.3, video.y*0.25, 1);
side=2; rule=1; 
draw_cue(video,rule,cue_colors,side,cue_Xpos);
Screen('DrawArc',video.h,[0 1 0],[video.x*0.6-50 video.yCenter-50 video.x*0.6+50 video.yCenter+50],0,360);
Rect = CenterRectOnPointd([0 0 800 500], video.xCenter, video.yCenter);
Screen('FrameRect', video.h, 0.5, Rect, 2);
Screen('Flip', video.h); WaitKeyPress();
% ASTUCE 2
draw_tuto(video,3);
DrawFormattedText(video.h, 'ASTUCES POUR �TRE RAPIDE', video.x*0.3, video.y*0.15, 1);
DrawFormattedText(video.h, 'Astuce 1 : La couleur � choisir se r�p�te.', video.x*0.3, video.y*0.25, 1);
DrawFormattedText(video.h, 'Donc, il est possible de pr�parer sa r�ponse.', video.x*0.38, video.y*0.3, 1);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
% ASTUCE 3
draw_tuto(video,3);
DrawFormattedText(video.h, 'ASTUCES POUR �TRE RAPIDE', video.x*0.3, video.y*0.15, 1);
DrawFormattedText(video.h, 'Astuce 1 : La couleur � choisir se r�p�te.', video.x*0.3, video.y*0.25, 1);
DrawFormattedText(video.h, 'Donc, il est possible de pr�parer sa r�ponse.', video.x*0.38, video.y*0.3, 1);
DrawFormattedText(video.h, 'Astuce 2 : Si vous �tes "trop lent", vous entendrez ce son : ', video.x*0.3, video.y*0.45, 1);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
Sound_Bad(0,pahandle); key = WaitKeyPress([keyconfirm keystop]); 
% ASTUCE 4
draw_tuto(video,3);
DrawFormattedText(video.h, 'ASTUCES POUR �TRE RAPIDE', video.x*0.3, video.y*0.15, 1);
DrawFormattedText(video.h, 'Astuce 1 : La couleur � choisir se r�p�te.', video.x*0.3, video.y*0.25, 1);
DrawFormattedText(video.h, 'Donc, il est possible de pr�parer sa r�ponse.', video.x*0.38, video.y*0.3, 1);
DrawFormattedText(video.h, 'Astuce 2 : Si vous �tes "trop lent", vous entendrez ce son :', video.x*0.3, video.y*0.45, 1);
DrawFormattedText(video.h, 'Mais, attention, si vous r�pondez avant que ', video.x*0.38, video.y*0.5, 1);
DrawFormattedText(video.h, 'le carr� central ne s''affiche, vous entendrez ce son :', video.x*0.38, video.y*0.55, 1);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
Sound_ToFast(0,pahandle); key = WaitKeyPress([keyconfirm keystop]); 

% POINTS =================================================================%
draw_tuto(video,4);
DrawFormattedText(video.h, 'Comment marquer des points ?', video.x*0.3,  video.y*0.15, 1);
DrawFormattedText(video.h, '+2 point', video.x*0.3,  video.y*0.3, [0 1 0]);
DrawFormattedText(video.h, 'si vous s�lectionnez RAPIDEMENT la bonne couleur', video.x*0.38,  video.y*0.3, 1);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
%------------------
draw_tuto(video,4);
DrawFormattedText(video.h, 'Comment marquer des points ?', video.x*0.3,  video.y*0.15, 1);
DrawFormattedText(video.h, '+2 point', video.x*0.3,  video.y*0.3, [0 1 0]);
DrawFormattedText(video.h, 'si vous s�lectionnez RAPIDEMENT la bonne couleur', video.x*0.38,  video.y*0.3, 1);
DrawFormattedText(video.h, '-1 point', video.x*0.3,  video.y*0.4, [1 0 0]);
DrawFormattedText(video.h, 'si vous �tes trop lent', video.x*0.38,  video.y*0.4, 1);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
%------------------
draw_tuto(video,4);
DrawFormattedText(video.h, 'Comment marquer des points ?', video.x*0.3,  video.y*0.15, 1);
DrawFormattedText(video.h, '+2 point', video.x*0.3,  video.y*0.3, [0 1 0]);
DrawFormattedText(video.h, 'si vous s�lectionnez RAPIDEMENT la bonne couleur', video.x*0.38,  video.y*0.3, 1);
DrawFormattedText(video.h, '-1 point', video.x*0.3,  video.y*0.4, [1 0 0]);
DrawFormattedText(video.h, 'si vous �tes trop lent', video.x*0.38,  video.y*0.4, 1);
DrawFormattedText(video.h, '-1 point', video.x*0.3,  video.y*0.5, [1 0 0]);
DrawFormattedText(video.h, 'si vous r�pondez avant que le carr� central ne s''affiche', video.x*0.38,  video.y*0.5, 1);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
%------------------
draw_tuto(video,4);
DrawFormattedText(video.h, 'Comment marquer des points ?', video.x*0.3,  video.y*0.15, 1);
DrawFormattedText(video.h, '+2 point', video.x*0.3,  video.y*0.3, [0 1 0]);
DrawFormattedText(video.h, 'si vous s�lectionnez RAPIDEMENT la bonne couleur', video.x*0.38,  video.y*0.3, 1);
DrawFormattedText(video.h, '-1 point', video.x*0.3,  video.y*0.4, [1 0 0]);
DrawFormattedText(video.h, 'si vous �tes trop lent', video.x*0.38,  video.y*0.4, 1);
DrawFormattedText(video.h, '-1 point', video.x*0.3,  video.y*0.5, [1 0 0]);
DrawFormattedText(video.h, 'si vous r�pondez avant que le carr� central ne s''affiche', video.x*0.38,  video.y*0.5, 1);
DrawFormattedText(video.h, '+4 points', video.x*0.3,  video.y*0.6, [0 1 0]);
DrawFormattedText(video.h, 'lorsque le carr� central change de couleur (cas difficile)', video.x*0.39,  video.y*0.6, 1);
DrawFormattedText(video.h, 'et que vous s�lectionnez la bonne couleur', video.x*0.39,  video.y*0.65, 1);
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 


% ENTRA�NEMENT ===========================================================%
draw_tuto(video,5);
DrawFormattedText(video.h, '�tes-vous pr�t � passer � l''entra�nement ?', 'center', video.y*0.4, 1); 
Screen('Flip', video.h);

% Close the audio device
PsychPortAudio('Close', pahandle); 

key = WaitKeyPress([keyconfirm keystop]);
if isequal(key,1)
    %[Passation,Passation.ErrorMsg] = switch_Training(participant);
elseif isequal(key,2)
    trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
    sca;
end

%-------------------------------------------------------------------------%

if participant.flags.with_eyetracker && ~is_training
    fprintf('Stopping Eyetracker ...');
    Eyelink('StopRecording');
    fprintf('recording stopped.\n');
end
if participant.flags.with_response_lumina
    IOPort('Close',hport_lum); % Close response port
end   
if participant.flags.with_triggers
    IOPort('Close',hport_trig); % close trigger port %  CloseParPort;
end

% Close video etc.
Priority(0);
Screen('CloseAll');
FlushEvents;
ListenChar(0);
ShowCursor;
video = [];

return

%%%%%%%%%%%%% THIS IS THE END %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
