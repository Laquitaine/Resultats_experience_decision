%%
%==========================================================================
% Data loading
%==========================================================================
Data = [ load([num2str(Passation.Filename) '_Bloc_1.mat']) ];
%Data = [ load('switch_20190214-0910_training_Bloc_1.mat') ];
%Data = [ load('switch_20190214-0920_exprmnt1_Bloc_1.mat')...
%         load('switch_20190214-0920_exprmnt1_Bloc_2.mat')]
%         load('switch_20190131-1017_exprmnt1_Bloc_3.mat') ];
if(0)
NSubject=6;                                     % Nombre de sujets
DataFolder = fileparts(mfilename('fullpath'));  % Saving switch\Data path
cd(DataFolder);                                 % Going to switch\Data
DataDirectory = []; DataDirectory = ls;         % Saving 001,002,003... paths
addpath(DataFolder);                            % Give access to switch\Data files
DataFiles = [];
for i=3:1:NSubject+2
    addpath(fullfile(DataFolder,DataDirectory(i,[1:3])));   % Give access to switch\Data\00X files
    cd(fullfile(DataFolder,DataDirectory(i,[1:3])));        % Going to switch\Data\00X files
    DataFiles = ls;                                         % switch_20190000_exp_Bloc_1.mat
    Name = DataDirectory(i,[1:3]);
    Data.(Name) = 0
    
end
end

%%

%==========================================================================
% Variables initialisation
%==========================================================================
%--------------------------------------------------------------------------
k=1;                        % [Indice] Number of blocs
i=1;                        % [Indice] Number of lines
j=1;                        % [Indice] Number of columns
N=3;                        % Set the N-2, N-1, N, N+1, N+2 matrix
q=1;
%--------------------------------------------------------------------------
[N0,Nblocs] = size(Data);   % Number of blocs loaded
Ntotal = [];                % Number total of trials per blocs
%--------------------------------------------------------------------------
Nswitch=0;                  % Number of switch 
Nswitch_05=0;              % Number of switch
Nswitch_1=0;                % Number of switch 
Nswitch_15=0;               % Number of switch 
Nswitch_20=0;               % Number of switch 
%--------------------------------------------------------------------------
rt = zeros(1,5);            % Reaction time of the N switch trials
err = zeros(1,5);           % Error rate of the N switch trials 
rt_05 = zeros(1,5);        % Reaction time of the N switch trials
err_05 = zeros(1,5);       % Error rate of the N switch trials 
rt_1 = zeros(1,5);          % Reaction time of the N switch trials
err_1 = zeros(1,5);         % Error rate of the N switch trials 
rt_15 = zeros(1,5);         % Reaction time of the N switch trials
err_15 = zeros(1,5);        % Error rate of the N switch trials 
rt_20 = zeros(1,5);         % Reaction time of the N switch trials
err_20 = zeros(1,5);        % Error rate of the N switch trials 
%--------------------------------------------------------------------------
rt_NS_correct = [];         % RT of correct NS
rt_NS_Ncorrect = [];        % RT of non correct NS
rt_S_correct = [];          % RT of correct switch
rt_S_Ncorrect = [];         % RT of non correct switch
%--------------------------------------------------------------------------
interv_NS_correct = [];         % RT of correct NS
interv_NS_Ncorrect = [];        % RT of non correct NS
interv_S_correct = [];          % RT of correct switch
interv_S_Ncorrect = [];         % RT of non correct switch
%--------------------------------------------------------------------------
task_diff2 = [];            % Variable interval time 2
react_time2 = [];           % Reaction time 2
accu2 = [];                 % Accurate 2
switch_trials2 = [];        % Switch trials positions 2
mean_rt2 = [];
mean_err2 = [];
interv2 = [];
rt_S2=[];
rt_NS2=[];
%--------------------------------------------------------------------------
%mean_err = [0];
T = [];                     % Trials vector



% LOOP 1 : --- from 1 to total number of blocs
%==========================================================================
for k=1:1:Nblocs
    
    [Nline,Ncolumn]=size(Data(k).Passation.Data.Response.rt); % Size of the matrix 
    Ntotal(k)=Nline*Ncolumn;                                  % Number of trials per bloc

    task_diff = [];
    react_time = [];
    accu = [];
    switch_trials = [];
    mean_rt = [];
    interv = [];
    rt_S=[];
    rt_NS=[];
    
    % LOOP 2 : --- from 1 to total number of lines
    %======================================================================
    for i=1:1:Nline
        
        % LOOP 3 : --- from 1 to total number of columns
        %==================================================================
        for j=1:1:Ncolumn

            task_diff(i,j) = 1e3*Data(k).Passation.Data.Trials.td{i,j};
            react_time(i,j) = 1e3*Data(k).Passation.Data.Response.rt{i,j};
            accu(i,j) = Data(k).Passation.Data.Response.accu{i,j};
            switch_trials(i,j) = Data(k).Passation.Data.Trials.switch{i,j};
            mean_rt(i,j) = mean(react_time);
            interv(i,j) = 1e3*(Data(k).Passation.Data.Timecode.precue_offset{i,j} - Data(k).Passation.Data.Timecode.precue_onset{i,j});
            mean_err(i,j) = 1e2*(1 - mean(accu));
            
            if Data(k).Passation.Data.Trials.switch{i,j}==2

                Nswitch = Nswitch+1;  % Number of the switch incrementation
                rt(N-2) = rt(N-2) + Data(k).Passation.Data.Response.rt{i,j-2}; % Reaction time N-2
                rt(N-1) = rt(N-1) + Data(k).Passation.Data.Response.rt{i,j-1}; % Reaction time N-1
                rt(N) = rt(N) + Data(k).Passation.Data.Response.rt{i,j};       % Reaction time N
                err(N-2) = err(N-2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N-2
                err(N-1) = err(N-1) + 1 - Data(k).Passation.Data.Response.accu{i,j-1}; % Error rate N-1
                err(N) = err(N) + 1 - Data(k).Passation.Data.Response.accu{i,j};       % Error rate N
                if j<=Ncolumn-2
                    rt(N+1) = rt(N+1) + Data(k).Passation.Data.Response.rt{i,j+1}; % Reaction time N+1
                    rt(N+2) = rt(N+2) + Data(k).Passation.Data.Response.rt{i,j+2}; % Reaction time N+2
                    err(N+1) = err(N+1) + 1 - Data(k).Passation.Data.Response.accu{i,j+1}; % Error rate N+1
                    err(N+2) = err(N+2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N+2
                end
          
                if  interv(i,j)<=749 % UTILISER LA NOTATION rt(N-2,2) � la place de rt_05(N-2)                  
                    Nswitch_05 = Nswitch_05+1;
                    rt_05(N-2) = rt_05(N-2) + Data(k).Passation.Data.Response.rt{i,j-2}; % Reaction time N-2
                    rt_05(N-1) = rt_05(N-1) + Data(k).Passation.Data.Response.rt{i,j-1}; % Reaction time N-1
                    rt_05(N) = rt_05(N) + Data(k).Passation.Data.Response.rt{i,j};       % Reaction time N
                    err_05(N-2) = err_05(N-2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N-2
                    err_05(N-1) = err_05(N-1) + 1 - Data(k).Passation.Data.Response.accu{i,j-1}; % Error rate N-1
                    err_05(N) = err_05(N) + 1 - Data(k).Passation.Data.Response.accu{i,j};       % Error rate N
                    if j<=Ncolumn-2
                        rt_05(N+1) = rt_05(N+1) + Data(k).Passation.Data.Response.rt{i,j+1}; % Reaction time N+1
                        rt_05(N+2) = rt_05(N+2) + Data(k).Passation.Data.Response.rt{i,j+2}; % Reaction time N+2
                        err_05(N+1) = err_05(N+1) + 1 - Data(k).Passation.Data.Response.accu{i,j+1}; % Error rate N+1
                        err_05(N+2) = err_05(N+2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N+2
                    end
                
                elseif (interv(i,j)>749 && interv(i,j)<=1249) % UTILISER LA NOTATION rt(N-2,3) � la place de rt_1(N-2)
                    Nswitch_1 = Nswitch_1+1;
                    rt_1(N-2) = rt_1(N-2) + Data(k).Passation.Data.Response.rt{i,j-2}; % Reaction time N-2
                    rt_1(N-1) = rt_1(N-1) + Data(k).Passation.Data.Response.rt{i,j-1}; % Reaction time N-1
                    rt_1(N) = rt_1(N) + Data(k).Passation.Data.Response.rt{i,j};       % Reaction time N
                    err_1(N-2) = err_1(N-2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N-2
                    err_1(N-1) = err_1(N-1) + 1 - Data(k).Passation.Data.Response.accu{i,j-1}; % Error rate N-1
                    err_1(N) = err_1(N) + 1 - Data(k).Passation.Data.Response.accu{i,j};       % Error rate N
                    if j<=Ncolumn-2
                        rt_1(N+1) = rt_1(N+1) + Data(k).Passation.Data.Response.rt{i,j+1}; % Reaction time N+1
                        rt_1(N+2) = rt_1(N+2) + Data(k).Passation.Data.Response.rt{i,j+2}; % Reaction time N+2
                        err_1(N+1) = err_1(N+1) + 1 - Data(k).Passation.Data.Response.accu{i,j+1}; % Error rate N+1
                        err_1(N+2) = err_1(N+2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N+2
                    end
                
                elseif (interv(i,j)>1249 && interv(i,j)<=1749) % UTILISER LA NOTATION rt(N-2,3) � la place de rt_15(N-2)
                    Nswitch_15 = Nswitch_15+1;
                    rt_15(N-2) = rt_15(N-2) + Data(k).Passation.Data.Response.rt{i,j-2}; % Reaction time N-2
                    rt_15(N-1) = rt_15(N-1) + Data(k).Passation.Data.Response.rt{i,j-1}; % Reaction time N-1
                    rt_15(N) = rt_15(N) + Data(k).Passation.Data.Response.rt{i,j};       % Reaction time N
                    err_15(N-2) = err_15(N-2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N-2
                    err_15(N-1) = err_15(N-1) + 1 - Data(k).Passation.Data.Response.accu{i,j-1}; % Error rate N-1
                    err_15(N) = err_15(N) + 1 - Data(k).Passation.Data.Response.accu{i,j};       % Error rate N
                    if j<=Ncolumn-2
                        rt_15(N+1) = rt_15(N+1) + Data(k).Passation.Data.Response.rt{i,j+1}; % Reaction time N+1
                        rt_15(N+2) = rt_15(N+2) + Data(k).Passation.Data.Response.rt{i,j+2}; % Reaction time N+2
                        err_15(N+1) = err_15(N+1) + 1 - Data(k).Passation.Data.Response.accu{i,j+1}; % Error rate N+1
                        err_15(N+2) = err_15(N+2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N+2
                    end
                    
                    
                 elseif interv(i,j)>1749 % UTILISER LA NOTATION rt(N-2,4) � la place de rt_20(N-2)
                    Nswitch_20 = Nswitch_20+1;
                    rt_20(N-2) = rt_20(N-2) + Data(k).Passation.Data.Response.rt{i,j-2}; % Reaction time N-2
                    rt_20(N-1) = rt_20(N-1) + Data(k).Passation.Data.Response.rt{i,j-1}; % Reaction time N-1
                    rt_20(N) = rt_20(N) + Data(k).Passation.Data.Response.rt{i,j};       % Reaction time N
                    err_20(N-2) = err_20(N-2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N-2
                    err_20(N-1) = err_20(N-1) + 1 - Data(k).Passation.Data.Response.accu{i,j-1}; % Error rate N-1
                    err_20(N) = err_20(N) + 1 - Data(k).Passation.Data.Response.accu{i,j};       % Error rate N
                    if j<=Ncolumn-2
                        rt_20(N+1) = rt_20(N+1) + Data(k).Passation.Data.Response.rt{i,j+1}; % Reaction time N+1
                        rt_20(N+2) = rt_20(N+2) + Data(k).Passation.Data.Response.rt{i,j+2}; % Reaction time N+2
                        err_20(N+1) = err_20(N+1) + 1 - Data(k).Passation.Data.Response.accu{i,j+1}; % Error rate N+1
                        err_20(N+2) = err_20(N+2) + 1 - Data(k).Passation.Data.Response.accu{i,j-2}; % Error rate N+2
                    end
                
                end 

            end
            
            if Data(k).Passation.Data.Trials.switch{i,j}==1 ... % NON SWITCH
                    && Data(k).Passation.Data.Response.accu{i,j}==1 % CORRECT
                rt_NS_correct = [rt_NS_correct , Data(k).Passation.Data.Response.rt{i,j}];
                interv_NS_correct = [interv_NS_correct , interv(i,j)];
            end
            if Data(k).Passation.Data.Trials.switch{i,j}==1 ... % NON SWITCH
                    && Data(k).Passation.Data.Response.accu{i,j}==0 % NON CORRECT
                rt_NS_Ncorrect = [rt_NS_Ncorrect , Data(k).Passation.Data.Response.rt{i,j}];
                interv_NS_Ncorrect = [interv_NS_Ncorrect , interv(i,j)];
            end
            if Data(k).Passation.Data.Trials.switch{i,j}==2 ... % SWITCH
                    && Data(k).Passation.Data.Response.accu{i,j}==1 % CORRECT
                rt_S_correct = [rt_S_correct , Data(k).Passation.Data.Response.rt{i,j}];
                interv_S_correct = [interv_S_correct , interv(i,j)];
            end
            if Data(k).Passation.Data.Trials.switch{i,j}==2 ... % SWITCH
                    && Data(k).Passation.Data.Response.accu{i,j}==0 % NON CORRECT
                rt_S_Ncorrect = [rt_S_Ncorrect , Data(k).Passation.Data.Response.rt{i,j}];
                interv_S_Ncorrect = [interv_S_Ncorrect , interv(i,j)];
            end

            if Data(k).Passation.Data.Trials.switch{i,j}==1  % NON SWITCH
                 rt_NS(i,j) = 1e3 * Data(k).Passation.Data.Response.rt{i,j};
                 rt_S(i,j) = -500;
            elseif Data(k).Passation.Data.Trials.switch{i,j}==2  % SWITCH
                 rt_S(i,j) = 1e3 * Data(k).Passation.Data.Response.rt{i,j};
                 rt_NS(i,j) = -500;
            end
            
        end
        % END of LOOP 3 : --- from 1 to total number of columns
        %==================================================================
            
    end
    % END of LOOP 2 : --- from 1 to total number of lines
    %======================================================================
    task_diff2 = [task_diff2, task_diff];
    react_time2 = [react_time2 , react_time];
    accu2 = [accu2 , accu];
    switch_trials2 = [switch_trials2 , switch_trials];
    mean_rt2 = [mean_rt2 , mean_rt];
    mean_err2 = [mean_err2 , mean_err];
    interv2 = [interv2 , interv];
    rt_S2 = [rt_S2 , rt_S];
    rt_NS2 = [rt_NS2 , rt_NS];
    
end
% END of LOOP 1 : --- from 1 to total number of blocs
%==========================================================================

rt = 1e3*rt/Nswitch;
err = 1e2*err/Nswitch;
X = -2:1:2;
T = 1:1:sum(Ntotal);
T = 1:1:size(task_diff2,2);
T2 = 1:1:sum(Ntotal)+1;
RT = mean(rt)*ones(1,sum(Ntotal));

rt_05 = 1e3*rt_05/Nswitch_05;
err_05 = 1e2*err_05/Nswitch_05;
rt_1 = 1e3*rt_1/Nswitch_1;
err_1 = 1e2*err_1/Nswitch_1;
rt_15 = 1e3*rt_15/Nswitch_15;
err_15 = 1e2*err_15/Nswitch_15;
rt_20 = 1e3*rt_20/Nswitch_20;
err_20 = 1e2*err_20/Nswitch_20;

%==========================================================================
% STEP 1 : Behavioral result
%========================================================================== 
%figure;
hold on; grid on;
subplot(2,3,1);
    title([num2str(Nswitch) ' switch trials ']); 
    xlabel('Trials position'); 
    xticks([-2 -1 0 1 2]); xticklabels({'N-2','N-1','N','N+1','N+2'});
    yyaxis left; plot(X,rt,'o-'); ylabel('Reaction time (ms)'); axis([-2 2 min(rt)*0.99 max(rt)*1.01]);
    yyaxis right; plot(X,err,'o-'); ylabel('Error rate (%)'); axis([-2 2 0 max(err)*1.1]);
subplot(2,3,2); 
    h1 = histogram(1e3*rt_NS_correct,'Normalization','count');
    h1.FaceColor = [0 0.5 0]; h1.EdgeColor = [0 0 0]; %h1.BinLimits=[-100 500];
    hold on; 
    h2 = histogram(1e3*rt_NS_Ncorrect,'Normalization','count');
    h2.FaceColor = [1 0 0]; h2.EdgeColor = [0 0 0]; %h2.BinLimits=[-100 500];
    title('Non switch trials');xlabel('Reaction time (ms)'); ylabel('Number of trials');
    legend([num2str(length(rt_NS_correct)) ' Correct '],[num2str(length(rt_NS_Ncorrect)) ' Not correct']);
subplot(2,3,3); 
    h1 = histogram(1e3*rt_S_correct,'Normalization','count');
    h1.FaceColor = [0 0.5 0]; h1.EdgeColor = [0 0 0]; %h1.BinLimits=[-100 500];
    hold on; 
    h2 = histogram(1e3*rt_S_Ncorrect,'Normalization','count');
    h2.FaceColor = [1 0 0]; h2.EdgeColor = [0 0 0]; %h2.BinLimits=[-100 500];
    title('Switch trials');xlabel('Reaction time (ms)'); ylabel('Number of trials');
    legend([num2str(length(rt_S_correct)) ' Correct '],[num2str(length(rt_S_Ncorrect)) ' Not correct']);
subplot(2,3,[4,5,6]);
    title(['Real time evaluation on ' num2str(length(task_diff2)) ' trials']); xlabel('Trials');
    %yyaxis left; plot(T,task_diff2,'b-',T,mean_rt2,'-'); ylabel('Time (ms)'); axis([min(T) max(T) 0 max([task_diff2,mean_rt2])*1.1]);
    yyaxis left; plot(T,task_diff2,'b-',T,react_time2,'-'); ylabel('Time (ms)'); axis([min(T) max(T) min([task_diff2,react_time2])*1.1 max([task_diff2,react_time2])*1.1]);
    yyaxis right; plot(T,mean_err2,'-'); ylabel('Percent (%)'); axis([min(T) max(T) 0 max(mean_err2)*1.1]);   
    legend('Allowed responding time','Reaction time','Error rate');
hold off; grid off;


%==========================================================================
% STEP 2 : Variable time interval 
%========================================================================== 
if(0)
figure;
hold on; grid on;
subplot(2,4,1); 
    title([num2str(Nswitch_05) ' switch trials @ 500ms +/-250ms']); 
    xlabel('Trials position'); 
    xticks([-2 -1 0 1 2]); xticklabels({'N-2','N-1','N','N+1','N+2'});
    yyaxis left; plot(X,rt_05,'o-'); ylabel('Reaction time (ms)'); axis([-2 2 min(rt_05)*0.99 max(rt_05)*1.01]);
    yyaxis right; plot(X,err_05,'o-'); ylabel('Error rate (%)'); axis([-2 2 0 max(err_05)*1.1]);
subplot(2,4,2);
    title([num2str(Nswitch_1) ' switch trials @ 1s +/-250ms']); 
    xlabel('Trials position'); 
    xticks([-2 -1 0 1 2]); xticklabels({'N-2','N-1','N','N+1','N+2'});
    yyaxis left; plot(X,rt_1,'o-'); ylabel('Reaction time (ms)'); axis([-2 2 min(rt_1)*0.99 max(rt_1)*1.01]);
    yyaxis right; plot(X,err_1,'o-'); ylabel('Error rate (%)'); axis([-2 2 0 max(err_1)*1.1]);    
subplot(2,4,3);
    title([num2str(Nswitch_15) ' switch trials  @ 1.5s +/-250ms']); 
    xlabel('Trials position'); 
    xticks([-2 -1 0 1 2]); xticklabels({'N-2','N-1','N','N+1','N+2'});
    yyaxis left; plot(X,rt_15,'o-'); ylabel('Reaction time (ms)'); axis([-2 2 min(rt_15)*0.99 max(rt_15)*1.01]);
    yyaxis right; plot(X,err_15,'o-'); ylabel('Error rate (%)'); axis([-2 2 0 max(err_15)*1.1]);
subplot(2,4,4);
    title([num2str(Nswitch_20) ' switch trials  @ 2s +/-250ms']); 
    xlabel('Trials position'); 
    xticks([-2 -1 0 1 2]); xticklabels({'N-2','N-1','N','N+1','N+2'});
    yyaxis left; plot(X,rt_20,'o-'); ylabel('Reaction time (ms)'); axis([-2 2 min(rt_20)*0.99 max(rt_20)*1.01]);
    yyaxis right; plot(X,err_20,'o-'); ylabel('Error rate (%)'); axis([-2 2 0 max(err_20)*1.1]);    
subplot(2,4,[5,6]);    
    plot(interv2,rt_NS2,'+b',interv2,rt_S2,'or')
    title(['Reaction time evolution on ' num2str(length(interv2)) ' trials']); 
    xlabel('Precue display duration (ms)'); ylabel('Reaction time (ms)'); axis([min(interv2) max(interv2) -100 max([rt_NS,rt_S])*1.1]);
    legend([num2str(sum(rt_NS2>-300)) ' Non swich trials'],[num2str(sum(rt_S2>-300)) ' Switch trials'],'Location','SouthEast');
subplot(2,4,7);    
    h1 = histogram(interv_NS_correct,'Normalization','count');
    h1.FaceColor = [0 0.5 0]; h1.EdgeColor = [0 0 0]; %h1.BinLimits=[-100 500];
    hold on; 
    h2 = histogram(interv_NS_Ncorrect,'Normalization','count');
    h2.FaceColor = [1 0 0]; h2.EdgeColor = [0 0 0]; %h2.BinLimits=[-100 500];
    title('Variable intervals on non switch');xlabel('Intervals (ms)'); ylabel('Number of trials');
    legend([num2str(length(interv_NS_correct)) ' NS correct '],[num2str(length(interv_NS_Ncorrect)) ' NS Not correct']);
subplot(2,4,8);    
    h1 = histogram(interv_S_correct,'Normalization','count');
    h1.FaceColor = [0 0.5 0]; h1.EdgeColor = [0 0 0]; %h1.BinLimits=[-100 500];
    hold on; 
    h2 = histogram(interv_S_Ncorrect,'Normalization','count');
    h2.FaceColor = [1 0 0]; h2.EdgeColor = [0 0 0]; %h2.BinLimits=[-100 500];
    title('Variable intervals on switch');xlabel('Intervals (ms)'); ylabel('Number of trials');
    legend([num2str(length(interv_S_correct)) ' S correct '],[num2str(length(interv_S_Ncorrect)) ' S Not correct']);
hold off; grid off;
end
    