%==========================================================================
% Function : draw_tuto
%==========================================================================

function draw_tuto(video,i)
DrawFormattedText(video.h, 'INSTRUCTIONS', video.x*0.05, video.y*0.2, 1);
DrawFormattedText(video.h, 'D�roulement', video.x*0.05, video.y*0.4, 0.5);
DrawFormattedText(video.h, 'Objectifs', video.x*0.05, video.y*0.45, 0.5);
DrawFormattedText(video.h, 'Astuces', video.x*0.05, video.y*0.5, 0.5);
DrawFormattedText(video.h, 'Points', video.x*0.05, video.y*0.55, 0.5);
DrawFormattedText(video.h, 'Entra�nement', video.x*0.05, video.y*0.6, 0.5);
DrawFormattedText(video.h, 'Appuyez sur ENTREE pour continuer', 'center', video.y*0.9, 0.5);
if i==1
    DrawFormattedText(video.h, 'D�roulement', video.x*0.05, video.y*0.4, 1);
    WidthPixels = 2;
    baseRect = [0 0 800 500];
    Rect = CenterRectOnPointd(baseRect, video.xCenter, video.yCenter);
    Screen('FrameRect', video.h, 0.5, Rect, WidthPixels);
elseif i==2
    DrawFormattedText(video.h, 'Objectifs', video.x*0.05, video.y*0.45, 1);
elseif i==3
    DrawFormattedText(video.h, 'Astuces', video.x*0.05, video.y*0.5, 1);
elseif i==4
    DrawFormattedText(video.h, 'Points', video.x*0.05, video.y*0.55, 1);
elseif i==5
    DrawFormattedText(video.h, 'Entra�nement', video.x*0.05, video.y*0.6, 1);
end

 