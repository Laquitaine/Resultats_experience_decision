num_bloc = 8;                       % Number of blocs
bloc_volatility_order = [1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1]; % Order of volatity per bloc
bloc_volatility_order = bloc_volatility_order(randperm(num_bloc),:); % Random permutation of line order
n_trials_within_volatility = 20;    % Number of switch per volatity

num_nsw=[];                         % Number of non-switch
num_nsw(:,1)=repmat([3 4 5 6],1,n_trials_within_volatility/4); % Column 1 [3 4 5...]
num_nsw(:,1)=num_nsw(randperm(length(num_nsw(:,1))),1); % Randomized column 1

blocidx=1;                          % Bloc index
volatility_level=1;                 % Volatitlity level
volatility=bloc_volatility_order(blocidx,volatility_level); % Volatility of this bloc and volatility level
num_nsw_vl=num_nsw(:,volatility);   % Vecteur de non-switch successif
rules=repmat([1 2],1,n_trials_within_volatility/2); % Rules
pseudo_rd=randperm(length(rules))  % Randomize the index of the rules vector
same_resp_idx=pseudo_rd(1:round(length(rules)*0.33)); % for same response_switch type, we will just have to adjust the side

        %% a) the switch axe will correspond to the same axe than the previous non-switch in 50 % of trials
        same_axe_idx=pseudo_rd(1:round(length(rules)*0.5));     % H-H or V-V cases
        diff_axe_idx=pseudo_rd(round(length(rules)*0.5)+1:end); % H-V or V-H cases
        
        %% b) the switch side will correspond to the same side than the previous non-switch in 50 % of trials
        same_resp_same_side_idx=same_axe_idx(1:round(length(same_axe_idx)*0.165));                                 % 0.33/2 repeat + same H side and same V side
        same_resp_diff_side_idx=same_axe_idx(round(length(same_axe_idx)*0.165)+1:round(length(same_axe_idx)*0.33));% 0.33/2 repeat + same H (or V) side and different V (or H) side
        diff_resp_same_side_idx=same_axe_idx(round(length(same_axe_idx)*0.33)+1:round(length(same_axe_idx)*0.665));% 0.67/2 alternate + same H side and same V side
        diff_resp_diff_side_idx=same_axe_idx(round(length(same_axe_idx)*0.665)+1:end);                             % 0.67/2 alternate + same H (or V) side and different V (or H) side
        
        %% c) the switch response will correspond to the same side than the previous non-switch in 33 % of trials
        diff_side0_idx=diff_axe_idx(1:round(length(diff_axe_idx)*0.25));                                  % 0.25 for 0 axe different from previous
        diff_side1_on_idx=diff_axe_idx(round(length(diff_axe_idx)*0.25)+1:round(length(diff_axe_idx)*0.5));% 0.25 for 1 axe different from previous = selected axe
        diff_side1_off_idx=diff_axe_idx(round(length(diff_axe_idx)*0.5)+1:round(length(diff_axe_idx)*0.75));% 0.25 for 1 axe different from previous (=/) selected axe
        diff_side2_idx=diff_axe_idx(round(length(diff_axe_idx)*0.75)+1:end);                               % 0.25 for 2 axe different from previous
        
for switch_seq=1:length(num_nsw_vl) %18 "sequences of trials"/level of volatility
    numtrial=num_nsw_vl(switch_seq)+1; % number of trials = number of non-switch +1
    rule=rules(switch_seq);         % will change if trial=num_trial
    sides=repmat([1 2],1,round(numtrial/2));%Here I set a sequence of sides
    sides=sides(randperm(length(sides))); %randomize the side
    ismember(switch_seq,same_resp_idx);
end