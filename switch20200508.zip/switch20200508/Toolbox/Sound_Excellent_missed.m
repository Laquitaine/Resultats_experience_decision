%==========================================================================
% Function : Sound_Excellent_missed
%==========================================================================

function Sound_Excellent_missed(delay,pahandle)

myBeep4 = MakeBeep(1100, 1/10, 48000); % Create a beep
PsychPortAudio('FillBuffer', pahandle, [myBeep4; myBeep4]); % Fill the audio playback buffer with the audio data
PsychPortAudio('Start', pahandle, 1, delay, 1); % Start audio playback
PsychPortAudio('Stop', pahandle, 1, 1);

myBeep3 = MakeBeep(1050, 1/10, 48000); % Create a beep
PsychPortAudio('FillBuffer', pahandle, [myBeep3; myBeep3]); % Fill the audio playback buffer with the audio data
PsychPortAudio('Start', pahandle, 1, 0, 1); % Start audio playback
PsychPortAudio('Stop', pahandle, 1, 1);

myBeep2 = MakeBeep(1000, 1/10, 48000); % Create a beep
PsychPortAudio('FillBuffer', pahandle, [myBeep2; myBeep2]); % Fill the audio playback buffer with the audio data
PsychPortAudio('Start', pahandle, 1, 0, 1); % Start audio playback
PsychPortAudio('Stop', pahandle, 1, 1);

myBeep1 = MakeBeep(950, 1/8, 48000); % Create a beep
PsychPortAudio('FillBuffer', pahandle, [myBeep1; myBeep1]); % Fill the audio playback buffer with the audio data
PsychPortAudio('Start', pahandle, 1, 0, 1); % Start audio playback
PsychPortAudio('Stop', pahandle, 1, 1);