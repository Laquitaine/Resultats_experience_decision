%==========================================================================
% Function : OpenPTBScreen
%==========================================================================

function video = OpenPTBScreen(frame)      % Open Psychtoolbox Screen
global DEBUG                               % Define DEBUG as a global variable
ppd=evalin('caller', 'ppd');               % Re-affectation by evaluating in workspace
Screen('CloseAll');                        % Close all screens, windows, textures, videos
Screen('Preference','VisualDebuglevel',3); % Display alert debug
%Screen('Preference','SkipSyncTests', 1);   % Skip sync test
%Screen('Preference','SyncTestSettings' [, maxStddev=0.001 secs][, minSamples=50][, maxDeviation=0.1][, maxDuration=5 secs]);
%Screen('Preference','SyncTestSettings', 0.001, 50, 0.1, 5);
PsychDefaultSetup(2);                      % Higher perform setup for Psychtoolbox
PsychImaging('PrepareConfiguration');      % Prepare setup for onscreen window.
PsychImaging('AddTask','General','UseFastOffscreenWindows');
%PsychImaging('AddTask','General','NormalizedHighresColorRange');

if DEBUG
   Screen('Preference', 'SkipSyncTests', 1);
else
   Screen('Preference', 'SkipSyncTests', 0);
end
video.i = max(Screen('Screens'));          % Higher number of screens (default auxillary monitor)
frame = [];                                % Define frame as a type double variable (full screen?)
video.res = Screen('Resolution',video.i);

% Now open a Psychtoolbox Window
[video.h,videoRect] = PsychImaging('OpenWindow',video.i,0);% Open a new window
[video.x,video.y] = Screen('WindowSize',video.h); % [pixel] Window dimension
[video.xCenter, video.yCenter] = RectCenter(videoRect); % [pixel] Center position (=video.xy/2)
Screen('TextFont',video.h,'Arial');
Screen('TextSize',video.h,round(0.33*ppd));
Screen('TextStyle',video.h,0);
%Screen('ColorRange',video.h,1);
%video.ifi = 1/60; 
video.ifi = Screen('GetFlipInterval',video.h,100,50e-6,10); % Display period
Screen('BlendFunction',video.h,GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
Priority(MaxPriority(video.h));