%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Switch2_TaskParameter.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% initialize SWITCH experiment
SESSIONS = {'lfp';'lfpmeg';'comportement'};

%% Default Experiment flags
flags.with_training          = 0;   % with initial training bloc?
flags.with_eyetracker = 0;          % change that for TOBII eye-tracker experiment
flags.with_fullscreen = 2;          % Check this parameter (not sure this is really used)
flags.with_triggers = 0;
flags.with_response_lumina   = participant.flags.with_response_lumina ; % Response Device = Lumina buttons
flags.with_response_mouse    = participant.flags.with_response_mouse; % Response Device = Mouse buttons
flags.with_response_keyboard = participant.flags.with_response_keyboard; % Response Device = Keyboard letters
flags.with_response_logitech = participant.flags.with_response_logitech; % Response Device = Keyboard letters
flags.parallel_triggers      = participant.flags.parallel_triggers; % send triggers on parallel port
flags.serial_triggers        = participant.flags.serial_triggers; % 0: parrallel port/1=serial port (which is used for LUMINA buttons)

%% we may want to try to use two serial ports: one for the triggers, and one for the responses 
...for the LFPs recordings (but this would not be consistent with MEG-lfp experimental set-up)
    
%% Useful inline functions: easier screen-blink compatible timing
% Typical use:>> Screen('Flip',video.h,last_flip+roundfp(duration,ifi));
roundfp = @(dt,ifi)(round(dt/ifi)-0.5)*ifi;%voir les demo psychotoolbox sur accurate timing+ fonction inline sur matlab

%% Stimuli (I would rather draw the stimluli...)
    %% S.1: Stimuli parameters (set in task_parameters): 
    cue_size=50;%size of the squares (cue or rule)
    fix_dot_Color = [1 1 1];%white central dot
    fix_dot_SizePix = 20;% Dot size in pixels
    post_cue_long = 500; % size of the rectangle long axe for the orientation
    post_cue_short = 80; % size of the rectangle short axe for the orientation

    %% S.2: 
    
%% Timing of events within a given trial OF PRELIMINARY RESULTS
timing1.fixduration = @()0.4   +.2*(rand-.5);%this is 400 ms +- 100 ms
timing1.precueduration = @()1   +.4*(rand-.5); %1.2   +.4*(rand-.5);%this is 1200 ms +- 200 ms;(%let's use a fix cue duration to begin...but...we will need to adapt this for SWITCH 2)
timing1.cueduration = .2;%let's use a fix cue duration to begin...but...we will need to adapt this for SWITCH 2)
timing1.feedbackduration = .5; %0.4
timing1.response_release = .2;  
timing1.startofblock = 2; %wait for 2 seconds at the begining of each bloc ?

%% Timing of events within a given trial OF EXPERIMENT B.O.
timing2.fixduration = @()0.2 ;                   % 200ms                         // TRIGGER 10
timing2.precueduration = @()0.5;                 % 400ms                         // ----
timing2.cueduration = @()0.375 +0.25*(rand-0.5); % [2] 250-500 ms [1] 250-750 ms // TRIGGER 20 
timing2.postcueduration = @()0.5 ;               % 500ms                         // TRIGGER 30
timing2.feedbackduration = .3;                   % 300ms
timing2.response_release = .2;                   % 200ms
timing2.startofblock = 2; %wait for 2 seconds at the begining of each bloc ?

%% keyboard/buttons inputs
KbName('UnifyKeyNames');       % Set all the keyboard code
keywait = KbName('space');     % Break and restart current bloc
keystop = KbName('ESCAPE');    % Abort experiment
if ispc                        % 1 for PC (windows) versions of Matlab
    keyquit = KbName('BackSpace');
elseif ismac                   % 1 for MAC (Macintosh) versions of Matlab
    keyquit = KbName('DELETE'); 
end
keyconfirm = KbName('Return'); % Validation of the data
keyredo = KbName('r');         % Repeat
%keyresp = KbName({'q','m','s','l'});   % response buttons ('L' 'R' 'Up' 'Down)
keyresp = KbName({'a','p','s','l'});   % response buttons ('L' 'R' 'Up' 'Down)

% Lumina buttons codes(this section is not clear to me: Note JB...)
%  | B[49]     |  |     R[52] |
%  |�    Y[50] |  | G[51]     |
datresp = [49,52,50,51]; % codes of lumina response buttons (Left, Right,Up,Down)
lptresp = [4,8]; % codes of mouse buttons on parallel port (Left, Right)
logresp = [5,6,7,8]; % codes of logitech response buttons (Left, Right)
% Logitech gamepad : X=1 | A=2 | B=3 | Y=4 | LB=5 | RB=6 | LT=7 | RT=8 | Back=9 
% Logitech arri�re n position D !!! pour Logitech Dual Action

%% training parameters
training.ntrials = 5;%5 switch sequences?
training.switch_seq_number=2;%2 switch/volatility level during training
training.volatility=2;%use intermediate volatility for training ?
%% TASK difficulty: not very well documented (complete that info)
task_diff2=0.7;
%we may need two task_diff (don't know why: comment ?)
task_diff=0.5;


%% TOBII eye-tracker variable:
tobii=[];

%% screen/display parameters
lumibg          = 0.0;
ppd             = 80;

IOPort('CloseAll');

%% Enable triggering
% Open trigger port & define SendTrigger

if flags.parallel_triggers % Parallel port 
    if ispc % Windows
        CloseParPort;
        OpenParPort;
        param.hport_trig = [];
        param.fun.trig = @SendTrigger; % Usage : trigger(trig, hport_trig)
    end
    
elseif flags.serial_triggers % Serial port
    %IOPort('CloseAll')
    if IsWin % Windows
        %[param.hport_trig] = IOPort('OpenSerialPort',FindSerialPort());
        [param.hport_trig] = IOPort('OpenSerialPort','COM5');
    end
    IOPort('ConfigureSerialPort',param.hport_trig,'BaudRate=9600 Parity=None DataBits=8 StopBits=1');
    IOPort('Purge',param.hport_trig);
    param.fun.trigger = @SendTrigger; % Usage : trigger(trig, hport_trig)
    
else % No port
    % Do nothing on 'trigger' function calls
    param.hport_trig = [];
    param.fun.trigger = @(trig, hport_trig) []; % Usage : trigger(trig, hport_trig)
end


% %% % LUMINA buttons
if flags.with_response_lumina           % Open port to be used with LUMINA buttons
    if IsWin                                        % NB : Baud rate is set to 115200
        [hport_lum] = IOPort('OpenSerialPort','COM6'); % Mode should be 'ASCII/MEDx' on the LSC-400B Controller
    elseif IsLinux
        hport_lum = IOPort('OpenSerialPort','/dev/ttyS0');
    end
    IOPort('ConfigureSerialPort',hport_lum,'BaudRate=115200');
    IOPort('Purge',hport_lum);
else
    hport_lum = [];
end



%%
%TRIGGER INFO: 
%FIXATON TRIGGERS: 
% if stim_rule_type==1
%     trig.fix=volatility*10;%fixation code [10 20 30] for stim first
% else
%     trig.fix=volatility*10+5;%fixation code [15 25 35] for rule first
% end

%PRECUE TRIGGERS: =code of SIDE (or RULE ?)
% if stim_rule_type==1 %one central dot and two peripheral squares
%     trig_precue=trig_fix+side;%%[11 21 31] or... 12 22 32 for stim first
%     elseif stim_rule_type==2 %one central square and two peripheral dots
%     trig_precue=trig_fix+rule;%%[16 26 36 or... 17 27 37 for rule first
%  end

%CUE TRIGGER: should either code the RULE Type or the side (depends on
%stim_rule_type variable again)
% if stim_rule_type==1
%     trig.cue=trig.precue+rule*100; %stim first = [61 71 81] or... 62 72 82 for stim first
%     %for stim first
% else
%     trig.cue=trig.precue+side*100; %rule first = [66 76 86 or... 67 77 87 
% end