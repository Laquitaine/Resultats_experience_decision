
function varargout = switch_GUI(varargin) % DO NOT EDIT -------------------
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @switch_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @switch_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before switch_GUI is made visible. --------------------
function switch_GUI_OpeningFcn(hObject, ~, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

% Variables and parameters ------------------------------------------------
global switchfolder;
global participant;              % Define participant as a global variable
global validation; validation=0;
global text_fr text_en text_sv text_cs;


% Directory path ----------------------------------------------------------
PATHSTR_root = load('PATHSTR.mat');     % Load the directory path
switchfolder = PATHSTR_root.PATHSTR;    % Current code file path
cd(switchfolder);                       % Change current folder
[text_fr,text_en,text_sv,text_cs] = switch_text_structure('GUI');


 
% Setup of participant's information -----------------------------------
participant.date = datestr(now,...  
    'yyyy.mm.dd at HH:MM'); % Experiment day and hour 
participant.identifier = '';% Participant's name
participant.age='';         % Participant's age
participant.gender='';      % Participant's gender
participant.laterality='';  % Participant's laterality
participant.pathology = ''; % Participant's pathology
participant.city='';        % Participant's city
participant.recording = ''; % Participant's recording method
participant.trigger = ''; % Participant's trigger or not
participant.response = '';  % Participant's pathology
participant.session = 'training'; % Experiment name 
participant.hostname=hostname(); % Computer name
participant.language = 1;   % 0=anglais | 1=fran�ais | 2=suedois | 3=tcheque



% --- Outputs from this function are returned to the command line.
function varargout = switch_GUI_OutputFcn(~, ~, handles) 
varargout{1} = handles.output;

%========================================================================== 
% RADIO BUTTON
%==========================================================================
        % --- Executes on button press
function radiobutton_anglais_Callback(hObject, eventdata, handles)
function radiobutton_francais_Callback(~, ~, ~)
function radiobutton_suedois_Callback(~, ~, ~)
function radiobutton_tcheque_Callback(~, ~, ~)
function radiobutton_entrainement_Callback(~, ~, ~)
function radiobutton_experience1_Callback(~, ~, ~)
function radiobutton_experience_test_Callback(~, ~, ~)

%========================================================================== 
% EDIT
%==========================================================================

function edit_nom_Callback(~, ~, handles)
global participant;
participant.identifier = get(handles.edit_nom, 'String');

% --- Executes during object creation, after setting all properties.
function edit_nom_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_age_Callback(~, ~, handles)
global participant;
participant.age = get(handles.edit_age, 'String');

% --- Executes during object creation, after setting all properties.
function edit_age_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ville_Callback(~, ~, handles)
global participant;
participant.city = get(handles.edit_ville, 'String');

% --- Executes during object creation, after setting all properties.
function edit_ville_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%========================================================================== 
% POP-UP
%==========================================================================

% --- Executes on selection change in popup_pathologie.
function popup_pathologie_Callback(~, ~, handles)
global participant;
Value = get(handles.popup_pathologie,'Value');
participant.pathology = handles.popup_pathologie.String{Value};

% --- Executes during object creation, after setting all properties.
function popup_pathologie_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in popup_enregistrement.
function popup_enregistrement_Callback(~, ~, handles)
global participant;
Value = get(handles.popup_enregistrement,'Value');
participant.recording = handles.popup_enregistrement.String{Value};

% --- Executes during object creation, after setting all properties.
function popup_enregistrement_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in popup_trigger.
function popup_trigger_Callback(~, ~, handles)
global participant;
Value = get(handles.popup_trigger,'Value');
participant.trigger = handles.popup_trigger.String{Value};

% --- Executes during object creation, after setting all properties.
function popup_trigger_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in popup_reponse.
function popup_reponse_Callback(~, ~, handles)
global participant;
Value = get(handles.popup_reponse,'Value');
participant.response = handles.popup_reponse.String{Value};

% --- Executes during object creation, after setting all properties.
function popup_reponse_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in popup_sexe.
function popup_sexe_Callback(~, ~, handles)
global participant;
Value = get(handles.popup_sexe,'Value');
participant.gender = handles.popup_sexe.String{Value};

% --- Executes during object creation, after setting all properties.
function popup_sexe_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in popup_lateralite.
function popup_lateralite_Callback(~, ~, handles)
global participant;
Value = get(handles.popup_lateralite,'Value');
participant.laterality = handles.popup_lateralite.String{Value};

% --- Executes during object creation, after setting all properties.
function popup_lateralite_CreateFcn(hObject, ~, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





%========================================================================== 
% PUSH
%==========================================================================

% --- Executes on button press in push_validation.
function push_validation_Callback(~, ~, handles)
global participant; global validation; 
global text_fr text_en text_sv text_cs;
if ~isempty(participant.identifier)
    PATHSTR_root = load('PATHSTR.mat');
    switchfolder = PATHSTR_root.PATHSTR;             % Current code file path
    mkdir(fullfile(switchfolder,['Data\' participant.identifier]));
    addpath(fullfile(switchfolder,['Data\' participant.identifier]));
    participant.folder=switchfolder;
end
if participant.language==0,     text=text_en.GUI; % Anglais
elseif participant.language==1, text=text_fr.GUI; % Fran�ais
elseif participant.language==2, text=text_sv.GUI; % Suedois
elseif participant.language==3, text=text_cs.GUI; % Tch�que
end
if isempty(participant.gender),     participant.gender = text{25};      end
if isempty(participant.laterality), participant.laterality = text{27};  end
if isempty(participant.pathology),  participant.pathology = text{29};   end
if isempty(participant.city),       participant.city = text{46};        end
if isempty(participant.recording),  participant.recording = text{29};   end
if isempty(participant.trigger),    participant.trigger = text{38};     end
if isempty(participant.response)  
    participant.response = text{41};    
    participant.flags.with_response_lumina   = 0;   % Response Device = Lumina buttons
    participant.flags.with_response_mouse    = 0;   % Response Device = Mouse buttons
    participant.flags.with_response_keyboard = 1;   % Response Device = Keyboard letters
    participant.flags.with_response_logitech = 0;   % Response Device = Logitech buttons
end
if isempty(participant.identifier)...
    || isempty(participant.age),    set(handles.text_information, 'String',text{44});
else, handles.text_information.String = sprintf(...
        ' - %s : %s \n - %s : %s \n - %s : %s \n - %s : %s \n - %s : %s \n - %s : %s \n\n - %s : %s \n - %s : %s \n - %s : %s',...
        text{7},participant.identifier,text{8},participant.age,text{9},participant.gender,...
        text{10},participant.laterality,text{11},participant.pathology,text{12},participant.city,...
        text{14},participant.response,text{15},participant.trigger,text{16},participant.recording);
        validation=1;
end  

if strcmp(participant.trigger,'Port Serie') || strcmp(participant.trigger,text{39})
    flags.serial_triggers=1;        % 0: parrallel port/1=serial port (which is used for LUMINA buttons)
    flags.parallel_triggers=0;      % send triggers on parallel port
elseif strcmp(participant.trigger,'Port Paral') || strcmp(participant.trigger,text{40})
    flags.serial_triggers=0;
    flags.parallel_triggers=1;
elseif strcmp(participant.trigger,'Aucun port') || strcmp(participant.trigger,'None ports') || strcmp(participant.trigger,text{38})
    flags.serial_triggers=0;
    flags.parallel_triggers=0;
end
if strcmp(participant.response,'Clavier') || strcmp(participant.response,'Keybrd.') || strcmp(participant.trigger,text{41})
    flags.with_response_lumina   = 0;   % Response Device = Lumina buttons
    flags.with_response_mouse    = 0;   % Response Device = Mouse buttons
    flags.with_response_keyboard = 1;   % Response Device = Keyboard letters
    flags.with_response_logitech = 0;   % Response Device = Logiteck buttons
elseif strcmp(participant.response,'Lumina.') || strcmp(participant.trigger,text{42})
    flags.with_response_lumina   = 1;   % Response Device = Lumina buttons
    flags.with_response_mouse    = 0;   % Response Device = Mouse buttons
    flags.with_response_keyboard = 0;   % Response Device = Keyboard letters
    flags.with_response_logitech = 0;   % Response Device = Logiteck buttons
elseif strcmp(participant.response,'Logitch') || strcmp(participant.trigger,text{43})
    flags.with_response_lumina   = 0;   % Response Device = Lumina buttons
    flags.with_response_mouse    = 0;   % Response Device = Mouse buttons
    flags.with_response_keyboard = 0;   % Response Device = Keyboard letters
    flags.with_response_logitech = 1;   % Response Device = Logiteck buttons
else
    flags.with_response_lumina   = 0;   % Response Device = Lumina buttons
    flags.with_response_mouse    = 1;   % Response Device = Mouse buttons
    flags.with_response_keyboard = 0;   % Response Device = Keyboard letters
    flags.with_response_logitech = 0;   % Response Device = Logiteck buttons
end
participant.flags=flags;    % Save experiment flags
run('switch_TaskParameters.m'); % Parameters importation
participant.flags=flags;    % Save experiment flags


   
% --- Executes on button press in push_demarrer.
function push_demarrer_Callback(~, ~, handles)
global participant; global validation; global DEBUG;
global text_fr text_en text_sv text_cs;
if isempty(DEBUG)
    DEBUG = false;
elseif DEBUG  
    flags.with_response_keyboard = 1;
end
if participant.language==0,     text=text_en.GUI; % Anglais
elseif participant.language==1, text=text_fr.GUI; % Fran�ais
elseif participant.language==2, text=text_sv.GUI; % Suedois
elseif participant.language==3, text=text_cs.GUI; % Tch�que
end

if not(validation)
    set(handles.text_information, 'String',text{45});

elseif (participant.session=='training')
    try
        %[Passation,Passation.ErrorMsg] = switch_Tutorial(participant);
        %[Passation,Passation.ErrorMsg] = switch_Training(participant);
        [Passation,Passation.ErrorMsg] = switch_Training_v2(participant);
        %[Passation,Passation.ErrorMsg] = switch_Training_v2_photoD(participant);
        
        COMMENT = inputdlg('ANY COMMENTS ?','',5);  % Need to add a comment ?
        save([Passation.Filename '_Comments'],'COMMENT');         % Save the comment
        if ~isempty(Passation.ErrorMsg)             % Display the error
            disp(Passation.ErrorMsg); psychrethrow(Passation.ErrorMsg); 
        end
 
    catch ME                % Execution if an error occurs in "try" section
        Priority(0);        % 0 is "normal priority level"
        Screen('CloseAll'); % Close screens, windows, textures, videos
        PsychPortAudio('Close'); % Close a PortAudio audio device
        FlushEvents;        % Remove events from the system event queue
        ListenChar(0);      % 0 = stop listening to keyboard input
        ShowCursor;         % re-displays the mouse after a "HideCursor"
        video = [];
        disp(ME)            % Display command
        rethrow(ME);        % Reissue error
        return
    end

elseif (participant.session=='exprmnt1')
    try
        %[Passation,Passation.ErrorMsg] = switch_Experiment_v1(participant); % Variable interval
        [Passation,Passation.ErrorMsg] = switch_Experiment_v2(participant); % Variable interval
        %[Passation,Passation.ErrorMsg] = switch_Experiment_v2_photoD(participant); % Variable interval
        COMMENT = inputdlg('ANY COMMENTS ?','',5);  % Need to add a comment ?
        save([Passation.Filename '_Comments'],'COMMENT');         % Save the comment
        if ~isempty(Passation.ErrorMsg)             % Display the error
            disp(Passation.ErrorMsg); psychrethrow(Passation.ErrorMsg); 
        end
 
    catch ME                % Execution if an error occurs in "try" section
        Priority(0);        % 0 is "normal priority level"
        Screen('CloseAll'); % Close screens, windows, textures, videos
        PsychPortAudio('Close'); % Close a PortAudio audio device
        FlushEvents;        % Remove events from the system event queue
        ListenChar(0);      % 0 = stop listening to keyboard input
        ShowCursor;         % re-displays the mouse after a "HideCursor"
        video = [];
        disp(ME)            % Display command
        rethrow(ME);        % Reissue error
        return
    end
elseif (participant.session=='exprmntX')
    try
        [Passation,Passation.ErrorMsg] = switch_1min_Up_Down(participant); % Test signal Up and Down display
        COMMENT = inputdlg('ANY COMMENTS ?','',5);  % Need to add a comment ?
        save([Passation.Filename '_Comments'],'COMMENT');         % Save the comment
        if ~isempty(Passation.ErrorMsg)             % Display the error
            disp(Passation.ErrorMsg); psychrethrow(Passation.ErrorMsg); 
        end
 
    catch ME                % Execution if an error occurs in "try" section
        Priority(0);        % 0 is "normal priority level"
        Screen('CloseAll'); % Close screens, windows, textures, videos
        PsychPortAudio('Close'); % Close a PortAudio audio device
        FlushEvents;        % Remove events from the system event queue
        ListenChar(0);      % 0 = stop listening to keyboard input
        ShowCursor;         % re-displays the mouse after a "HideCursor"
        video = [];
        disp(ME)            % Display command
        rethrow(ME);        % Reissue error
        return
    end
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes when selected object is changed in group_langue.
% Change the language of the GUI
% -------------------------------------------------------------------------
function group_langue_SelectionChangedFcn(hObject, ~, handles)
global participant;
global text_fr text_en text_sv text_cs;
if (hObject == handles.radiobutton_anglais)
    participant.language = 0; 
    text=text_en.GUI;
elseif (hObject == handles.radiobutton_francais)
    participant.language = 1; 
    text=text_fr.GUI;    
elseif (hObject == handles.radiobutton_suedois)
    participant.language = 2; 
    text=text_sv.GUI;   
elseif (hObject == handles.radiobutton_tcheque)
    participant.language = 3; 
    text=text_cs.GUI;  
end       

set(handles.group_langue,'Title',text{1});
set(handles.radiobutton_anglais, 'String', text{2});
set(handles.radiobutton_francais, 'String', text{3});
set(handles.radiobutton_suedois, 'String', text{4});
set(handles.radiobutton_tcheque, 'String', text{5});
set(handles.panel_participant,'Title',text{6});
set(handles.text_nom, 'String', text{7});
set(handles.text_age, 'String', text{8});
set(handles.text_sexe, 'String', text{9});
set(handles.text_lateralite, 'String', text{10});
set(handles.text_pathologie, 'String', text{11});
set(handles.text_ville, 'String', text{12});
set(handles.panel_experience,'Title',text{13});
set(handles.text_reponse, 'String', text{14});
set(handles.text_trigger, 'String', text{15});
set(handles.text_enregistrement, 'String', text{16});
set(handles.push_validation, 'String', text{17});
set(handles.panel_resultats,'Title',text{18});
set(handles.group_session,'Title',text{19});
set(handles.radiobutton_entrainement, 'String', text{20});
set(handles.radiobutton_experience1, 'String', text{21});
set(handles.radiobutton_experience_test, 'String', text{22});
set(handles.push_demarrer, 'String', text{23});
set(handles.edit_nom,'String',text{24});
set(handles.edit_age,'String',text{24}); 
set(handles.popup_sexe,'String',{text{25},text{26}});
set(handles.popup_lateralite,'String',{text{27},text{28}});
set(handles.popup_pathologie,'String',{text{30},text{31},text{32},text{33}});
set(handles.popup_enregistrement,'String',{text{29},text{34},text{35},text{36},text{37}});
set(handles.popup_trigger,'String',{text{38},text{39},text{40}});
set(handles.popup_reponse,'String',{text{41},text{42},text{43}});



% --- Executes when selected object is changed in group_session.
function group_session_SelectionChangedFcn(hObject, ~, handles)
global participant;
if (hObject == handles.radiobutton_entrainement)
    participant.session = 'training';
elseif (hObject == handles.radiobutton_experience1)
    participant.session = 'exprmnt1';
elseif (hObject == handles.radiobutton_experience_test)
    participant.session = 'exprmntX';
end
