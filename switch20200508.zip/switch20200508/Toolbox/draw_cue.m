%==========================================================================
% Function : draw_cue
%==========================================================================

function draw_cue_x4(video,rule,cue_colors,side,cue_Xpos)
 if side==1 %adjust cue color
                    Screen('FillRect', video.h, cue_colors(:,:,rule), cue_Xpos); %this takes either the first or second color_codes
 elseif side==2
                    Screen('FillRect', video.h, cue_colors(:,:,rule+side), cue_Xpos);%this takes either the third or fourth color_codes
 end
 Screen('DrawingFinished',video.h); % No more drawing before the next Screen('Flip' or 'AsyncFlipBegin')
 
 % windowPtr = video.h