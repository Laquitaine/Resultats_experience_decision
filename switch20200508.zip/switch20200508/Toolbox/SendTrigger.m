%% Envoi des triggers

function trig = SendTrigger(trig,hport_trig)
if isempty(hport_trig) % Parallel port
    if ispc % Windows
        WriteParPort(trig);
        WaitSecs(0.010);
        WriteParPort(0);
    end
else % Serial port
    IOPort('Write', hport_trig, uint8(trig)); %char(trig)); % Avec char les codes 128, 130 -> 140, 142, 145 -> 156, 158 et 159 sont transform�s en trigger = 26 avec SystemPLUS
end
end