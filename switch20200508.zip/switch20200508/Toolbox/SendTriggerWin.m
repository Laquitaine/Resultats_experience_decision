%==========================================================================
% Function : SendTriggerWin
%==========================================================================

function trig=SendTriggerWin(trig,~) %parrallel port code
WriteParPort(trig);
WaitSecs(0.010);
WriteParPort(0);