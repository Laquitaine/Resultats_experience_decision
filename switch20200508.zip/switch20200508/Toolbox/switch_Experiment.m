%==========================================================================
% Function : switch_Experiment
%==========================================================================

function [Passation,errormsg] = switch_Experiment(participant)

% Initialisation of Passation
%==========================================================================
% Definition of Passation DEBUG, Running, TaskParameters, Runner,
% Participant, DataFolder, Filename
%--------------------------------------------------------------------------
global DEBUG                               % Define DEBUG as a global variable
global Points;
global mean_rt;
rt2=[];
mean_rt=[];
Passation=[];                              % Define Passation
errormsg =[];                              % Define errormsg
Passation.DEBUG = DEBUG;                   % Define Passation.DEBUG
Passation.Running = dbstack;               % File information (file:Name.m ; name:Name ; line:999)
for i=1:length(Passation.Running)
    Passation.Running(i).fullpath = which(Passation.Running(i).file); % File location (C:\Users\Name\Documents\File.m)
    Passation.Running(i).filedate = getfield(dir(Passation.Running(i).fullpath),'date'); % Saving date (16-oct.-2018 15:07:49)
    Passation.Running(i).mcode    = ...    % Copy all the actual script
        textread(Passation.Running(i).fullpath,'%s','delimiter','\n');           
end
run('switch_TaskParameters');             % Define various parameters
Passation.TaskParameters = ...             % Copy all the TaskParameter script
    textread(which('switch_TaskParameters'),'%s','delimiter','\n');
Passation.Runner = ...                     % Copy all the Runner script
    textread(which('switch_Runner'),'%s','delimiter','\n');
Passation.Participant = participant;
Passation.DataFolder = fullfile(participant.folder,'Data',participant.identifier);
%Passation.DataFolder = fullfile(...        % Current code file path 
%    fileparts(mfilename('fullpath')),...   %(C:\Users\Name\Documents\)
%    'data', ...                            % + \data
%    participant.identifier);               % + \Participant_name
if not(exist(Passation.DataFolder, 'dir')) % Saving data folder exist or not
    if DEBUG
        Passation.DataFolder = fullfile(fileparts(tempname)); % DEBUG => Save in temporary folder
    else
        error('switch:MssingDataFolder','Missing data folder! %s\n', Passation.DataFolder);
    end
end
Passation.Filename=fullfile(...            % Define the filename to save the info
    Passation.DataFolder,sprintf('switch_%s_%s',... % like 
    datestr(now,'yyyymmdd-HHMM'),...       % Datafolder\switch_20181017-1038_lfp
    participant.session));


% Save Diary (in ...\switch\data\TEST\switch_20181017-1038_lfp)
%==========================================================================
diary(Passation.Filename) % DIARY ON = begining of saving
fprintf('\n'); 
fprintf('=======================================\n');
fprintf('======= START OF THE EXPERIMENT =======\n');
fprintf('=======================================\n');
fprintf('\n');

% Configuarion
%==========================================================================
% Set important design parameters
%--------------------------------------------------------------------------
num_bloc = 4; % ideally, we would perform 4 blocs of switch trials (duration is about 1h)
stim_rule_type_blocs = [1 2 1 2 1 2];% stim_rule_type_blocs=stim_rule_type_blocs(randperm(num_bloc));%1=rule after; 2=rule before
bloc_volatility_order = [1 2 3 ; 1 3 2 ; 2 3 1 ; 2 1 3 ; 3 1 2 ; 3 2 1];
bloc_volatility_order = bloc_volatility_order(randperm(num_bloc),:); % Random permutation of line order
n_trials_within_volatility = 18;%should be a multiple of three and two
% task_diff=0.5; %500 ms = initial task difficulty (good for training; not so good for experimental sessions)?

% Randomize number of non-switch trials for each volatility in a bloc
%--------------------------------------------------------------------------
num_nsw=[];                                                  % Definition
num_nsw(:,1)=repmat([3 4 5],1,n_trials_within_volatility/3); % Column 1 [3 4 5...]
num_nsw(:,1)=num_nsw(randperm(length(num_nsw(:,1))),1);      % Randomized column 1
num_nsw(:,2)=repmat([4 5 6],1,n_trials_within_volatility/3); % Column 2 [4 5 6...]
num_nsw(:,2)=num_nsw(randperm(length(num_nsw(:,2))),2);      % Randomized column 2
num_nsw(:,3)=repmat([5 6 7],1,n_trials_within_volatility/3); % Column 3 [5 6 7...]
num_nsw(:,3)=num_nsw(randperm(length(num_nsw(:,3))),3);      % Randomized column 1

% Number of trials within a bloc
%--------------------------------------------------------------------------
ntrials=sum(num_nsw(:))+(size(num_nsw,1)*size(num_nsw,2)); % number of nsw + number of switch

% Initialisation of Psychtoolbox
%==========================================================================
% Open the Psychtoolbox and display various general information about the
% experiment (participant, exp. condition, keyboard inputs)
%--------------------------------------------------------------------------
if participant.flags.with_fullscreen
    video = OpenPTBScreen([]);             % Screen Definition
else
    video = OpenPTBScreen;
end                                        
if DEBUG                                   % #03 DEBUG mode display and wait for keyboard input
    DrawFormattedText(video.h, 'DEBUG MODE', 'center', 'center', 1); Screen('Flip', video.h); KbStrokeWait;
end


% Initialisation of I/O ports
%==========================================================================
IOPort('CloseAll'); % Close all input/output (USB, serial, parallel..etc)

% LUMINA buttons
if participant.flags.with_response_lumina           % Open port to be used with LUMINA buttons
    if IsWin                                        % NB : Baud rate is set to 115200
        [hport] = IOPort('OpenSerialPort','COM10'); % Mode should be 'ASCII/MEDx' on the LSC-400B Controller
    elseif IsLinux
        hport = IOPort('OpenSerialPort','/dev/ttyS0');
    end
    IOPort('ConfigureSerialPort',hport,'BaudRate=115200');
    IOPort('Purge',hport);
else
    hport = [];
end

% With triggers
if participant.flags.with_triggers  % Open trigger port & define sendtrigger
    if ispc && participant.flags.serial_triggers==0
        %PARRALLEL PORT CASE: to be coded !!!
        CloseParPort;
        OpenParPort;
        hp2=[];
        trigger = @(trig,hp2) SendTriggerWin(trig,hp2);
        %SERIAL PORT CASE:
    elseif ispc && participant.flags.serial_triggers==1
        [hp2] = IOPort('OpenSerialPort','COM8');  % COMxx is the name of the port in window setup panel  
        IOPort('ConfigureSerialPort',hp2,'BaudRate=9600'); % adjust according to windows setup panel value
        IOPort('Purge',hp2);
        trigger = @(trig,hp2) SendTriggerWin2(trig,hp2);
    elseif IsLinux
        trigger = @(trig) SendTriggerLinux(trig);
    end 
else 
    trigger = @(x)[]; % Do nothing on trigger() function calls
end


 if ~DEBUG         % Remove keyboard outputs to matlab screen: REMOVED BY JB TO DEBUG...
    HideCursor;    % Hide the mouse cursor
    FlushEvents;   % Remove events from the system even queue
    ListenChar(2); % 2 = listen to keyboard input and supress any output of keypresses
end


%==========================================================================
% Important section: defines the structures within and between blocs of
% trials. Store information in Passation.Data=Data;
%--------------------------------------------------------------------------

% Stimuli defintion
%==========================================================================
% STEP 1 : 20 pixel white fixation dot at screen center
% STEP 2 : rule or pre-cue display
%    2.1 : pre-cue (stim type) trials = first display peripheric pre-cues
%          and then the central rule
%    2.2 : pre-cue (rule type) trials = first display central rule and then
%          peripheric pre-cues (see the papers of Buchman and Miller in
%          Neuron)
% STEP 3 : 3 squares (stim+rule)
%--------------------------------------------------------------------------
% #1
fix_dot_Xpos = video.xCenter;                             % Center X position in pixels
fix_dot_Ypos = video.yCenter;                             % Center Y position in pixels

% #2.1
baseRect = [0 0 cue_size cue_size];                       % Rect dimension of 50 by 50 pixels
pre_cue_Xpos_tmp = [video.x*0.25, video.x*0.75];          % Screen X positions of the two pre-cue rectangles  % Adjust x coordinates of both pre-cues
pre_cue_Xpos_stim = nan(4, length(pre_cue_Xpos_tmp));     % Create a matrix for all the squares (4,:)
for i = 1:length(pre_cue_Xpos_tmp)                        % that contains (xmin,ymin,xmax,ymax) of each square
    pre_cue_Xpos_stim(:, i) = CenterRectOnPointd(baseRect, pre_cue_Xpos_tmp(i), video.yCenter); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues
pre_cue_colors(:,:,1)=[1 0 1; 1 1 0]';                    % magenta left; yellow right
pre_cue_colors(:,:,2)=[1 1 0;1 0 1 ]';                    % yellow left ; magenta right

% #2.2
pre_cue_Xpos_rule = CenterRectOnPointd(baseRect, video.x*0.5, video.yCenter);%
pre_cue_rule_color=[1 0 1; 1 1 0]';                       % first colomn= rule= magenta; second= yellow

% #3
cue_Xpos_tmp = [video.x*0.25, video.x*0.5, video.x*0.75]; % Screen X positions of our three rectangles
cue_Xpos = nan(4, length(cue_Xpos_tmp));                  % Create a matrix for all the squares (4,:)
for i = 1:length(cue_Xpos_tmp)                            % that contains (xmin,ymin,xmax,ymax) of each square
    cue_Xpos(:, i) = CenterRectOnPointd(baseRect, cue_Xpos_tmp(i), video.yCenter); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues (dirty code...)
cue_colors(:,:,1)=[1 0 1;1 0 1; 1 1 0]';                  % magenta left; yellow right; rule = magenta
cue_colors(:,:,2)=[1 0 1;1 1 0; 1 1 0]';                  % magenta left; yellow right; rule = yellow
cue_colors(:,:,3)=[1 1 0;1 0 1; 1 0 1]';                  % yellow left ; magenta right; rule = magenta
cue_colors(:,:,4)=[1 1 0;1 1 0; 1 0 1]';                  % yellow left ; magenta right; rule = yellow
% % %        cue_colors choice depends on both cue and side codes: is between 1 and 4
% % %        cue_color code=1 or 2 si rule = 0 par exemple mais = 3 ou 4 si on multiplie side par rule

%%%%%%%%%%%%%%%%%%%%

% Loop over the blocks
% stopped = false;
% nextblock = true;

% Snd('Open'); % Open the sound channel until Snd('Close') -- maybe change this line (see Psychotoolbox help)
InitializePsychSound(1)                 % Initialize Sounddriver
Snd_channel = 2;                       % Number of channels
Snd_freq = 48000;                       % Frequency of the sound
pahandle = PsychPortAudio('Open', [], 1, 1, Snd_freq, Snd_channel);
PsychPortAudio('Volume', pahandle, 0.5); % Set the volume

if(1)
    
% #01 Display and wait for keyboard input
DrawFormattedText(video.h, 'START OF THE EXPERIMENT', 'center', video.y*0.4, 1); 
DrawFormattedText(video.h, ['Press "' KbName(keyconfirm) '" to continue'], 'center', video.y*0.9, 0.5); 
Screen('Flip', video.h); %WaitKeyPress(keyconfirm);
key = WaitKeyPress([keyconfirm keystop]);
if isequal(key,2)
    sca;
end


% LOOP 1 --- from 1 to num_bloc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for blocidx=1:num_bloc %befor this was : while seqidx <= nseq && nextblock %this should clearly be modified for switch
    
    stim_rule_type=stim_rule_type_blocs(blocidx); % [1} rule is before or [2] after the stimulus
    Points = 0;
    
    % If Rule after the stimulus (relax temporal pressur if rule is before stimulation)
    %----------------------------------------------------------------------
    if stim_rule_type==2 
            task_diff=task_diff2;
    end
    
    % If trainig mode activated
    %----------------------------------------------------------------------
    is_training = false; % Training data set
    if participant.flags.with_training
        is_training = true;
        ntrials = training.ntrials; % defined in task parameters
        % modify this section for training code, please: TO DO JB
        %     Data.Target    = num2cell(randi(2),2)';
        %     Data.Side      = num2cell(randi(2),2)';
    end
    

    itrial_data=0; % initialize this before the first trial of a bloc;
    
    % Prepare the LogFile and the logging variables (TO BE DEFINED, ALSO)
    %----------------------------------------------------------------------
    
    % Cell definition for num_bloc blocs to save the data in
    response = [];                              % Definition of response
    timecode = [];                              % Definition of timecode
    timecode.fix_onset  = cell(1,num_bloc);     % onset of fixation
    timecode.fix_offset = cell(1,num_bloc);     % offset of fixation
    timecode.precue_onset = cell(1,num_bloc);   % onset of precue (stim or rule)
    timecode.precue_offset = cell(1,num_bloc);  % offset of precue
    timecode.cue_onset = cell(1,num_bloc);      % onset of cue (stim or rule)
    timecode.cue_offset = cell(1,num_bloc);     % offset of cue
    timecode.resp_press = cell(1,num_bloc);     % button press
    timecode.resp_release = cell(1,num_bloc);   % button release
    timecode.feedback_onset= cell(1,num_bloc);  % feedback display on
    timecode.feedback_offset= cell(1,num_bloc); % feedback display off 
    
    % Array definition for 1 bloc to save the data in
    response.resp{blocidx}  = NaN*zeros(1,ntrials); % Response
    response.rt{blocidx}   = NaN*zeros(1,ntrials);  % Reaction Time (RT)
    response.accu{blocidx} = NaN*zeros(1,ntrials);  % Accurate
    timecode.fix_onset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.fix_offset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.precue_onset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.precue_offset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.cue_onset{blocidx} = NaN*zeros(1,ntrials);
    timecode.cue_offset{blocidx} = NaN*zeros(1,ntrials);
    timecode.resp_press{blocidx}  = NaN*zeros(1,ntrials);
    timecode.resp_release{blocidx}= NaN*zeros(1,ntrials);
    timecode.feedback_onset{blocidx}= NaN*zeros(1,ntrials);
    timecode.feedback_offset{blocidx}= NaN*zeros(1,ntrials);
    
    %We obviously also need to monitor, for each trial some event codes: 
    % side, rule, stim_rule_type, volatility, SW/NSW, correct/incorrect (NOT DONE YET)
    
    Passation.Data.Trials.stim_rule_type{blocidx} = NaN*zeros(1,ntrials);  % 1=rule after; 2=rule before
    Passation.Data.Trials.side{blocidx}   = NaN*zeros(1,ntrials);          % 1=MAGENTA left; 2=YELLOW left ??
    Passation.Data.Trials.rule{blocidx} = NaN*zeros(1,ntrials);            % 1=MAGENTA; 2=YELLOW  ??
    Passation.Data.Trials.volatility{blocidx} = NaN*zeros(1,ntrials);      % 1-3 low to high
    Passation.Data.Trials.switch{blocidx} = NaN*zeros(1,ntrials);          % 1 or 2 for NSW-SW
    Passation.Data.Trials.td{blocidx}=NaN*zeros(1,ntrials);                % 1 or 2 for NSW-SW ??
  
    
    % STEP 1:  start a new bloc of trials display 
    %----------------------------------------------------------------------
    fprintf('\n'); 
    fprintf('============== NEW BLOC ==============\n');
    fprintf('\n');
    DrawFormattedText(video.h, ['Bloc ' num2str(blocidx) ' is ready !'], 'center', video.y*0.4, 1); 
    DrawFormattedText(video.h, ['Press "' KbName(keywait) '" to START    or    "' KbName(keyquit) '" to STOP !'], 'center', video.y*0.9, 0.5); 
    Screen('Flip', video.h);
    key = WaitKeyPress([keywait keyquit]);
    
    % If key = KEYQUIT which is the 2nd choice possible in key
    %----------------------------------------------------------------------
    if isequal(key,2) % 
        DrawFormattedText(video.h, 'Do you really want to stop the experiment ?', 'center', video.y*0.4, 1);
        DrawFormattedText(video.h, [KbName(keyconfirm) ' YES    /    NO ' KbName(keystop) ], 'center', video.y*0.9, 0.5);
        Screen('Flip', video.h);
        key = WaitKeyPress();
        if isequal(key,keyconfirm)
            nextblock = false;
            stopped = true;
            break;
        end
    end
    
    % Dead time before starting the block
    if ~DEBUG
        WaitSecs(timing.startofblock);
    end
    
    % Parallel port back to 0
    if participant.flags.with_triggers
%         WriteParPort(0);
%         WaitSecs(0.2);
%         fprintf('Sending BLOCK #%d code ', blocidx);
    end
    
    % Next task: set the side, rule and general trial organisation within this bloc
    % HERE PRESENT THE TRIALS    
    % FOR DEBUG ONLY: one volatility bloc !!!
    
    % LOOP 2 --- from 1 to 3 (max volatility level)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for volatility_level=1:3
        
        volatility=bloc_volatility_order(blocidx,volatility_level);%1: low; 2=mid; 3=HIGH
        %NOTE FOR LATTER perhaps should be consider to provide a short brake between volatility levels
        num_nsw_vl=num_nsw(:,volatility);                          % number of non-switch within a given volatility level
        rules=repmat([1 2],1,n_trials_within_volatility/2);        % here we make sure that the rule will change between the 18 trials
        pseudo_rd=randperm(length(rules));                         % Randomize the index to get the adequate response
        %% a) the switch trial will either correspond to the same response than the previous non-switch in 33 % of trials
        same_resp_idx=pseudo_rd(1:round(length(rules)*0.33));%%for same response_switch type, we will just have to adjust the side
%         other_resp_idx=pseudo_rd(round(length(rules)*0.33)+1:end);%TO fo this, we also need to know the last_non_switch side
        switch_seq_number=length(num_nsw_vl);
        if is_training
            switch_seq_number=training.switch_seq_number;
            volatility=training.volatility;
        end
        
        % LOOP 3 --- from 1 to n_trials_within_volatility 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for switch_seq=1:length(num_nsw_vl) %18 "sequences of trials"/level of volatility
            numtrial=num_nsw_vl(switch_seq)+1;%number of trials = number of non-switch +1
            %             stim_rule_type=stim_rule_types(switch_seq);
            rule=rules(switch_seq);%will change if trial=num_trial

            % dirty code to randomize the side of the response :
            sides=repmat([1 2],1,round(numtrial/2));%Here I set a sequence of sides 
            sides=sides(randperm(length(sides))); %randomize the side
            
            % LOOP 4 --- from 1 to numtrials NSW+SW
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                
            %% Important loop over nsw+SW trials
             for itrial=1:numtrial %Loop over trials within agiven non-switch+switch sequence NOW
                itrial_data=itrial_data+1;
                 %% Parameters for switch same vs. different responses+ SW-NSW
                if itrial<numtrial
                    side=sides(itrial);%c�t� = al�atoire
                    Passation.Data.Trials.switch{itrial_data}=1;%non-switch trials
                elseif itrial==numtrial %% SWITCH TRIAL = rule change
                    Passation.Data.Trials.switch{itrial_data}=2; %switch trials
                    if rule==1  % Rule change (1->2) in the switch case
                        rule=2;
                    elseif rule==2 % Rule change (2->1) in the switch case
                        rule=1;
                    end
                    if ismember(switch_seq,same_resp_idx) %Same response 
                        %= update SIDE during SWitch
                        if side==1
                            side=2;
                        elseif side==2
                            side=1;
                        end
                    else
                        %don't update side variable to set a new response
                    end
                end
                
         %% Monitor few interesting event codes for the logfile
        Passation.Data.Trials.stim_rule_type{itrial_data}=stim_rule_type;
        Passation.Data.Trials.volatility{itrial_data}=volatility;
        Passation.Data.Trials.side{itrial_data}=side;
        Passation.Data.Trials.rule{itrial_data}=rule;   
        Passation.Data.Trials.td{itrial_data}=task_diff;

        %% OK: THERE IT's TIME TO PRESENT ONE TRIAL--------------------------
        
         %% 1. DISPLAY FIXATION POINT + SEND TRIGGER + record logfile data
                % Points
                DrawFormattedText(video.h, ['POINTS :' num2str(Points)] ,0.1*video.x,0.1*video.y, 0.5);
                % central dot - placeholder for rule
                Screen('DrawDots', video.h, ...
                    [fix_dot_Xpos fix_dot_Ypos], fix_dot_SizePix,...
                    fix_dot_Color, [0 0], 2);
               % Left/Rigth dots - placeholder for colored stim
                Screen('DrawDots', video.h, ...
                    [pre_cue_Xpos_tmp ; fix_dot_Ypos fix_dot_Ypos],...
                    [fix_dot_SizePix fix_dot_SizePix], ...
                    [fix_dot_Color'  fix_dot_Color'], [0 0], 2);  
                Screen('DrawingFinished',video.h);
                % Display / get the time 
                tonset_fix = Screen('Flip',video.h);  %get the initial time stamp (not sure when to do this)
                timecode.fix_onset{itrial_data} = tonset_fix;%LOGFILE DATA:fixation onset
                %FIXATION TRIGGERS
                if stim_rule_type==1
                    trig.fix=volatility*10;%fixation code [10 20 30] for stim first
                else
                    trig.fix=volatility*10+5;%fixation code [15 25 35] for rule first
                end
                if participant.flags.with_triggers
                   trigger(trig.fix,hp2);%fixation code [15 25 35] for rule first
                end
                %%%%%%%%%%%%%%%%%%%%%%
                toffset_fix = Screen('Flip',video.h,tonset_fix+roundfp(timing.fixduration(),video.ifi));%next flip = end of fixation...
                timecode.fix_offset{itrial_data}  = toffset_fix;  %LOGFILE DATA
               
                
         %% 2. Display pre-cue (fix+pre-cue or rule+pre-cues_absent)
                
                %2.1 DRAWING
                [trig.precue]=draw_precue(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                 pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Xpos_rule,rule,trig.fix);
                
                %2.2 DISPLAY, trigger and logfile
                %a) get one time stamp to synch with screen
                vbl = Screen('Flip',video.h,toffset_fix); %displaying the pre-cue at this exact timing (tonset_precue)
                if participant.flags.with_triggers
                    trigger(trig.precue,hp2);  % Send trigger right after pre-cue stimulus display
                end
                timecode.precue_onset{itrial_data} = vbl;
                
                % Now we present the precue + we abort the trial in case of premature resp
                precueTimeFrames=round(timing.precueduration()/video.ifi); waitframes=1; 
                resp = 0;frame=0;
                
% % %  Clear the response button port, to collect response
        if participant.flags.with_response_lumina
            IOPort('Purge',hport);
        end
% % %         
                while resp==0 && frame<(precueTimeFrames - 1)   %% check for responses during pre-cue drawings
                    for frame = 1:precueTimeFrames - 1
                        if ~resp && participant.flags.with_response_keyboard
                            [resp,t]=CheckKeyPress(keyresp);
                            if resp
                                if participant.flags.with_triggers
                                    trigger(resp,hp2);%
                                end
                                break %
                            end
                        end
                        
                        if ~resp && participant.flags.with_response_lumina
                            [dat, t] = IOPort('Read',hport);
                            t = t(1);
                            if ~isempty(dat) && ismember(dat(1),datresp)
                                resp = find(datresp == dat(1));%this means a response ?
                                %CHECK LUMINA RESPONSE HERE:
                                if participant.flags.with_triggers
                                    trigger(resp,hp2);%
                                end
                                break %
                            end
                        end
                        % Draw the precue (if no response occured)
                        [trig.precue]=draw_precue(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                 pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Xpos_rule,rule,trig.fix);
                        vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi);
                    end
                end
               timecode.precue_offset{itrial_data}  = vbl;   
                
                
         %% 3. DISPLAY cue (always RULE+STIM)
                % Points
                DrawFormattedText(video.h, ['POINTS :' num2str(Points)] ,0.1*video.x,0.1*video.y, 0.5);
                %DRAWING the CUE
                draw_cue(video,rule,cue_colors,side,cue_Xpos)

                %Display the RULE for one time stamp first+send trigger
                vbl = Screen('Flip',video.h,vbl); 
                if participant.flags.with_triggers
                    if stim_rule_type==1
                        trig.cue=trig.precue+rule-1+30;
                    else
                       trig.cue=trig.precue+side-1+30;
                    end
                    trigger(trig.cue,hp2);             %         % Send trigger right after pre-cue stimulus display
                end
                timecode.cue_onset{itrial_data} = vbl;
                
    % Now we present the cue while monitoring response (cue disappears in
    % that case ?
    cueTimeFrames=round(timing.cueduration()/video.ifi);frame=0;
    while resp==0 && frame<(cueTimeFrames - 1)  %% check for responses during pre-cue drawings
        for frame = 1:cueTimeFrames - 1            
            if ~resp && participant.flags.with_response_keyboard
                [resp,t]=CheckKeyPress(keyresp);
                if resp
                    if participant.flags.with_triggers
                        trigger(resp,hp2);%1= left 2=right
                    end
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_lumina
                [dat, t] = IOPort('Read',hport);
                t = t(1);
                if ~isempty(dat) && ismember(dat(1),datresp)
                    resp = find(datresp == dat(1));%this means a response ?
                    if participant.flags.with_triggers
                        trigger(resp,hp2);%
                    end
                    break %
                end
            end
            
            
            % Draw the cue (if no response occured)
            draw_cue(video,rule,cue_colors,side,cue_Xpos)
            % Flip to the screen
            vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi);
        end
    end
    
    %if we still wait the response after cue display time
     [trig.precue]=draw_precue(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                 pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Xpos_rule,rule,trig.fix);
     toffset_cue = Screen('Flip',video.h,vbl);%next flip = end of cue...
     timecode.cue_offset{itrial_data}  = toffset_cue;
        
     %we still wait for the response at this point
    %in addition, let's end the trial if no response occurs within a given time delay 
            tmp_t= GetSecs;
            while resp==0   %% check for responses during pre-cue drawings
                %first constraint: subject will have about 1 sec to press a button
                if GetSecs>tmp_t+0.8
%                     miss=1;%no response occured !
                    break
                end
                
                if ~resp && participant.flags.with_response_keyboard
                    [resp,t]=CheckKeyPress(keyresp);
                    if resp
                        if participant.flags.with_triggers
                            trigger(resp,hp2);%1= left 2=right ?
                        end
                    end
                end
                
                if ~resp && participant.flags.with_response_lumina
                    [dat, t] = IOPort('Read',hport);
                    t = t(1);
                    if ~isempty(dat) && ismember(dat(1),datresp)
                        resp = find(datresp == dat(1));%this means a response ?
                        %CHECK LUMINA RESPONSE HERE:
                        if participant.flags.with_triggers
                            trigger(resp,hp2);%
                        end
                        break %
                    end
                end
            end
            
     toffset = Screen('Flip',video.h); %after response everything disappears from screen ?
     
                                     
                rt = t-timecode.cue_onset{itrial_data};
                accu = ((side==rule)&&(resp==1)) ||...
                    (   (side~=rule)&&(resp==2));
                
                % Log data
                response.resp{itrial_data} = resp;
                response.rt{itrial_data} = rt;
                response.accu{itrial_data} = accu;
                timecode.stim_offset{itrial_data} = toffset;
                timecode.resp_press{itrial_data} = t;
                
                % Display on experimenter control monitor
                resptype    = 'N/A ';
                
                if resp==0
                    resptype=('miss       ');
                    trig.feedback=70;%slow or incorrect or miss
                else
                rt2 = [rt2,rt];
                mean_rt= mean(rt2);
                    if Passation.Data.Trials.switch{itrial_data}==1
                        if accu && mean_rt<=task_diff  %%%%%% NEW 2018.12.07
                            task_diff=task_diff-0.015; 
                        elseif accu &&  mean_rt>task_diff
                            task_diff=task_diff+0.01; 
                        end                            %%%%%%%%
                        if accu && rt<task_diff
                            resptype=('hit       ');
                            trig.feedback=80;%FAST correct
                        else
                            resptype=('error       ');
                            trig.feedback=70;%slow or incorrect or miss
                        end
                    
                        
                    elseif Passation.Data.Trials.switch{itrial_data}==2
                        %for switch trial, don't punish slow RTs !
                        
                        if accu
                            resptype=('hit       ');
                            trig.feedback=85;%correct switch
                            if task_diff>=.200 %300
                                task_diff=task_diff-0.05; %-0.04
                            else %don't update task_diff
                            end
                        else
                            resptype=('error       ');
                            trig.feedback=75;%incorrect switch
                            task_diff=task_diff+0.05; %0.04
                        end
                        
                    end
                end
                fprintf('|RT:% 6dms',round(rt*1000));
                fprintf(' resp:[%d] = %s', resp, resptype);
                
                % Wait patient to release the buttons
                if participant.flags.with_response_lumina ...
                        && ~participant.flags.with_response_keyboard...
                        && ~participant.flags.with_response_mouse
                    % NB : in ASCII/MEDx mode, Lumina buttons send a single
                    % trigger when pressing the buttons i.e. cannot detect
                    % relase nor continuous press
                    fprintf(' [n/a with lumina] ');
                    timecode.resp_release{itrial_data} = NaN;
                    t=WaitSecs('UntilTime',t+timing.response_release);
                else
                    pressed=true;
                    lastkeypress=t;
                    fprintf(' [waiting release... ');
                    while pressed || (t-lastkeypress) < timing.response_release
                        pressed=0;
                        if participant.flags.with_response_keyboard
                            pressed = pressed || CheckKeyPress(keyresp);
                        end
                        
                        t = GetSecs;
                        if pressed
                            lastkeypress=t;
                        end
                    end
                    timecode.resp_release{itrial_data} = lastkeypress;
                    fprintf(' %03.0fms]',1000*(timecode.resp_release{itrial_data}-timecode.resp_press{itrial_data}));
                end %OK: button press relased !
                
                if CheckKeyPress(keystop) % STOP
                
                    sca;
                end
                    
                                         
                if Passation.Data.Trials.switch{itrial_data}==1 && accu && rt<=task_diff % NON SWITCH CORRECT FAST
                    % Screen('DrawDots', video.h, [fix_dot_Xpos fix_dot_Ypos], fix_dot_SizePix, [0 1 0], [], 2);
                    DrawFormattedText(video.h, '+1', 'center',video.yCenter, [0 1 0]);
                    DrawFormattedText(video.h, 'Bien !', 0.48*video.x,0.4*video.y, [0 1 0]); % Good
                    Points = Points + 1; 
                elseif Passation.Data.Trials.switch{itrial_data}==1 && accu && rt>task_diff % NON SWITCH CORRECT SLOW
                    DrawFormattedText(video.h, '-1', 'center',video.yCenter, [1 0 0]);
                    DrawFormattedText(video.h, 'Trop lent !', 0.47*video.x,0.4*video.y, [1 0 0]); % Too slow
                    Points = Points - 1; 
                elseif Passation.Data.Trials.switch{itrial_data}==1 && ~accu && rt<=task_diff % NON SWITCH NOT CORRECT FAST
                    DrawFormattedText(video.h, '-1', 'center',video.yCenter, [1 0 0]);
                    DrawFormattedText(video.h, 'Mauvaise r�ponse !', 0.44*video.x,0.4*video.y, [1 0 0]); % Wrong answer
                    Points = Points - 1; 
                elseif Passation.Data.Trials.switch{itrial_data}==1 && ~accu && rt>task_diff % NON SWITCH NOT CORRECT SLOW
                    DrawFormattedText(video.h, '-1', 'center',video.yCenter, [1 0 0]);
                    DrawFormattedText(video.h, 'Restez concentr� !', 0.44*video.x,0.4*video.y, [1 0 0]); % Be focussed
                    Points = Points - 1;                     
                elseif Passation.Data.Trials.switch{itrial_data}==2 && accu % SWITCH CORRECT (FAST or NOT)
                    DrawFormattedText(video.h, '+3', 'center',video.yCenter, [0 1 0]);
                    DrawFormattedText(video.h, 'Excellent !', 0.47*video.x,0.4*video.y, [0 1 0]);
                    Points = Points + 3; 
                elseif Passation.Data.Trials.switch{itrial_data}==2 && ~accu % SWITCH NOT CORRECT (FAST or NOT)
                    DrawFormattedText(video.h, '-3 ', 'center',video.yCenter, [1 0 0]);
                    DrawFormattedText(video.h, 'Mauvaise r�ponse !', 0.44*video.x,0.4*video.y, [1 0 0]); % Wrong answer
                    Points = Points - 3;
                    
                %else
                    %     Screen('DrawDots', video.h, [fix_dot_Xpos fix_dot_Ypos], fix_dot_SizePix, [1 0 0], [], 2);
                %    DrawFormattedText(video.h, '-1 !', 'center',video.yCenter, [1 0 0]);
                end
                
                %if Passation.Data.Trials.switch{itrial_data}==2
                %    if accu
                %        DrawFormattedText(video.h, '+3 !', 'center',video.yCenter, [0 1 0]);
                %    else
                %        DrawFormattedText(video.h, '-3 !', 'center',video.yCenter, [1 0 0]);
                %    end
                %end
                
                DrawFormattedText(video.h, ['POINTS :' num2str(Points)] ,0.1*video.x,0.1*video.y, 0.5);
                
                
         %% 5. FEEDBACK
                tonset_feedback = Screen('Flip',video.h);%DRAW FEEDBACK and play sound (can this be simultaneous ?)
                if participant.flags.with_triggers
                trigger(trig.feedback,hp2);             %
                    %          % Send trigger right after sound : not sure
                    %          how this works on psychotoolbox...
                end
                
                %if rt>task_diff 
                %    Snd('Play', sin([1:5000]*pi*1/100)*.5);%how do we get the timing of this sounds ?
                %   
                %elseif rt<task_diff
                %    Snd('Play', sin([1:500 ]*pi*1/050)*.2);
                %end
                
                if Passation.Data.Trials.switch{itrial_data}==1 && accu && rt<=task_diff % NON SWITCH CORRECT FAST
                    Sound_Good(0,pahandle);
                elseif Passation.Data.Trials.switch{itrial_data}==1 && accu && rt>task_diff % NON SWITCH CORRECT SLOW
                    Sound_Bad(0,pahandle); 
                elseif Passation.Data.Trials.switch{itrial_data}==1 && ~accu && rt<=task_diff % NON SWITCH NOT CORRECT FAST
                    Sound_Bad(0,pahandle);
                elseif Passation.Data.Trials.switch{itrial_data}==1 && ~accu && rt>task_diff % NON SWITCH NOT CORRECT SLOW
                    Sound_Bad(0,pahandle);                                        
                elseif Passation.Data.Trials.switch{itrial_data}==2 && accu % SWITCH CORRECT (FAST or NOT)
                    Sound_Excellent(0,pahandle);
                elseif Passation.Data.Trials.switch{itrial_data}==2 && ~accu % SWITCH NOT CORRECT (FAST or NOT)
                    Sound_Excellent_missed(0,pahandle);
                end                
                
                
                
                timecode.feedback_onset{itrial_data} = tonset_feedback;
                toffset_feedback = Screen('Flip',video.h,tonset_feedback+roundfp(timing.feedbackduration,video.ifi));%next flip = end of pre-cue...
                timecode.feedback_offset{itrial_data}  = toffset_feedback;
%% one trial DISPLAY = DONE (fix--pre_cue--cue--resp--feedback) = DONE
                
            end
                            %% one NSW-SW trial sequence= DONE
        Passation.Data.Response = response;
        Passation.Data.Timecode = timecode;
%         save([Passation.Filename '_Bloc_' num2str(blocidx)],'Passation');
%         assignin('base','Passation', Passation);
        end %end of a switch-non-switch sequence
         % Save data in temporary file just in case...after each volatility
             % level ?
        
        
        % Temporary backup: tic - toc ???
        save([Passation.Filename '_Bloc_' num2str(blocidx)],'Passation');
        assignin('base','Passation', Passation);
%         
        
    DrawText(video.h,{'Appuyer sur espace pour continuer.'});
    Screen('Flip',video.h);
    key = WaitKeyPress([keywait keyquit]);
        
    end %end of all volatility levels (basically, this is the end of one blox of trial)
    %%%%%%%%%%%%%%%%%%%%%%%
    
    %IMPLEMENT a pause at the end of a bloc: 
    if blocidx<num_bloc
    DrawText(video.h,{'Attendez le chercheur pour demarrer le prochain bloc.'});
    Screen('Flip',video.h);
    key = WaitKeyPress([keywait keyquit]);
    end
end  %this is the end of all bloc
end % if experiement



if(0) % TRAINING
    
% #01 Display and wait for keyboard input
DrawFormattedText(video.h, 'START OF THE TRAINING', 'center', video.y*0.4, 1); 
DrawFormattedText(video.h, ['Press "' KbName(keyconfirm) '" to continue'], 'center', video.y*0.9, 0.5); 
Screen('Flip', video.h); WaitKeyPress(keyconfirm);
                                           % #02 Display and wait for keyboard input
DrawFormattedText(video.h, 'GENERAL INFORMATION', 'center', video.y*0.1, 1); % General information on the experiment
DrawFormattedText(video.h, ['Date : ' participant.date ], video.x*0.2, video.y*0.3, 1); 
DrawFormattedText(video.h, ['Participant''s name : ' participant.identifier], video.x*0.2, video.y*0.35, 1);
DrawFormattedText(video.h, ['Experiment condition : ' participant.session], video.x*0.2, video.y*0.4, 1);
DrawFormattedText(video.h, ['Saving : ' Passation.DataFolder], video.x*0.2, video.y*0.45, 1);
DrawFormattedText(video.h, ['Blocs number : ' num2str(num_bloc) ], video.x*0.2, video.y*0.5, 1);
DrawFormattedText(video.h, ['Press "' KbName(keyconfirm) '" to continue'], 'center', video.y*0.9, 0.5); 
Screen('Flip', video.h); WaitKeyPress(keyconfirm);

end


    
    if participant.flags.with_eyetracker && ~is_training
        fprintf('Stopping Eyetracker ...');
        Eyelink('StopRecording');
        fprintf('recording stopped.\n');
    end
    
    
                                if is_training
                                    if ~stopped
                                        fprintf('Un autre block de training? \n');
                                        t=GetSecs;
                                        while (GetSecs()-t)<5 && ~stopped && ~stopped
                                            DrawText(video.h,{...
                                                '...',...
                                                '',...
                                                sprintf('%d',round(5-(GetSecs()-t)))});
                                            Screen('Flip',video.h,tonset);
                                            if CheckKeyPress(keystop)
                                                stopped = true;
                                            end
                                        end
                                        %% Entrainement � programmer !
                            %             Data.Sequence  = num2cell(randi(3,[1,ntrials]),2)';
                            %             Data.Target    = num2cell(randi(3),2)';
                            %             Data.Side      = num2cell(randi(2),2)';
                                    else
                                        % Training was manually stopped. Continue with the task?
                                        fprintf('L''entrainement interrompu.\n');
                                        is_training = false;
                                        stopped=false;
                                        DrawText(video.h,{...
                                            'Cette fois, nous allons passer' ...
                                            'a la tache proprement dite.'},'tm');
                                        fprintf('On continue vers blocs de t�che...\n');
                                        WaitSecs(.3);
                                        Data=Passation.Data;
                                    end
                                else %this is REAL experiment
                                    if stopped
                                        fprintf('Bloc interrompu!\n');
                                        if nextblock
                                            stopped = false;
                                        end
                                    end
                                    save([Passation.Filename],'Passation');%Why is this done twice ?
                                    fprintf('Session data are saved in: %s\n', Passation.Filename);


                                end

if participant.flags.with_response_lumina
    % Close response port
    IOPort('Close',hport);
end

if participant.flags.with_triggers
    % close trigger port
%     CloseParPort;
    IOPort('Close',hp2);

end

if stopped
    sufx = '_stopped';
else
    sufx = '';
end
Passation.Filename=[Passation.Filename sufx];

% Save data
save(Passation.Filename,'Passation');

% Close video etc.
Priority(0);
Screen('CloseAll');
FlushEvents;
ListenChar(0);
ShowCursor;
video = [];
%% THIS IS THE END
return



% % close response port
if participant.flags.with_meg
    %     % close trigger port
    CloseParPort;
end
% Close the audio device
PsychPortAudio('Close', pahandle); 

