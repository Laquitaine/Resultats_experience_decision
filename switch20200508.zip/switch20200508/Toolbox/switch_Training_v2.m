%==========================================================================
% Function : switch_Experiment
%==========================================================================

function [Passation,errormsg] = switch_Training_v2(participant)

% Initialisation of Passation
%==========================================================================
% Definition of Passation DEBUG, Running, TaskParameters, Runner,
% Participant, DataFolder, Filename
%--------------------------------------------------------------------------
global DEBUG;                   % Define DEBUG as a global variable
global Points;                  % Points
global mean_rt;                 % Mean speed
global mean_accu;                 % Mean speed
rt2=[]; accu2=[];
mean_rt=[]; mean_accu=[];
Passation=[];                   % Define Passation
errormsg =[];                 	% Define errormsg
Passation.DEBUG = DEBUG;      	% Define Passation.DEBUG
Passation.Running = dbstack; 	% File information (file:Name.m ; name:Name ; line:999)
for i=1:length(Passation.Running)
    Passation.Running(i).fullpath = which(Passation.Running(i).file); % File location (C:\Users\Name\Documents\File.m)
    Passation.Running(i).filedate = getfield(dir(Passation.Running(i).fullpath),'date'); % Saving date (16-oct.-2018 15:07:49)
    Passation.Running(i).mcode    = ...    % Copy all the actual script
        textscan(Passation.Running(i).fullpath,'%s','delimiter','\n');  %"textread" old function replacing textscan        
end
run('switch_TaskParameters'); 	% Define various parameters
Passation.TaskParameters = ... 	% Copy all the TaskParameter script
    textscan(which('switch_TaskParameters'),'%s','delimiter','\n');
Passation.Runner = ...         	% Copy all the Runner script
    textscan(which('switch_Runner'),'%s','delimiter','\n');
Passation.Participant = participant;
Passation.DataFolder = fullfile(participant.folder,'Data',participant.identifier); %(C:\...\Matlab\switch) + \Data + \Participant_name
if not(exist(Passation.DataFolder, 'dir')) % Saving data folder exist or not
    if DEBUG
        Passation.DataFolder = fullfile(fileparts(tempname)); % DEBUG => Save in temporary folder
    else
        error('switch:MssingDataFolder','Missing data folder! %s\n', Passation.DataFolder);
    end
end
Passation.Filename=fullfile(...	% Define the filename to save the info
    Passation.DataFolder,sprintf('switch_%s_%s',... % like 
    datestr(now,'yyyymmdd-HHMM'),...	% Datafolder\switch_20181017-1038_lfp
    participant.session));
stopped = false;
if participant.flags.with_response_logitech
    [gamepadIndices, productNames] = GetGamepadIndices;
end

% Save Diary (in ...\switch\data\TEST\switch_20181017-1038_lfp)
%==========================================================================
diary(Passation.Filename) % DIARY ON = begining of saving
fprintf('\n'); 
fprintf('=======================================\n');
fprintf('======= START OF THE EXPERIMENT =======\n');
fprintf('=======================================\n');
fprintf('\n');
trig.start=51; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS

% CLASSEMENT
%==========================================================================
for iSujet=1:1:15
    Name{iSujet}=strcat('Sujet_',num2str(iSujet));
end          
Points_Exp = [ 474 , 474 , 474 , 474 , 474 , 474 , 474 , 474 ;...  % 01 -- avec 64 switch (22') : 820*37/64
               389 , 389 , 389 , 389 , 389 , 389 , 389 , 389 ;...  % 02 -- avec 37 switch (13')
               421 , 421 , 421 , 421 , 421 , 421 , 421 , 421 ;...  % 03 -- (16')
               372 , 372 , 372 , 372 , 372 , 372 , 372 , 372 ;...  % 04 -- (13')
               386 , 386 , 386 , 386 , 386 , 386 , 386 , 386 ;...  % 05 -- (14')
               466 , 466 , 466 , 466 , 466 , 466 , 466 , 466 ;...  % 06 -- (13')
               338 , 338 , 338 , 338 , 338 , 338 , 338 , 338 ;...  % 07 -- (13')
               424 , 424 , 424 , 424 , 424 , 424 , 424 , 424 ;...  % 08
               467 , 467 , 467 , 467 , 467 , 467 , 467 , 467 ;...  % 09
               315 , 315 , 315 , 315 , 315 , 315 , 315 , 315 ;...  % 10
               583 , 583 , 583 , 583 , 583 , 583 , 583 , 583 ;...  % 11
               131 , 131 , 131 , 131 , 131 , 131 , 131 , 131 ;...  % 12
               328 , 328 , 328 , 328 , 328 , 328 , 328 , 328 ;...  % 13
               0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;...  % 14
               0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;...  % 15
                0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ];...                % XX
Name{iSujet+1} = Passation.Participant.identifier;
Points_Exp(iSujet+1,:) = [ 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ];


% Configuarion
%==========================================================================
% Set important design parameters
%--------------------------------------------------------------------------
num_bloc = 1;                   % ideally, we would perform 4 blocs of switch trials (duration is about 1h)
stim_rule_type_blocs = [1 1 1 1 1 1 1 1];% stim_rule_type_blocs=stim_rule_type_blocs(randperm(num_bloc));%1=rule before; 2=rule after
bloc_volatility_order = [1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1];
bloc_volatility_order = bloc_volatility_order(randperm(num_bloc),:); % Random permutation of line order
n_trials_within_volatility = 24; %48 %18;%should be a multiple of 2(rules) and 3(volatility level)
task_diff=2;                    %500 ms = initial task difficulty (good for training; not so good for experimental sessions)?
task_diff_bonus=1; 

% Randomize number of non-switch trials for each volatility in a bloc
%--------------------------------------------------------------------------
num_nsw=[]; num_nsw_control=[];                              % Definition
num_nsw(:,1)=repmat([3 4 5],1,n_trials_within_volatility/3); % Column 1 [3 4 5...]
num_nsw(:,1)=num_nsw(randperm(length(num_nsw(:,1))),1);      % Randomized column 1
num_nsw_control(:,1)=repmat([3 4 5],1,4);                    % 60 essai "rapidit�"
num_nsw_control(:,1)=num_nsw_control(randperm(length(num_nsw_control(:,1))),1);  % Randomized column 1
num_nsw_control = [ 59 ; num_nsw_control(:,1) ];             % 60 essai "pr�cision"
num_nsw = [ num_nsw(:,1) ; num_nsw_control(:,1) ] ;
n_trials_within_volatility = 38; %=24+12+1

% Number of trials within a bloc
%--------------------------------------------------------------------------
ntrials=sum(num_nsw(:))+(size(num_nsw,1)*size(num_nsw,2)); % number of nsw + number of switch

% Initialisation of Psychtoolbox
%==========================================================================
% Open the Psychtoolbox and display various general information about the
% experiment (participant, exp. condition, keyboard inputs)
%--------------------------------------------------------------------------
if participant.flags.with_fullscreen
    video = OpenPTBScreen([]);             % Screen Definition
else
    video = OpenPTBScreen;
end                                        
if DEBUG                                   % #03 DEBUG mode display and wait for keyboard input
    DrawFormattedText(video.h, 'DEBUG MODE', 'center', 'center', 1); Screen('Flip', video.h); KbStrokeWait;
end
if ~DEBUG          % Remove keyboard outputs to matlab screen: REMOVED BY JB TO DEBUG...
    HideCursor;    % Hide the mouse cursor
    FlushEvents;   % Remove events from the system even queue
    ListenChar(2); % 2 = listen to keyboard input and supress any output of keypresses
end

%==========================================================================
% Important section: defines the structures within and between blocs of
% trials. Store information in Passation.Data=Data;
%--------------------------------------------------------------------------

% Stimuli defintion
%==========================================================================
% STEP 1 : 20 pixel white fixation dot at screen center
% STEP 2 : rule or pre-cue display
%    2.1 : pre-cue (stim type) trials = first display peripheric pre-cues
%          and then the central rule
%    2.2 : pre-cue (rule type) trials = first display central rule and then
%          peripheric pre-cues (see the papers of Buchman and Miller in
%          Neuron)
% STEP 3 : 3 squares (stim+rule)
%--------------------------------------------------------------------------
% #1 Fixation position
fix_dot_Xpos = video.xCenter;                             % Center X position in pixels
fix_dot_Ypos = video.yCenter;                             % Center Y position in pixels

% #2.1 Pre-cue position and color
baseRect = [0 0 cue_size cue_size];                       % Rect dimension of 50 by 50 pixels
pre_cue_Xpos_tmp = [video.x*0.35, video.x*0.65, video.x*0.43, video.x*0.57];  % Screen X/Y positions of the two pre-cue rectangles  
pre_cue_Ypos_tmp = [video.y*0.4, video.y*0.4, video.y*0.6, video.y*0.6];  % Adjust X/Y coordinates of both pre-cues
pre_cue_Xpos_stim = nan(4, length(pre_cue_Xpos_tmp));     % Create a matrix for all the squares (4,:)
for i = 1:length(pre_cue_Xpos_tmp)                        % that contains (xmin,ymin,xmax,ymax) of each square
    pre_cue_Xpos_stim(:, i) = CenterRectOnPointd(baseRect, pre_cue_Xpos_tmp(i), pre_cue_Ypos_tmp(i)); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues
%                       LEFT / RIGHT /  UP  / DOWN
pre_cue_colors(:,:,1)=[1 0 1 ; 1 1 0 ; 1 0 1 ; 1 1 0]';   % magenta left; yellow right ; magenta up; yellow down
pre_cue_colors(:,:,2)=[1 0 1 ; 1 1 0 ; 1 1 0 ; 1 0 1]';   % magenta left; yellow right ; yellow up ; magenta down
pre_cue_colors(:,:,3)=[1 1 0 ; 1 0 1 ; 1 1 0 ; 1 0 1]';   % yellow left ; magenta right; yellow up ; magenta down
pre_cue_colors(:,:,4)=[1 1 0 ; 1 0 1 ; 1 0 1 ; 1 1 0]';   % yellow left ; magenta right; magenta up; yellow down

% #2.2 Pre-cue rule position and color
pre_cue_Xpos_rule = CenterRectOnPointd(baseRect, video.x*0.5, video.yCenter);%
pre_cue_rule_color=[1 0 1; 1 1 0]';                       % first colomn= rule= magenta; second= yellow

% #3 Cue position and color
cue_Xpos_tmp = [video.x*0.35, video.x*0.5, video.x*0.65, video.x*0.43, video.x*0.57]; % Screen X positions of our three rectangles
cue_Ypos_tmp = [video.y*0.4, video.yCenter, video.y*0.4, video.y*0.6, video.y*0.6];
cue_Xpos = nan(4, length(cue_Xpos_tmp));                  % Create a matrix for all the squares (4,:)
for i = 1:length(cue_Xpos_tmp)                            % that contains (xmin,ymin,xmax,ymax) of each square
    cue_Xpos(:, i) = CenterRectOnPointd(baseRect, cue_Xpos_tmp(i), cue_Ypos_tmp(i)); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues
%                   LEFT / RULE / RIGHT / UP / DOWN
cue_colors(:,:,1)=[1 0 1 ; 1 0 1 ; 1 1 0 ; 1 0 1 ; 1 1 0]';  % magenta left+up; yellow right+down; rule = magenta
cue_colors(:,:,2)=[1 0 1 ; 1 0 1 ; 1 1 0 ; 1 1 0 ; 1 0 1]';  % magenta left+down; yellow right+up; rule = magenta
cue_colors(:,:,3)=[1 1 0 ; 1 0 1 ; 1 0 1 ; 1 1 0 ; 1 0 1]';  % yellow left+up ; magenta right+down; rule = magenta
cue_colors(:,:,4)=[1 1 0 ; 1 0 1 ; 1 0 1 ; 1 0 1 ; 1 1 0]';  % yellow left+down ; magenta right+up; rule = magenta
cue_colors(:,:,5)=[1 0 1 ; 1 1 0 ; 1 1 0 ; 1 0 1 ; 1 1 0]';  % magenta left+up; yellow right+down; rule = yellow
cue_colors(:,:,6)=[1 0 1 ; 1 1 0 ; 1 1 0 ; 1 1 0 ; 1 0 1]';  % magenta left+down; yellow right+up; rule = yellow
cue_colors(:,:,7)=[1 1 0 ; 1 1 0 ; 1 0 1 ; 1 1 0 ; 1 0 1]';  % yellow left+up ; magenta right+down; rule = yellow
cue_colors(:,:,8)=[1 1 0 ; 1 1 0 ; 1 0 1 ; 1 0 1 ; 1 1 0]';  % yellow left+down ; magenta right+up; rule = yellow

% #4 Post-cue (=axe) position and color 
baseRect_HV = [0 0 650  post_cue_short ;...   % Rect dimension of horizonzal axe
               0 0 645  post_cue_short-5 ;... % Rect dimension of horizonzal axe
               0 0 350  post_cue_short ;...   % Rect dimension of horizonzal axe
               0 0 345  post_cue_short-5 ]; % Rect dimension of horizonzal axe
post_cue_Xpos_tmp = [video.xCenter, video.xCenter, video.xCenter, video.xCenter]; % Screen X/Y positions of the two post-cue rectangles  
post_cue_Ypos_tmp = [video.y*0.4, video.y*0.4, video.y*0.6, video.y*0.6]; % Adjust X/Y coordinates of both post-cues
post_cue_Xpos_stim = nan(4, length(post_cue_Xpos_tmp)); % Create a matrix for all the squares (4,:)
for i = 1:length(post_cue_Xpos_tmp)                     % that contains (xmin,ymin,xmax,ymax) of each square
    post_cue_Xpos_stim(:, i) = CenterRectOnPointd(baseRect_HV(i,:), post_cue_Xpos_tmp(i), post_cue_Ypos_tmp(i)); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues
%                   H white / H black  / V white / V black
post_cue_colors(:,:)=[1 1 1 ; 0 0 0 ; 1 1 1 ; 0 0 0]';  % white horizontal/vertical ; black horizontal/vertical

% Initialisation port audio
%==========================================================================
InitializePsychSound(1)                 % Initialize Sounddriver
Snd_channel = 2;                       % Number of channels
Snd_freq = 48000;                       % Frequency of the sound
pahandle = PsychPortAudio('Open', [], 1, 1, Snd_freq, Snd_channel);
PsychPortAudio('Volume', pahandle, 0.5); % Set the volume

% Initialisation text
%==========================================================================
[text_fr,text_en,text_sv,text_cs] = switch_text_structure('Training_v2');
if participant.language==0,     text=text_en.training; % Anglais
elseif participant.language==1, text=text_fr.training; % Fran�ais
elseif participant.language==2, text=text_sv.training; % Suedois
elseif participant.language==3, text=text_cs.training; % Tch�que
end

% Display steps
%==========================================================================
% #01 Display and wait for keyboard input
DrawFormattedText(video.h, text{1}, 'center', video.y*0.4, 1); 
DrawFormattedText(video.h, text{2}, 'center', video.y*0.9, 0.5); 
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
if isequal(key,2) 
    trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
    sca; end

% #02 Display and wait for keyboard input
DrawFormattedText(video.h, text{3}, 'center', video.y*0.1, 1); 
DrawFormattedText(video.h, text{4}, 'center', video.y*0.9, 0.5); 
baseRect_jpg = [0 0 100 100]; dstRects = nan(4, 1);
dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg, video.x*0.15, video.y*0.19);
dstRects(:, 2) = CenterRectOnPointd(baseRect_jpg, video.x*0.15, video.y*0.5);
dstRects(:, 3) = CenterRectOnPointd(baseRect_jpg, video.x*0.15, video.y*0.6);
dstRects(:, 4) = CenterRectOnPointd(baseRect_jpg, video.x*0.15, video.y*0.7);
dstRects(:, 5) = CenterRectOnPointd(baseRect_jpg, video.x*0.15, video.y*0.8);
theImage = imread('attention.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
theImage = imread('Son_1.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,2), 0); % Draw the image to the screen
theImage = imread('Son_2.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,3), 0); % Draw the image to the screen
theImage = imread('Son_3.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,4), 0); % Draw the image to the screen
theImage = imread('Son_4.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,5), 0); % Draw the image to the screen
DrawFormattedText(video.h, text{5}, video.x*0.2, video.y*0.2, 1); 
DrawFormattedText(video.h, text{6}, video.x*0.2, video.y*0.3, 1);
DrawFormattedText(video.h, text{7}, 'center', video.y*0.4, 0.7); 
DrawFormattedText(video.h, text{8}, video.x*0.2, video.y*0.5, 1); 
DrawFormattedText(video.h, text{9}, video.x*0.8, video.y*0.5, [0 1 0]); 
DrawFormattedText(video.h, text{10}, video.x*0.2, video.y*0.6, 1); 
DrawFormattedText(video.h, text{11}, video.x*0.8, video.y*0.6, [1 0 0]); 
DrawFormattedText(video.h, text{12}, video.x*0.2, video.y*0.7, 1); 
DrawFormattedText(video.h, text{13}, video.x*0.8, video.y*0.7, [1 0 0]); 
DrawFormattedText(video.h, text{14}, video.x*0.2, video.y*0.8, 1); 
DrawFormattedText(video.h, text{15}, video.x*0.8, video.y*0.8, [0 1 0]); 
Screen('Flip', video.h); sound=0;
while sound==0
    if CheckKeyPress(KbName('1'))==1 || CheckKeyPress(KbName('F1'))==1,   Sound_Good(0,pahandle);  end
    if CheckKeyPress(KbName('2'))==1 || CheckKeyPress(KbName('F2'))==1,   Sound_Bad(0,pahandle);  end
    if CheckKeyPress(KbName('3'))==1 || CheckKeyPress(KbName('F3'))==1,   Sound_ToFast(0,pahandle);   end
    if CheckKeyPress(KbName('4'))==1 || CheckKeyPress(KbName('F4'))==1,   Sound_Excellent(0,pahandle);    end
    if CheckKeyPress(KbName('0'))==1 || CheckKeyPress(KbName('F10'))==1,  sound=1;    end
end
key = WaitKeyPress([keyconfirm keystop]); 
if isequal(key,2)  
    trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
    sca;  end

% case 1 axe=1; rule=1; side=1; resp=0; % horizontal / magenta / resp=1 gauche
% case 2 axe=1; rule=1; side=4; resp=0; % horizontal / magenta / resp=2 droite
% case 3 axe=2; rule=1; side=3; resp=0; % horizontal / magenta / resp=4 bas
% case 4 axe=2; rule=1; side=1; resp=0; % horizontal / magenta / resp=3 haut
% case 5 axe=1; rule=2; side=2; resp=0; % horizontal / yellow  / resp=2 droite
% case 6 axe=2; rule=2; side=4; resp=0; % vertical   / yellow  / resp=4 bas
% case 7 axe=1; rule=2; side=3; resp=0; % horizontal / yellow  / resp=1 gauche
% case 8 axe=2; rule=2; side=2; resp=0; % vertical   / yellow  / resp=3 haut
axe = [1,1,2,2,1,2,1,2];
rule=[1,1,1,1,2,2,2,2];
side=[1,4,3,1,2,4,3,2];
accu=[1,2,4,3,2,4,1,3];

for ind_ex=1:1:8
    resp=0;
    DrawFormattedText(video.h, text{16}, 'center', video.y*0.1, 1); 
    DrawFormattedText(video.h, text{17}, video.x*0.25, video.y*0.2, 1);
    baseRect_jpg = [0 0 200 250]; dstRects = nan(4, 1);
    dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg, video.x*0.15, video.y*0.5);
    dstRects(:, 2) = CenterRectOnPointd(baseRect_jpg, video.x*0.85, video.y*0.5);
    theImage = imread('lumina_left_up.jpg'); % Load the image
        imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
    theImage = imread('lumina_right_down.jpg'); % Load the image
        imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,2), 0); % Draw the image to the screen
    draw_postcue_x4(video,axe(ind_ex),rule(ind_ex),post_cue_colors,cue_colors,side(ind_ex),post_cue_Xpos_stim,cue_Xpos);
    Screen('Flip', video.h);
    if participant.flags.with_response_lumina,   IOPort('Purge',hport_lum);  end
    while ~(resp==accu(ind_ex))
        if participant.flags.with_response_keyboard
            [resp,t]=CheckKeyPress(keyresp);
        elseif participant.flags.with_response_lumina
            [dat, t] = IOPort('Read',hport_lum);
            if ~isempty(dat) && ismember(dat(1),datresp)
                resp = find(datresp == dat(1));
            end
        elseif participant.flags.with_response_logitech
               [~,t,Code,~] = KbCheck(gamepadIndices(1));
               if any(Code(logresp))
                  resp = find(Code(logresp),1); 
               end
        end
        if CheckKeyPress(keystop)==1
            sca;
            break;
        end
    end
    baseRect_jpg = [0 0 150 150]; dstRects = nan(4, 1);
    dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg.*0.5, video.x*0.5, video.y*0.5);
    theImage = imread('good.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
    Screen('Flip', video.h); Sound_Good(0,pahandle); WaitSecs(0.4); % Wait for one seconds
end

ind_ex=0;
while ind_ex<=8
    ind_ex=ind_ex+1;
    resp=0;
    DrawFormattedText(video.h, text{16}, 'center', video.y*0.1, 1); 
    DrawFormattedText(video.h, text{17}, video.x*0.25, video.y*0.2, 1);
    draw_postcue_x4(video,axe(ind_ex),rule(ind_ex),post_cue_colors,cue_colors,side(ind_ex),post_cue_Xpos_stim,cue_Xpos);
    Screen('Flip', video.h);
    while ~(resp==accu(ind_ex))
        if participant.flags.with_response_keyboard
            [resp,t]=CheckKeyPress(keyresp);
        elseif participant.flags.with_response_lumina
            [dat, t] = IOPort('Read',hport_lum);
            if ~isempty(dat) && ismember(dat(1),datresp)
                resp = find(datresp == dat(1));
            end
        elseif participant.flags.with_response_logitech
               [~,t,Code,~] = KbCheck(gamepadIndices(1));
               if any(Code(logresp))
                  resp = find(Code(logresp),1); 
               end
        end
        if CheckKeyPress(keystop)==1
            sca;
            break;
        end
    end
    baseRect_jpg = [0 0 150 150]; dstRects = nan(4, 1);
    dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg.*0.5, video.x*0.5, video.y*0.5);
    theImage = imread('good.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
    Screen('Flip', video.h); Sound_Good(0,pahandle); WaitSecs(0.4); % Wait for one seconds
    if ind_ex==8
        % Pr�t pour la suite ?
        DrawFormattedText(video.h, text{18}, 'center', video.y*0.4, 1); 
        DrawFormattedText(video.h, text{19}, 'center', video.y*0.9, 0.5); 
        Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop keyquit]); 
        if isequal(key,1)
            ind_ex=ind_ex+1;
        elseif isequal(key,2)
            trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
            sca;   
        elseif isequal(key,3)
            ind_ex=0;
        end
    end
end

% #03 Display and wait for keyboard input
DrawFormattedText(video.h, text{20}, 'center', video.y*0.1, 1); 
baseRect_jpg = [0 0 80 80]; dstRects = nan(4, 1);
dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg, video.x*0.2, video.y*0.25);
dstRects(:, 2) = CenterRectOnPointd(baseRect_jpg, video.x*0.2, video.y*0.35);
dstRects(:, 3) = CenterRectOnPointd(baseRect_jpg, video.x*0.2, video.y*0.45);
dstRects(:, 4) = CenterRectOnPointd(baseRect_jpg, video.x*0.2, video.y*0.55); baseRect_jpg = [0 0 120 60];
dstRects(:, 5) = CenterRectOnPointd(baseRect_jpg, video.x*0.2, video.y*0.65);
theImage = imread('good.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
theImage = imread('temps.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,2), 0); % Draw the image to the screen
theImage = imread('record.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,3), 0); % Draw the image to the screen
theImage = imread('pieces.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,4), 0); % Draw the image to the screen
theImage = imread('niveau5.jpg'); % Load the image
    imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
    Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,5), 0); % Draw the image to the screen
DrawFormattedText(video.h, text{21}, video.x*0.25, video.y*0.25, 1); 
DrawFormattedText(video.h, text{22}, video.x*0.25, video.y*0.35, 1); 
DrawFormattedText(video.h, text{23}, video.x*0.25, video.y*0.45, 1); 
DrawFormattedText(video.h, text{24}, video.x*0.25, video.y*0.55, 1); 
DrawFormattedText(video.h, text{25}, video.x*0.25, video.y*0.65, 1); 
DrawFormattedText(video.h, text{2}, 'center', video.y*0.9, 0.5); 
Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]); 
if isequal(key,1)
    nominalFrameRate = Screen('NominalFrameRate', video.h); % Get the nominal framerate of the monitor.
    presSecs = sort(repmat(1:3, 1, nominalFrameRate), 'descend'); % list of the number we are going to present on each frame.
    for i = 1:length(presSecs) % Here is our drawing loop
        numberString = num2str(presSecs(i)); % Convert number into a string
        DrawFormattedText(video.h, numberString, 'center', 'center',1); % Draw our number to the screen
        Screen('Flip', video.h); % Flip to the screen
    end
elseif isequal(key,2) 
    trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
    sca; 
end

niveau=1; Nb_bonus=0; Nb_switch=0;
trig.bloc=30+niveau; param.fun.trigger(trig.bloc, param.hport_trig);

% LOOP 1 --- from 1 to num_bloc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for blocidx=1:num_bloc %befor this was : while seqidx <= nseq && nextblock %this should clearly be modified for switch
    
    stim_rule_type=stim_rule_type_blocs(blocidx); % [1} rule is before or [2] after the stimulus
    Points = 0;
    
    % If Rule after the stimulus (relax temporal pressur if rule is before stimulation)
    %----------------------------------------------------------------------
    if stim_rule_type==2 
            task_diff=task_diff2;
    end
    
    itrial_data=0; % initialize this before the first trial of a bloc;
    
    % Prepare the LogFile and the logging variables (TO BE DEFINED, ALSO)
    %----------------------------------------------------------------------
    
    % Cell definition for num_bloc blocs to save the data in
    response = [];                              % Definition of response
    timecode = [];                              % Definition of timecode
    trials = [];
    timecode.fix_onset  = cell(1,num_bloc);     % onset of fixation
    timecode.fix_offset = cell(1,num_bloc);     % offset of fixation
    timecode.precue_onset = cell(1,num_bloc);   % onset of precue (stim or rule)
    timecode.precue_offset = cell(1,num_bloc);  % offset of precue
    timecode.cue_onset = cell(1,num_bloc);      % onset of cue (stim or rule)
    timecode.cue_offset = cell(1,num_bloc);     % offset of cue
    timecode.postcue_onset = cell(1,num_bloc);  % onset of postcue (axe H/V)
    timecode.postcue_offset = cell(1,num_bloc); % offset of postcue
    timecode.stim_onset = cell(1,num_bloc);  % onset of answer window
    timecode.stim_offset = cell(1,num_bloc);  % offset of answer window
    timecode.resp_press = cell(1,num_bloc);     % button press
    timecode.resp_release = cell(1,num_bloc);   % button release
    timecode.feedback_onset= cell(1,num_bloc);  % feedback display on
    timecode.feedback_offset= cell(1,num_bloc); % feedback display off 
    
    % Array definition for 1 bloc to save the data in
    response.resp{blocidx}  = NaN*zeros(1,ntrials); % Response
    response.rt{blocidx}   = NaN*zeros(1,ntrials);  % Reaction Time (RT)
    response.accu{blocidx} = NaN*zeros(1,ntrials);  % Accurate
    timecode.fix_onset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.fix_offset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.precue_onset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.precue_offset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.cue_onset{blocidx} = NaN*zeros(1,ntrials);
    timecode.cue_offset{blocidx} = NaN*zeros(1,ntrials);
    timecode.postcue_onset{blocidx} = NaN*zeros(1,ntrials);
    timecode.postcue_offset{blocidx} = NaN*zeros(1,ntrials);
    timecode.stim_onset{blocidx} = NaN*zeros(1,ntrials);
    timecode.stim_offset{blocidx} = NaN*zeros(1,ntrials);
    timecode.resp_press{blocidx}  = NaN*zeros(1,ntrials);
    timecode.resp_release{blocidx}= NaN*zeros(1,ntrials);
    timecode.feedback_onset{blocidx}= NaN*zeros(1,ntrials);
    timecode.feedback_offset{blocidx}= NaN*zeros(1,ntrials);
    
    trials.stim_rule_type{blocidx} = NaN*zeros(1,ntrials);  % 1=rule before; 2=rule after
    trials.side{blocidx}   = NaN*zeros(1,ntrials);          % 1=MAGENTA left/up; 2=YELLOW left/down; 3=right/down; 4=right/up
    trials.rule{blocidx} = NaN*zeros(1,ntrials);            % 1=MAGENTA; 2=YELLOW
    trials.axe{blocidx} = NaN*zeros(1,ntrials);             % 1=HORIZONTAL; 2=VERTICAL
    trials.volatility{blocidx} = NaN*zeros(1,ntrials);      % 1-3 low to high
    trials.switch{blocidx} = NaN*zeros(1,ntrials);          % 1=NSM; 2=SW
    trials.td{blocidx}=NaN*zeros(1,ntrials);                % task difficulty (delay allowed)
    trials.score{blocidx}=NaN*zeros(1,ntrials);             % score  
    
    % LOOP 2 --- from 1 to 3 (max volatility level)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for volatility_level=1:1%3
        
        volatility=bloc_volatility_order(blocidx,volatility_level);%1: low; 2=mid; 3=HIGH
        %NOTE FOR LATTER perhaps should be consider to provide a short brake between volatility levels
        num_nsw_vl=num_nsw(:,volatility);                          % number of non-switch within a given volatility level
        rules=repmat([1 2],1,n_trials_within_volatility/2);        % here we make sure that the rule will change between the 18 trials
        pseudo_rd=randperm(length(rules));                         % Randomize the index to get the adequate response
        
        % a) the switch axe will correspond to the same axe than the previous non-switch in 50 % of trials
        same_axe_idx=pseudo_rd(1:round(length(rules)*0.5));     % H-H or V-V cases
        diff_axe_idx=pseudo_rd(round(length(rules)*0.5)+1:end); % H-V or V-H cases
        
        % b) the switch side will correspond to the same side than the previous non-switch in 50 % of trials
        same_resp_same_side_idx=[];                                                 % 0 repeat + same H side and same V side
        same_resp_diff_side_idx=same_axe_idx(1:round(length(same_axe_idx)*0.67));   % 0.67 repeat + same H (or V) side and different V (or H) side (diffculty variation)
        diff_resp_same_side_idx=same_axe_idx(round(length(same_axe_idx)*0.67)+1:end); % 0.33 alternate + same H side and same V side
        diff_resp_diff_side_idx=[];                                                 % 0 alternate + same H (or V) side and different V (or H) side (diffculty variation)
        
        % c) the switch response will correspond to the same side than the previous non-switch in 33 % of trials
        diff_side0_idx=diff_axe_idx(1:round(length(diff_axe_idx)*0.5));             % 0.5 for 0 axe different from previous
        diff_side1_on_idx=[];                                                       % 0 for 1 axe different from previous = selected axe (diffculty variation)
        diff_side1_off_idx=[];                                                      % 0 for 1 axe different from previous (=/) selected axe (diffculty variation)
        diff_side2_idx=diff_axe_idx(round(length(diff_axe_idx)*0.5)+1:end);         % 0.5 for 2 axe different from previous
     
%         % b) the switch side will correspond to the same side than the previous non-switch in 50 % of trials
%         same_resp_same_side_idx=same_axe_idx(1:round(length(same_axe_idx)*0.165));                                 % 0.33/2 repeat + same H side and same V side
%         same_resp_diff_side_idx=same_axe_idx(round(length(same_axe_idx)*0.165)+1:round(length(same_axe_idx)*0.33));% 0.33/2 repeat + same H (or V) side and different V (or H) side
%         diff_resp_same_side_idx=same_axe_idx(round(length(same_axe_idx)*0.33)+1:round(length(same_axe_idx)*0.665));% 0.67/2 alternate + same H side and same V side
%         diff_resp_diff_side_idx=same_axe_idx(round(length(same_axe_idx)*0.665)+1:end);                             % 0.67/2 alternate + same H (or V) side and different V (or H) side
%         
%         % c) the switch response will correspond to the same side than the previous non-switch in 33 % of trials
%         diff_side0_idx=diff_axe_idx(1:round(length(diff_axe_idx)*0.25));                                   % 0.25 for 0 axe different from previous
%         diff_side1_on_idx=diff_axe_idx(round(length(diff_axe_idx)*0.25)+1:round(length(diff_axe_idx)*0.5));% 0.25 for 1 axe different from previous = selected axe
%         diff_side1_off_idx=diff_axe_idx(round(length(diff_axe_idx)*0.5)+1:round(length(diff_axe_idx)*0.75));% 0.25 for 1 axe different from previous (=/) selected axe
%         diff_side2_idx=diff_axe_idx(round(length(diff_axe_idx)*0.75)+1:end);                               % 0.25 for 2 axe different from previous

        switch_seq_number=length(num_nsw_vl);
         
        % LOOP 3 --- from 1 to n_trials_within_volatility 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for switch_seq=1:length(num_nsw_vl) %18 "sequences of trials"/level of volatility
            
            if niveau==9 % BLOC CONTROL "pr�cision" = rule repetition
                numtrial=num_nsw_vl(switch_seq)+1; % Number of non-switch + 1 switch
                rule=rules(switch_seq); % Will change if trial=num_trial
                sides=repmat([1 2 3 4],1,round(numtrial/4));%Here I set a sequence of sides 
                sides=sides(randperm(length(sides))); %randomize the side
                axes=repmat([1 2],1,round(numtrial/2));%Here I set a sequence of axe Horizontal or Vertical
                axes=axes(randperm(length(axes))); %randomize the side
                axes(end)=2;
                if rule==1
                    sides(end)=1;
                elseif rule==2
                    sides(end)=2;
                end
            
            elseif niveau==10 % BLOC CONTROL "rapidit�" = answer repetition
                numtrial=num_nsw_vl(switch_seq)+1;%number of trials = number of non-switch +1
                rule=rules(switch_seq);%will change if trial=num_trial
                axes=repmat([2 2],1,round(numtrial/2));% ONLY axe 2 selected
                if rule==1
                    sides=repmat([2 3],1,round(numtrial/2));%Here I set a sequence of sides 
                    sides=sides(randperm(length(sides))); %randomize the side
                    sides(end)=1;
                elseif rule==2
                    sides=repmat([1 4],1,round(numtrial/2));%Here I set a sequence of sides 
                    sides=sides(randperm(length(sides))); %randomize the side
                    sides(end)=2;
                end
            
            else
                numtrial=num_nsw_vl(switch_seq)+1;%number of trials = number of non-switch +1
                rule=rules(switch_seq);%will change if trial=num_trial
                sides=repmat([1 2 3 4],1,round(numtrial/4));%Here I set a sequence of sides 
                sides=sides(randperm(length(sides))); %randomize the side
                axes=repmat([1 2],1,round(numtrial/2));%Here I set a sequence of axe Horizontal or Vertical
                axes=axes(randperm(length(axes))); %randomize the side
            end
            
            
            % LOOP 4 --- from 1 to numtrials NSW+SW
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                
            % Important loop over nsw+SW trials
             for itrial=1:numtrial %Loop over trials within agiven non-switch+switch sequence NOW
                itrial_data=itrial_data+1;
                                
                % Parameters for switch same vs. different responses+ SW-NSW
                if itrial<numtrial
                    side=sides(itrial); % c�t� = al�atoire
                    axe=axes(itrial);   % c�t� = al�atoire
                    trials.switch{itrial_data}=1;%non-switch trials
                elseif itrial==numtrial % SWITCH TRIAL = rule change
                    trials.switch{itrial_data}=2; %switch trials
                    Nb_switch=Nb_switch+1;
                    if rule==1          % Rule change (1->2) in the switch case
                        rule=2;
                    elseif rule==2      % Rule change (2->1) in the switch case
                        rule=1;
                    end
                    if niveau>=9 % BLOC CONTROL
                        axe=axes(end);
                        side=sides(end);
                    
                    elseif niveau<9
                    %%%%%%%%% 1 if the same than previous trial (0 if not) %%%%%%%%%%%% 
                    if ismember(switch_seq,same_resp_same_side_idx)     % AXE=1 / RESP=1 / SIDE=1
                        if side==1      if axe==1 side=4; elseif axe==2 side=2; end
                        elseif side==2  if axe==1 side=3; elseif axe==2 side=1; end
                        elseif side==3  if axe==1 side=2; elseif axe==2 side=4; end
                        elseif side==4  if axe==1 side=1; elseif axe==2 side=3; end
                        end
                    elseif ismember(switch_seq,same_resp_diff_side_idx) % AXE=1 / RESP=1 / SIDE=0
                        if side==1      side=3;
                        elseif side==2  side=4;
                        elseif side==3  side=1;
                        elseif side==4  side=2;
                        end
                    elseif ismember(switch_seq,diff_resp_same_side_idx) % AXE=1 / RESP=0 / SIDE=1
                        % Don't need to update side variable to set a new response
                    elseif ismember(switch_seq,diff_resp_diff_side_idx) % AXE=1 / RESP=0 / SIDE=0
                        if side==1      if axe==1 side=2; elseif axe==2 side=4; end
                        elseif side==2  if axe==1 side=1; elseif axe==2 side=3; end
                        elseif side==3  if axe==1 side=4; elseif axe==2 side=2; end
                        elseif side==4  if axe==1 side=3; elseif axe==2 side=1; end
                        end
                    elseif ismember(switch_seq,diff_side0_idx)          % AXE=0 / SIDE=1 with 0 different axis
                        if axe==1       axe=2;
                        elseif axe==2   axe=1;
                        end
                    elseif ismember(switch_seq,diff_side1_on_idx)       % AXE=0 / SIDE=0 with 1 different axis
                        if side==1      if axe==1 axe=2; side=2; elseif axe==2 axe=1; side=4; end
                        elseif side==2  if axe==1 axe=2; side=1; elseif axe==2 axe=1; side=3; end
                        elseif side==3  if axe==1 axe=2; side=4; elseif axe==2 axe=1; side=2; end
                        elseif side==4  if axe==1 axe=2; side=3; elseif axe==2 axe=1; side=1; end
                        end
                    elseif ismember(switch_seq,diff_side1_off_idx)      % AXE=0 / SIDE=0 with 1 different axis
                        if side==1      if axe==1 axe=2; side=4; elseif axe==2 axe=1; side=2; end
                        elseif side==2  if axe==1 axe=2; side=3; elseif axe==2 axe=1; side=1; end
                        elseif side==3  if axe==1 axe=2; side=2; elseif axe==2 axe=1; side=4; end
                        elseif side==4  if axe==1 axe=2; side=1; elseif axe==2 axe=1; side=3; end
                        end
                    elseif ismember(switch_seq,diff_side2_idx)          % AXE=0 / SIDE=0 with 2 different axis
                        if axe==1       axe=2;
                        elseif axe==2   axe=1;
                        end
                        if side==1      side=3;
                        elseif side==2  side=4;
                        elseif side==3  side=1;
                        elseif side==4  side=2;
                        end
                    end
                    end
                end
                
        % Monitor few interesting event codes for the logfile %%%%%%%%%%%%%
        trials.stim_rule_type{itrial_data}=stim_rule_type;
        trials.volatility{itrial_data}=volatility;
        trials.side{itrial_data}=side;
        trials.rule{itrial_data}=rule;
        trials.axe{itrial_data}=axe;
        trials.td{itrial_data}=task_diff;


%%%%%%%%%%%%%%%%%% STOP ou PAUSE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        if CheckKeyPress(keywait) % STOP
            DrawFormattedText(video.h, text{26}, 'center', video.y*0.4, 1);
            DrawFormattedText(video.h, text{27} , 'center', video.y*0.9, 0.5);
            trig.start=55;
            Screen('Flip', video.h);
            param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
            key = WaitKeyPress([keyconfirm keystop]);
            if isequal(key,2)
                trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
                stopped=true; break;
            else trig.start=56; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
            end
        end

        % OK: THERE IT's TIME TO PRESENT ONE TRIAL %%%%%%%%%%%%%%%%%%%%%%%%
        
%%%%%%%%%%%%% 1. DISPLAY FIXATION POINT + SEND TRIGGER + record logfile data    
            % 1.1 DRAW INSTRUCTIONS
                DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1); % Points
                Screen('DrawDots', video.h, ... % central dot - placeholder for rule
                    [fix_dot_Xpos fix_dot_Ypos], fix_dot_SizePix,...
                    fix_dot_Color, [0 0], 2);
                Screen('DrawDots', video.h, ... % Left/Rigth dots - placeholder for colored stim
                    [pre_cue_Xpos_tmp ; pre_cue_Ypos_tmp],...
                    [fix_dot_SizePix fix_dot_SizePix fix_dot_SizePix fix_dot_SizePix], ...
                    [fix_dot_Color'  fix_dot_Color' fix_dot_Color' fix_dot_Color'], [0 0], 2);  
                Screen('DrawingFinished',video.h);
            % 1.2 DRAW DISPLAY ON : display and get the time 
                trig.fix=10; % FIXATION TRIGGERS
                tonset_fix = Screen('Flip',video.h);  %get the initial time stamp (not sure when to do this)
                param.fun.trigger(trig.fix, param.hport_trig);
                timecode.fix_onset{itrial_data} = tonset_fix;%LOGFILE DATA:fixation onset
            %%%%%%%%%%%%%%%%%%%%%%
                toffset_fix = Screen('Flip',video.h,tonset_fix+roundfp(timing2.fixduration(),video.ifi));%next flip = end of fixation...
                timecode.fix_offset{itrial_data}  = toffset_fix;  %LOGFILE DATA
               
                
%%%%%%%%%%%%% 2. Display pre-cue (fix+pre-cue or rule+pre-cues_absent)
            % 2.1 DRAW INSTRUCTIONS
                DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                [trig_precue]=draw_precue_x4(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                    pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Ypos_tmp,pre_cue_rule_color,rule,pre_cue_Xpos_rule,trig.fix);
            % 2.2 DRAW DISPLAY ON : display and get the time %2.2 DISPLAY, trigger and logfile %a) get one time stamp to synch with screen
                vbl = Screen('Flip',video.h,toffset_fix); %displaying the pre-cue at this exact timing (tonset_precue)
                timecode.precue_onset{itrial_data} = vbl;
            %%%%%%%%%%%%%%%%%%%%%%
                % Now we present the precue + we abort the trial in case of premature resp
                precueTimeFrames=round(timing2.precueduration()/video.ifi); waitframes=1;
                resp = 0;frame=0;
% % %  Clear the response button port, to collect response
        if participant.flags.with_response_lumina
            IOPort('Purge',hport_lum);
        end
% % %         
                while resp==0 && frame<(precueTimeFrames - 1)   %% check for responses during pre-cue drawings
                    for frame = 1:precueTimeFrames - 1
                        if ~resp && participant.flags.with_response_keyboard
                            [resp,t]=CheckKeyPress(keyresp);
                            if resp
                                param.fun.trigger(resp, param.hport_trig);
                                break %
                            end
                        end

                        if ~resp && participant.flags.with_response_lumina
                            [dat, t] = IOPort('Read',hport_lum);
                            t = t(1);
                            if ~isempty(dat) && ismember(dat(1),datresp)
                                resp = find(datresp == dat(1));%this means a response ? %CHECK LUMINA RESPONSE HERE:
                                param.fun.trigger(resp, param.hport_trig);
                                break %
                            end
                        end
                        
                        if ~resp && participant.flags.with_response_logitech
                           [~,t,Code,~] = KbCheck(gamepadIndices(1));
                           if any(Code(logresp))
                              resp = find(Code(logresp),1); 
                              param.fun.trigger(resp, param.hport_trig);
                              break %
                           end
                        end
                        
                        % Draw the precue (if no response occured)
                        [trig_precue]=draw_precue_x4(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                        pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Ypos_tmp, pre_cue_rule_color,rule,pre_cue_Xpos_rule,trig.fix);
                        DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                        vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi);
                    end
                end
               timecode.precue_offset{itrial_data}  = vbl;   
                
                
%%%%%%%%%%%%% 3. DISPLAY cue (always RULE+STIM)
            % 3.1 DRAW INSTRUCTIONS 
                if resp==0
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    draw_cue_x4(video,rule,cue_colors,side,cue_Xpos); %Display the RULE for one time stamp first+send trigger
            % 3.2 DRAW DISPLAY ON
                    trig.cue=20; % FIXATION TRIGGERS
                    vbl = Screen('Flip',video.h,vbl); 
                    param.fun.trigger(trig.cue, param.hport_trig);
                end
                timecode.cue_onset{itrial_data} = vbl;
            %%%%%%%%%%%%%%%%%%%%%%   
    % Now we present the cue while monitoring response (cue disappears in
    % that case ?
    cueTimeFrames=round(timing2.cueduration()/video.ifi);frame=0;
    while resp==0 && frame<(cueTimeFrames - 1)  %% check for responses during pre-cue drawings
        for frame = 1:cueTimeFrames - 1            
            if ~resp && participant.flags.with_response_keyboard
                [resp,t]=CheckKeyPress(keyresp);
                if resp
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_lumina
                [dat, t] = IOPort('Read',hport_lum);
                t = t(1);
                if ~isempty(dat) && ismember(dat(1),datresp)
                    resp = find(datresp == dat(1));%this means a response ?
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_logitech
               [~,t,Code,~] = KbCheck(gamepadIndices(1));
               if any(Code(logresp))
                  resp = find(Code(logresp),1); 
                  param.fun.trigger(resp, param.hport_trig);
                  break %
               end
            end
            
            % Draw the cue (if no response occured)
            draw_cue_x4(video,rule,cue_colors,side,cue_Xpos);
            DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
            % Flip to the screen
            vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi);
        end
    end
    timecode.cue_offset{itrial_data}  = vbl; 
    
 
%%%%%%%%%%%%% 4. DISPLAY post-cue (always RULE+STIM+AXE)
            % 4.1 DRAW INSTRUCTIONS 
                if resp==0
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    draw_postcue_x4(video,axe,rule,post_cue_colors,cue_colors,side,post_cue_Xpos_stim,cue_Xpos); %Display the RULE for one time stamp first+send trigger
            % 4.2 DRAW DISPLAY ON
                    trig.postcue=30; % FIXATION TRIGGERS
                    vbl = Screen('Flip',video.h,vbl); 
                    param.fun.trigger(trig.postcue, param.hport_trig);
                end
                timecode.postcue_onset{itrial_data} = vbl;
            %%%%%%%%%%%%%%%%%%%%%%   
    % Now we present the cue while monitoring response (cue disappears in
    % that case ?
    postcueTimeFrames=round(timing2.postcueduration()/video.ifi);frame=0;
    while resp==0 && frame<(postcueTimeFrames - 1)  %% check for responses during pre-cue drawings
        for frame = 1:postcueTimeFrames - 1            
            if ~resp && participant.flags.with_response_keyboard
                [resp,t]=CheckKeyPress(keyresp);
                if resp
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_lumina
                [dat, t] = IOPort('Read',hport_lum);
                t = t(1);
                if ~isempty(dat) && ismember(dat(1),datresp)
                    resp = find(datresp == dat(1));%this means a response ?
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_logitech
               [~,t,Code,~] = KbCheck(gamepadIndices(1));
               if any(Code(logresp))
                  resp = find(Code(logresp),1); 
                  param.fun.trigger(resp, param.hport_trig);
                  break %
               end
            end
            
            % Draw the cue (if no response occured)
            draw_postcue_x4(video,axe,rule,post_cue_colors,cue_colors,side,post_cue_Xpos_stim,cue_Xpos);
            DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
            vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi); % Flip to the screen
        end
    end
    timecode.postcue_offset{itrial_data}  = vbl;
    
    %if we still wait the response after cue display time
     draw_cue_x4(video,rule,cue_colors,side,cue_Xpos);
     DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
     tonset = Screen('Flip',video.h,vbl);%next flip = end of cue...
     timecode.stim_onset{itrial_data} = tonset;
     
    %%%%%%%%%%%%%
     %we still wait for the response at this point
    %in addition, let's end the trial if no response occurs within a given time delay 
            tmp_t= GetSecs;
            if niveau==1        t_response=2;
            else                t_response=1;
            end
            while resp==0   % check for responses during pre-cue drawings
                %first constraint: subject will have about 1 sec to press a button
                if GetSecs>tmp_t+t_response %0.8
%                     miss=1;%no response occured !
                    break
                end
                
                if ~resp && participant.flags.with_response_keyboard
                    [resp,t]=CheckKeyPress(keyresp);
                    if resp
                        param.fun.trigger(resp, param.hport_trig);
                    end
                end
                
                if ~resp && participant.flags.with_response_lumina
                    [dat, t] = IOPort('Read',hport_lum);
                    t = t(1);
                    if ~isempty(dat) && ismember(dat(1),datresp)
                        resp = find(datresp == dat(1));%this means a response ? %CHECK LUMINA RESPONSE HERE:
                        param.fun.trigger(resp, param.hport_trig);
                        break %
                    end
                end
                
                if ~resp && participant.flags.with_response_logitech
                   [~,t,Code,~] = KbCheck(gamepadIndices(1));
                   if any(Code(logresp))
                      resp = find(Code(logresp),1); 
                      param.fun.trigger(resp, param.hport_trig);
                      break %
                   end
                end
                
            end
     DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);       
     toffset = Screen('Flip',video.h); %after response everything disappears from screen ?
     timecode.stim_offset{itrial_data} = toffset;
                                     
                if timecode.precue_offset{itrial_data} == timecode.cue_onset{itrial_data} % TOO FAST ANSWER (before cue display)
                    rt = t - (precueTimeFrames + cueTimeFrames)*video.ifi - timecode.precue_onset{itrial_data};

                elseif timecode.cue_offset{itrial_data} == timecode.postcue_onset{itrial_data} % TOO FAST ANSWER (before postcue display)
                    rt = t - cueTimeFrames*video.ifi - timecode.cue_onset{itrial_data};
                
                else % GOOD (after postcue display)
                    rt = t - timecode.postcue_onset{itrial_data};
                end
                

                if axe==1 && rule==1
                    if (side==1 || side==2) && resp==1      accu=1;
                    elseif (side==3 || side==4) && resp==2  accu=1;
                    else accu=0;
                    end
                elseif axe==1 && rule==2
                    if (side==1 || side==2) && resp==2      accu=1;
                    elseif (side==3 || side==4) && resp==1  accu=1;
                    else accu=0;
                    end                    
                elseif axe==2 && rule==1
                    if (side==1 || side==4) && resp==3      accu=1;
                    elseif (side==2 || side==3) && resp==4  accu=1;
                    else accu=0;
                    end                      
                elseif axe==2 && rule==2
                    if (side==1 || side==4) && resp==4      accu=1;
                    elseif (side==2 || side==3) && resp==3  accu=1;
                    else accu=0;
                    end   
                end
                
                
                % Log data
                response.resp{itrial_data} = resp;
                response.rt{itrial_data} = rt;
                response.accu{itrial_data} = accu;
                timecode.resp_press{itrial_data} = t;
                
                % Display on experimenter control monitor
                resptype    = 'N/A ';
                
                if resp==0
                    resptype=('miss       ');
                    trig.feedback=70;%slow or incorrect or miss
                else

                    if trials.switch{itrial_data}==1 % NON SWITCH
                        if accu && rt<task_diff
                            resptype=('hit       ');
                            trig.feedback=80;%FAST correct
                        else
                            resptype=('error       ');
                            trig.feedback=70;%slow or incorrect or miss
                        end
                    
                        
                    elseif trials.switch{itrial_data}==2 % SWITCH
                        %for switch trial, don't punish slow RTs !
                        
                        if accu
                            resptype=('hit       ');
                            trig.feedback=85;%correct switch
                            %if task_diff>=.200 %300
                            %    task_diff=task_diff-0.05; %-0.04
                            %else %don't update task_diff
                            %end
                        else
                            resptype=('error       ');
                            trig.feedback=75;%incorrect switch
                            %task_diff=task_diff+0.05; %0.04
                        end
                        
                    end
                end
                fprintf('|RT:% 6dms',round(rt*1000));
                fprintf(' resp:[%d] = %s', resp, resptype);
                
                % Wait patient to release the buttons
                if participant.flags.with_response_lumina ...
                        && ~participant.flags.with_response_keyboard...
                        && ~participant.flags.with_response_mouse
                    % NB : in ASCII/MEDx mode, Lumina buttons send a single
                    % trigger when pressing the buttons i.e. cannot detect
                    % relase nor continuous press
                    fprintf(' [n/a with lumina] ');
                    timecode.resp_release{itrial_data} = NaN;
                    t=WaitSecs('UntilTime',t+timing2.response_release);
                else
                    pressed=true;
                    lastkeypress=t;
                    fprintf(' [waiting release... ');
                    while pressed || (t-lastkeypress) < timing2.response_release
                        pressed=0;
                        if participant.flags.with_response_keyboard
                            pressed = pressed || CheckKeyPress(keyresp);
                        end
                        
                        t = GetSecs;
                        if pressed
                            lastkeypress=t;
                        end
                    end
                    timecode.resp_release{itrial_data} = lastkeypress;
                    fprintf(' %03.0fms]',1000*(timecode.resp_release{itrial_data}-timecode.resp_press{itrial_data}));
                end %OK: button press relased !
                                
                %============MEAN SPEED====================================
                
                if rt>0
                    rt2 = [rt2,rt];
                else
                    rt2 = rt2;
                end
                mean_rt= round(mean(rt2)*1000);
                accu2 = [accu2,accu];
                mean_accu = round(1e2*sum(accu2)/length(accu2),1);
                
                
                %============TASK DIFF=====================================
                
                % NEGATIVE TIMING %----------------------------------------
                if rt<=0 
                    Points = Points - 1;        % -1 point
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                    DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',[1 0 0]);
                    if niveau==10 % BLOC CONTROL "rapidit�"
                        Nb_bonus=Nb_bonus+1;
                    end
                
                % NON SWITCH CORRECT VERY FAST %---------------------------
                elseif trials.switch{itrial_data}==1 && accu && rt<=task_diff_bonus
                    Points = Points + 4;        % +4 points
                    Nb_bonus=Nb_bonus+1;
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        Sound_Good(0,pahandle);% Good timing
                        DrawFormattedText(video.h, [num2str(Nb_bonus) text{28}] ,'center','center',[0 1 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        Sound_Excellent(0,pahandle);% Excellent timing
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    elseif niveau<=8
                        Sound_Excellent(0,pahandle);% Excellent timing
                        DrawFormattedText(video.h, [num2str(Nb_bonus) text{29}] ,'center','center',[0 1 0]);
                        baseRect_jpg = [0 0 300 300]; dstRects = nan(4, 1);
                        dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg.*0.5, video.x*0.5, video.y*0.5);
                        theImage = imread('good.jpg'); % Load the image
                        imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
                        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
                    end
                
                % NON SWITCH CORRECT FAST %--------------------------------
                elseif trials.switch{itrial_data}==1 && accu && rt<=task_diff 
                    Points = Points + 2;        % +2 point
                    Sound_Good(0,pahandle);% Good timing
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        Nb_bonus=Nb_bonus+1;
                        DrawFormattedText(video.h, [num2str(Nb_bonus) text{28}] ,'center','center',[0 1 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    elseif niveau<=8
                        baseRect_jpg = [0 0 150 150]; dstRects = nan(4, 1);
                        dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg.*0.5, video.x*0.5, video.y*0.5);
                        theImage = imread('good.jpg'); % Load the image
                        imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
                        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
                    end
                
                % NON SWITCH CORRECT SLOW %--------------------------------
                elseif trials.switch{itrial_data}==1 && accu && rt>task_diff
                    Points = Points - 1;        % -1 point
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        Nb_bonus=Nb_bonus+1;
                        Sound_Good(0,pahandle);% Good timing
                        DrawFormattedText(video.h, [num2str(Nb_bonus) text{28}] ,'center','center',[0 1 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        Sound_Good(0,pahandle);% Good timing
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    elseif niveau<=8
                        Sound_Bad(0,pahandle);      % Unvalided timing
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',[1 0 0]);
                    end
                
                % NON SWITCH NOT CORRECT FAST %----------------------------
                elseif trials.switch{itrial_data}==1 && ~accu && rt<=task_diff 
                    Points = Points;                % 0 point
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        DrawFormattedText(video.h, text{31} ,'center','center',[1 0 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    end
                
                % NON SWITCH NOT CORRECT SLOW %----------------------------
                elseif trials.switch{itrial_data}==1 && ~accu && rt>task_diff 
                    Points = Points;                % 0 point
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        DrawFormattedText(video.h, text{31} ,'center','center',[1 0 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    elseif niveau<=8
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',[1 0 0]);
                    end
   
                % SWITCH CORRECT VERY FAST %------------------------------------
                elseif trials.switch{itrial_data}==2 && accu && rt<=task_diff_bonus 
                    Points = Points + 4;        % +4 points
                    Nb_bonus=Nb_bonus+1;
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        Sound_Good(0,pahandle);% Good timing
                        DrawFormattedText(video.h, [num2str(Nb_bonus) text{28}] ,'center','center',[0 1 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        Sound_Excellent(0,pahandle);% Excellent timing
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    elseif niveau<=8
                        Sound_Excellent(0,pahandle);% Excellent timing
                        baseRect_jpg = [0 0 300 300]; dstRects = nan(4, 1);
                        dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg.*0.5, video.x*0.5, video.y*0.5);
                        theImage = imread('good.jpg'); % Load the image
                        imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
                        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
                    end
                    
                % SWITCH CORRECT FAST %------------------------------------
                elseif trials.switch{itrial_data}==2 && accu && rt<=task_diff 
                    Points = Points + 4;        % +4 points
                    Sound_Good(0,pahandle);% Good timing
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        Nb_bonus=Nb_bonus+1;
                        DrawFormattedText(video.h, [num2str(Nb_bonus) text{28}] ,'center','center',[0 1 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    elseif niveau<=8
                        baseRect_jpg = [0 0 150 150]; dstRects = nan(4, 1);
                        dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg.*0.5, video.x*0.5, video.y*0.5);
                        theImage = imread('good.jpg'); % Load the image
                        imageTexture = Screen('MakeTexture', video.h, theImage); % Make the image into a texture
                        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
                    end
                      
                % SWITCH CORRECT SLOW %------------------------------------
                elseif trials.switch{itrial_data}==2 && accu && rt>task_diff  
                    Points = Points + 4;            % +4 points
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        Nb_bonus=Nb_bonus+1;
                        Sound_Good(0,pahandle);% Good timing
                        DrawFormattedText(video.h, [num2str(Nb_bonus) text{28}] ,'center','center',[0 1 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        Sound_Good(0,pahandle);% Good timing
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    elseif niveau<=8
                        Sound_Bad(0,pahandle);      % Unvalided timing
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',[1 0 0]);
                    end
                
                % SWITCH NOT CORRECT FAST %--------------------------------
                elseif trials.switch{itrial_data}==2 && ~accu && rt<=task_diff 
                    Points = Points;                % 0 point
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        DrawFormattedText(video.h, text{31} ,'center','center',[1 0 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    end
                
                % SWITCH NOT CORRECT SLOW %--------------------------------
                elseif trials.switch{itrial_data}==2 && ~accu && rt>task_diff 
                    Points = Points;                % 0 point
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                    if niveau==9 % BLOC CONTROL "pr�cision"
                        DrawFormattedText(video.h, text{31} ,'center','center',[1 0 0]);
                    elseif niveau==10 % BLOC CONTROL "rapidit�"
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',1);
                    elseif niveau<=8
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) text{30}] ,'center','center',[1 0 0]);
                    end
                end

                trials.score{itrial_data}=Points;
                
                
%%%%%%%%%%%%% 5. FEEDBACK
                if (1) % Feeback or not
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    tonset_feedback = Screen('Flip',video.h);%DRAW FEEDBACK and play sound (can this be simultaneous ?)
                else
                    tonset_feedback = toffset;
                end
                timecode.feedback_onset{itrial_data} = tonset_feedback;
                

                if accu==1 % Feeback or not
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    toffset_feedback = Screen('Flip',video.h,tonset_feedback+roundfp(timing2.feedbackduration,video.ifi));%next flip = end of pre-cue...
                else
                    toffset_feedback = toffset;
                end
                timecode.feedback_offset{itrial_data}  = toffset_feedback;
                 
             %%%%%%%%%%%%% one trial DISPLAY = DONE (fix--pre_cue--cue--resp--feedback) = DONE
             
                 %=========== INSTRUCTIONS =================================
                % Niveau 1 : diff=2s & bonus=1s ---------------------------
                if niveau==1 && itrial==numtrial && Nb_switch==3
                    niveau=niveau+1; %task_diff=1; task_diff_bonus=0.8;
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{33}], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, text{42}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{43}, 'center', video.y*0.9, 0.5);
                % Niveau 2 : diff=1s & bonus=800ms ------------------------
                elseif niveau==2 && itrial==numtrial && Nb_switch==6
                    niveau=niveau+1; %task_diff=0.8; task_diff_bonus=0.6;
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{33}], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, text{42}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{43}, 'center', video.y*0.9, 0.5);
                % Niveau 3 : diff=800mss & bonus=600ms --------------------
                elseif niveau==3 && itrial==numtrial && Nb_switch==9
                    niveau=niveau+1; %task_diff=0.6; task_diff_bonus=0.5;
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{33}], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, text{42}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{43}, 'center', video.y*0.9, 0.5);
                % Niveau 4 : diff=600mss & bonus=500ms --------------------
                elseif niveau==4 && itrial==numtrial && Nb_switch==12
                    niveau=niveau+1; %task_diff=0.5; task_diff_bonus=0.4;
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{33}], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, text{42}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{43}, 'center', video.y*0.9, 0.5);
                % Niveau 5 : diff=500mss & bonus=400ms --------------------
                elseif niveau==5 && itrial==1 && Nb_switch==15
                    niveau=niveau+1; %task_diff=0.4; task_diff_bonus=0.35;
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{33}], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, text{42}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{43}, 'center', video.y*0.9, 0.5);
                % Niveau 6 : diff=400mss & bonus=350ms --------------------
                elseif niveau==6 && itrial==numtrial && Nb_switch==18
                    niveau=niveau+1; %task_diff=0.35; task_diff_bonus=0.3;
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{33}], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, text{42}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{43}, 'center', video.y*0.9, 0.5);
                % Niveau 7 : diff=350mss & bonus=300ms --------------------
                elseif niveau==7 && itrial==numtrial && Nb_switch==21
                    niveau=niveau+1; %task_diff=0.3; task_diff_bonus=0.25;
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{33}], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, text{42}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{43}, 'center', video.y*0.9, 0.5);
                % Niveau 8 : diff=300mss & bonus=250ms --------------------
                elseif niveau==8 && itrial==numtrial && Nb_switch==24
                    niveau=niveau+1; 
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{33}], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, [text{44} num2str(niveau) text{45} num2str(niveau) '.'], 'center', video.y*0.8, 0.7);
                    DrawFormattedText(video.h, text{46}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{43}, 'center', video.y*0.9, 0.5);
                % Niveau 9 : BLOC CONTROL "pr�cision" ---------------------
                elseif niveau==9 && itrial==numtrial-1 && Nb_switch==24
                    niveau=niveau+1; task_diff_bonus=0.2;
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{28} ' !' ], 'center',video.y*0.25, 1); Nb_bonus=100;
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, [text{44} num2str(niveau) text{47}], 'center', video.y*0.8, 0.7);
                    DrawFormattedText(video.h, text{48}, 'center', video.y*0.85, 0.7);
                    DrawFormattedText(video.h, text{2}, 'center', video.y*0.9, 0.5);
                % Niveau 10 : BLOC CONTROL "rapidit�" ---------------------
                elseif niveau==10 && itrial==numtrial && Nb_switch==37
                    niveau=niveau+1; 
                    DrawFormattedText(video.h, [text{32} num2str(Nb_bonus) text{28} ' !' ], 'center',video.y*0.25, 1); Nb_bonus=100; 
                    DrawFormattedText(video.h, [text{34} num2str(niveau-1) text{35}], video.x*0.4,video.y*0.15, 1);
                    DrawFormattedText(video.h, [text{36} num2str(Points) text{37}],video.x*0.35 ,video.y*0.4, 1); % CAGNOTTE
                    DrawFormattedText(video.h, [text{38} num2str(mean_rt) text{39}],video.x*0.35 ,video.y*0.5, 1); rt2=[];% TEMPS
                    DrawFormattedText(video.h, [text{40} num2str(mean_accu) text{41}],video.x*0.35 ,video.y*0.6, 1);  accu2=[]; % GOOD
                    DrawFormattedText(video.h, text{2}, 'center', video.y*0.9, 0.5);
                end
                
                if Nb_bonus==100
                    Nb_bonus=0;
                    if task_diff==2,       task_diff=1;    task_diff_bonus=0.8;    % niveau 2
                    elseif task_diff==1,   task_diff=0.8;  task_diff_bonus=0.6;    % niveau 3
                    elseif task_diff==0.8, task_diff=0.6;  task_diff_bonus=0.5;    % niveau 4
                    elseif task_diff==0.6, task_diff=0.5;  task_diff_bonus=0.4;    % niveau 5
                    elseif task_diff==0.5, task_diff=0.4;  task_diff_bonus=0.35;   % niveau 6
                    elseif task_diff==0.4, task_diff=0.35; task_diff_bonus=0.3;    % niveau 7
                    elseif task_diff==0.35, task_diff=0.3; task_diff_bonus=0.25;   % niveau 8
                    end
                    baseRect_jpg = [0 0 160 80]; dstRects = nan(4, 1);
                    dstRects(:, 1) = CenterRectOnPointd(baseRect_jpg, video.x*0.56, video.y*0.15);  baseRect_jpg = [0 0 80 80];
                    dstRects(:, 2) = CenterRectOnPointd(baseRect_jpg, video.x*0.3, video.y*0.4);
                    dstRects(:, 3) = CenterRectOnPointd(baseRect_jpg, video.x*0.3, video.y*0.5);
                    dstRects(:, 4) = CenterRectOnPointd(baseRect_jpg, video.x*0.3, video.y*0.6);
                    if niveau==2        theImage = imread('niveau0_5.jpg'); DrawFormattedText(video.h, [text{61} num2str(task_diff) text{62} num2str(niveau) '.'], 'center', video.y*0.8, 0.7);
                    elseif niveau==3    theImage = imread('niveau1.jpg');   DrawFormattedText(video.h, [text{61} num2str(task_diff*1000) text{63} num2str(niveau) '.'], 'center', video.y*0.8, 0.7);
                    elseif niveau==4    theImage = imread('niveau1_5.jpg'); DrawFormattedText(video.h, [text{61} num2str(task_diff*1000) text{63} num2str(niveau) '.'], 'center', video.y*0.8, 0.7);
                    elseif niveau==5    theImage = imread('niveau2.jpg');   DrawFormattedText(video.h, [text{61} num2str(task_diff*1000) text{63} num2str(niveau) '.'], 'center', video.y*0.8, 0.7);
                    elseif niveau==6    theImage = imread('niveau2_5.jpg'); DrawFormattedText(video.h, [text{61} num2str(task_diff*1000) text{63} num2str(niveau) '.'], 'center', video.y*0.8, 0.7);
                    elseif niveau==7    theImage = imread('niveau3.jpg');   DrawFormattedText(video.h, [text{61} num2str(task_diff*1000) text{63} num2str(niveau) '.'], 'center', video.y*0.8, 0.7);
                    elseif niveau==8    theImage = imread('niveau3_5.jpg'); DrawFormattedText(video.h, [text{61} num2str(task_diff*1000) text{63} num2str(niveau) '.'], 'center', video.y*0.8, 0.7);
                    elseif niveau==9    theImage = imread('niveau4.jpg'); 
                    elseif niveau==10    theImage = imread('niveau4_5.jpg'); 
                    elseif niveau==11    theImage = imread('niveau5.jpg'); 
                    end
                        imageTexture = Screen('MakeTexture', video.h, theImage); % Load and make the image into a texture
                        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,1), 0); % Draw the image to the screen
                    theImage = imread('pieces.jpg'); imageTexture = Screen('MakeTexture', video.h, theImage); % Load and make the image into a texture
                        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,2), 0); % Draw the image to the screen
                    theImage = imread('temps.jpg'); imageTexture = Screen('MakeTexture', video.h, theImage); % Load and make the image into a texture
                        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,3), 0); % Draw the image to the screen
                    theImage = imread('good.jpg'); imageTexture = Screen('MakeTexture', video.h, theImage); % Load and make the image into a texture
                        Screen('DrawTexture', video.h, imageTexture, [], dstRects(:,4), 0); % Draw the image to the screen
                     Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop keyquit]); 
                     if isequal(key,1)
                         if niveau<11
                         nominalFrameRate = Screen('NominalFrameRate', video.h); % Get the nominal framerate of the monitor.
                         presSecs = sort(repmat(1:3, 1, nominalFrameRate), 'descend'); % list of the number we are going to present on each frame.
                         for i = 1:length(presSecs) % Here is our drawing loop
                            numberString = num2str(presSecs(i)); % Convert number into a string
                            DrawFormattedText(video.h, numberString, 'center', 'center', 1); % Draw our number to the screen
                            Screen('Flip', video.h); % Flip to the screen
                         end
                         end
                         trig.bloc=30+niveau; param.fun.trigger(trig.bloc, param.hport_trig);
                     end
                     if isequal(key,2) 
                         trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
                         stopped = true; break; 
                     end
                     if isequal(key,3) 
                         if task_diff==1,       task_diff=2;    task_diff_bonus=1;
                         elseif task_diff==0.8, task_diff=1;    task_diff_bonus=0.8;
                         elseif task_diff==0.6, task_diff=0.8;  task_diff_bonus=0.6;
                         elseif task_diff==0.5, task_diff=0.6;  task_diff_bonus=0.5;
                         elseif task_diff==0.4, task_diff=0.5;  task_diff_bonus=0.4;
                         elseif task_diff==0.35, task_diff=0.4;  task_diff_bonus=0.35;
                         elseif task_diff==0.3, task_diff=0.35;  task_diff_bonus=0.3;
                         end
                     end
                end
             
             if stopped==true; break; end   
             end % for itrial=1:numtrial
             % END of LOOP 4 --- from 1 to numtrials NSW+SW
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             
        %%%%%%%%%%%%% one NSW-SW trial sequence= DONE
        Passation.Data.Response = response;
        Passation.Data.Timecode = timecode;
        Passation.Data.Trials = trials;
%         save([Passation.Filename '_Bloc_' num2str(blocidx)],'Passation');
%         assignin('base','Passation', Passation);

        if stopped==true; break; end
        end % for switch_seq=1:length(num_nsw_vl) %end of a switch-non-switch sequence
        % END of LOOP 3 --- from 1 to n_trials_within_volatility 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
         % Save data in temporary file just in case...after each volatility
             % level ?
        if ~stopped
            % Temporary backup: tic - toc ???
            save([Passation.Filename '_Bloc_' num2str(blocidx)],'Passation');
            assignin('base','Passation', Passation);
            trig.start=60; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
        end
    
    if stopped==true; break; end
    end % for volatility_level=1:3 %end of all volatility levels (basically, this is the end of one blox of trial)
    %%%%%%%%%%%%%%%%%%%%%%%
    % END of LOOP 2 --- from 1 to 3 (max volatility level)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ~stopped
        Points_Exp(iSujet+1,blocidx) = Points;
        [Record,Index] = sortrows(Points_Exp,blocidx);
        DrawFormattedText(video.h, text{53}, 'center',video.y*0.15, 1);
        DrawFormattedText(video.h, [text{54} num2str(Points) text{55}] , 'center',video.y*0.2, 1);
        DrawFormattedText(video.h, [text{56} num2str(niveau-1) text{57}] , 'center',video.y*0.25, 1);

        DrawFormattedText(video.h, text{58}, 'center',video.y*0.4, 1);
        DrawFormattedText(video.h, ['1     ' Name{Index(end)} '     ' num2str(Record(end,blocidx)) text{59}] ,video.x*0.43,video.y*0.45, 0.8);
        DrawFormattedText(video.h, ['2     ' Name{Index(end-1)} '     ' num2str(Record(end-1,blocidx)) text{59}] ,video.x*0.43,video.y*0.49, 0.8);
        DrawFormattedText(video.h, ['3     ' Name{Index(end-2)} '     ' num2str(Record(end-2,blocidx)) text{59}] ,video.x*0.43,video.y*0.53, 0.8);
        DrawFormattedText(video.h, ['4     ' Name{Index(end-3)} '     ' num2str(Record(end-3,blocidx)) text{59}] ,video.x*0.43,video.y*0.57, 0.8);
        DrawFormattedText(video.h, ['5     ' Name{Index(end-4)} '     ' num2str(Record(end-4,blocidx)) text{59}] ,video.x*0.43,video.y*0.61, 0.8);
        DrawFormattedText(video.h, ['6     ' Name{Index(end-5)} '     ' num2str(Record(end-5,blocidx)) text{59}] ,video.x*0.43,video.y*0.65, 0.8);
        DrawFormattedText(video.h, ['7     ' Name{Index(end-6)} '     ' num2str(Record(end-6,blocidx)) text{59}] ,video.x*0.43,video.y*0.69, 0.8);
        DrawFormattedText(video.h, ['8     ' Name{Index(end-7)} '     ' num2str(Record(end-7,blocidx)) text{59}] ,video.x*0.43,video.y*0.73, 0.8);
        Screen('Flip', video.h); WaitKeyPress(keyconfirm);

        DrawFormattedText(video.h, text{60}, 'center', 'center', 1);
        Screen('Flip', video.h); WaitKeyPress(keyconfirm);
    end
    
if stopped==true; break; end    
end % for blocidx=1:num_bloc %%%%%%%%%%%%%%%%  %this is the end of all bloc 

% END of LOOP 1 --- from 1 to num_bloc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Save
if stopped    
    sufx = '_stopped';
    Passation.Filename=[Passation.Filename sufx];
    save([Passation.Filename],'Passation'); 
    trig.start=60; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
end

% Close video etc.
PsychPortAudio('Close', pahandle); % Close the audio device
IOPort('CloseAll');
Priority(0);
Screen('CloseAll');
FlushEvents;
ListenChar(0); 
ShowCursor;
video = [];

% Display result
%switch_ReadData_v2;

return

%%%%%%%%%%%%% THIS IS THE END %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
