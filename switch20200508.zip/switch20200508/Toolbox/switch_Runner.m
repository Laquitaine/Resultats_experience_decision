%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Switch2_Runner.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ======================================================================== 
% 1/ Initialize matlab to run the experiment
%==========================================================================

% a. Setup the workspace --------------------------------------------------
clear('all');  % Clear all variables, globals, functions and MEX links
close('all');  % Close all open figure windows
clc;           % Clear the command window
sca;           % Close all screens, windows, textures, movies and videos
 
diary;         % Save text of Matlab session
profile on     % Profile execution time (see profile viewer)
Priority(2);   % 2 is "real time priority level"

% b. Add paths to the Matlab search directory -----------------------------
switchfolder = fileparts(mfilename('fullpath')); % Current code file path
cd(switchfolder);                                % Change current folder
addpath(switchfolder);                           % Give access to all the  
addpath(fullfile(switchfolder,'Toolbox'));       % file.m of these folders
addpath(fullfile(switchfolder,'Data'));


% c. Variables and parameters ---------------------------------------------
global DEBUG;                    % Define DEBUG as a global variable
global participant;              % Define participant as a global variable
run('switch_TaskParameters.m'); % Parameters importation 


%% ======================================================================== 
% 2/ Dialog box
%==========================================================================

% a. Participant's name ---------------------------------------------------
answer=inputdlg({'What is the participant''s name ?________________'}...
,'Identification',1,{'TEST'});    % Create an input dialog box
if isempty(answer)                % if identification process cancelled
    error('Identification cancelled during the setup.'); % Error message
end


% b. Experiment condition -------------------------------------------------
[selection,ok] = listdlg(...                % Create a list dialog box
    'Name', 'Experiment condition',...      % Dialog box title
    'PromptString','Select a condition',... % Dialog box instruciton
    'SelectionMode','single',...            % Setup single/multiple choice
    'ListString',SESSIONS(:,1), ...         % List of choices
    'ListSize', [ 200 100 ], ...            % Box [width,height] in pixel
    'InitialValue', 1);                     % Setup of default choice 
if ~ok
     error('Experiment condition cancelled during the setup.');
end

   
%% ======================================================================== 
% 3/ Setup of participant's information
%==========================================================================

participant.identifier = answer{1}; % Participant's name
participant.date = datestr(now,...  % Experiment day and hour
    'yyyy.mm.dd at HH:MM'); 
participant.hostname=hostname();    % Computer name
participant.session_number = selection;    % Experiment number 
participant.session = SESSIONS{selection,1}; % Experiment name
participant.flags=flags;            % Save experiment flags
%fprintf('PARTICIPANT INFORMATION:\n\n'); 
%disp(participant);                  % Participant data display
%disp(participant.flags);            % Participant flags display
mkdir(fullfile(switchfolder,['Data\' participant.identifier]));
addpath(fullfile(switchfolder,['Data\' participant.identifier]));

%% ======================================================================== 
% 4/ DEBUG verification
%==========================================================================
if isempty(DEBUG)
    DEBUG = false;
end

if DEBUG   % shorter timings
    %timing.cueduration = 1.5;
    flags.with_response_keyboard = 1;
end


%% ======================================================================== 
% 5/ Run experiment 
%==========================================================================

Screen('CloseAll');
close('all');
 
if DEBUG
    % run experiment
    %  p %%%% I GUESS THIS was An error (JB question ?)
    [Passation,Passation.ErrorMsg] = switch_Experiment(participant);

else
    
    try
        % run experiment
        [Passation,Passation.ErrorMsg] = switch_Experiment(participant);
 
    catch ME                % Execution if an error occurs in "try" section
        Priority(0);        % 0 is "normal priority level"
        Screen('CloseAll'); % Close screens, windows, textures, videos
        FlushEvents;        % Remove events from the system event queue
        ListenChar(0);      % 0 = stop listening to keyboard input
        ShowCursor;         % re-displays the mouse after a "HideCursor"
        video = [];
        disp(ME)            % Display command
        rethrow(ME);        % Reissue error
        return
    end
end


%% ======================================================================== 
% 6/ Save data
%==========================================================================
save(Passation.Filename,'Passation'); % Save structure Passation
if ~DEBUG
    % Let the experimenter add some comments?
    Passation.ExpostComments = inputdlg('Ex-post Commentary','Any comments?',5);
    % re-save
    save(Passation.Filename,'Passation')
end

% rethrow error message
if ~isempty(Passation.ErrorMsg)
    psychrethrow(Passation.ErrorMsg);
end

diary('OFF')    % End of saving text of Matlab session
profile off     % Profile execution time (see profile viewer)

%% THIS IS THE END
return
