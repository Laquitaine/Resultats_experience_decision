%==========================================================================
% Function : SendTriggerLinux
%==========================================================================

function trig=SendTriggerLinux(trig)
command = sprintf('./TRIGGER/trigger %d',trig);
system(command);
return