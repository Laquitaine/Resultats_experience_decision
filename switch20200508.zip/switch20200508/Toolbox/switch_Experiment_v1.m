%==========================================================================
% Function : switch_Experiment
%==========================================================================

function [Passation,errormsg] = switch_Experiment_v1(participant)

% Initialisation of Passation
%==========================================================================
% Definition of Passation DEBUG, Running, TaskParameters, Runner,
% Participant, DataFolder, Filename
%--------------------------------------------------------------------------
global DEBUG                               % Define DEBUG as a global variable
global Points;
global mean_rt;
rt2=[];
mean_rt=[];
Passation=[];                              % Define Passation
errormsg =[];                              % Define errormsg
Passation.DEBUG = DEBUG;                   % Define Passation.DEBUG
Passation.Running = dbstack;               % File information (file:Name.m ; name:Name ; line:999)
for i=1:length(Passation.Running)
    Passation.Running(i).fullpath = which(Passation.Running(i).file); % File location (C:\Users\Name\Documents\File.m)
    Passation.Running(i).filedate = getfield(dir(Passation.Running(i).fullpath),'date'); % Saving date (16-oct.-2018 15:07:49)
    Passation.Running(i).mcode    = ...    % Copy all the actual script
        textread(Passation.Running(i).fullpath,'%s','delimiter','\n');           
end
run('switch_TaskParameters');             % Define various parameters
Passation.TaskParameters = ...             % Copy all the TaskParameter script
    textread(which('switch_TaskParameters'),'%s','delimiter','\n');
Passation.Runner = ...                     % Copy all the Runner script
    textread(which('switch_Runner'),'%s','delimiter','\n');
Passation.Participant = participant;
Passation.DataFolder = fullfile(participant.folder,'Data',participant.identifier); %(C:\...\Matlab\switch) + \Data + \Participant_name
if not(exist(Passation.DataFolder, 'dir')) % Saving data folder exist or not
    if DEBUG
        Passation.DataFolder = fullfile(fileparts(tempname)); % DEBUG => Save in temporary folder
    else
        error('switch:MssingDataFolder','Missing data folder! %s\n', Passation.DataFolder);
    end
end
Passation.Filename=fullfile(...            % Define the filename to save the info
    Passation.DataFolder,sprintf('switch_%s_%s',... % like 
    datestr(now,'yyyymmdd-HHMM'),...       % Datafolder\switch_20181017-1038_lfp
    participant.session));
stopped = false; datresp = [50,51]; keyresp = KbName({'q','m'});
if participant.flags.with_response_logitech
    [gamepadIndices, productNames] = GetGamepadIndices;
    logresp = [5,6];
end

% Save Diary (in ...\switch\data\TEST\switch_20181017-1038_lfp)
%==========================================================================
diary(Passation.Filename) % DIARY ON = begining of saving
fprintf('\n'); 
fprintf('=======================================\n');
fprintf('======= START OF THE EXPERIMENT =======\n');
fprintf('=======================================\n');
fprintf('\n');
trig.start=50; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS

% CLASSEMENT
%==========================================================================
for iSujet=1:1:17
    Name{iSujet}=strcat('Sujet_',num2str(iSujet));
end          
Points_Exp1 = [ 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;...                  % 01
                64 , 64 , 64 , 64 , 64 , 64 , 64 , 64 ;...          % 02
                0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;...                  % 03
                0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;...                  % 04
                0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;...                  % 05
                36 , 36 , 36 , 36 , 36 , 36 , 36 , 36 ;...          % 06
                0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;...                  % 07
                95 , 95 , 95 , 95 , 95 , 95 , 95 , 95 ;...          % 08
                70 , 70 , 70 , 70 , 70 , 70 , 70 , 70 ;...          % 09
                116 , 116 , 116 , 116 , 116 , 116 , 116 , 116 ;...  % 10
                121 , 121 , 121 , 121 , 121 , 121 , 121 , 121 ;...  % 11
                133 , 133 , 133 , 133 , 133 , 133 , 133 , 133 ;...  % 12
                100 , 100 , 100 , 100 , 100 , 100 , 100 , 100 ;...  % 13
                124 , 124 , 124 , 124 , 124 , 124 , 124 , 124 ;...  % 14
                120 , 120 , 120 , 120 , 120 , 120 , 120 , 120 ;...  % 15
                130 , 130 , 130 , 130 , 130 , 130 , 130 , 130 ;...  % 16
                110 , 110 , 110 , 110 , 110 , 110 , 110 , 110 ];    % 17
Name{iSujet+1} = Passation.Participant.identifier;
Points_Exp1(iSujet+1,:) = [ 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ];


% Configuarion
%==========================================================================
% Set important design parameters
%--------------------------------------------------------------------------
num_bloc = 8; % ideally, we would perform 4 blocs of switch trials (duration is about 1h)
stim_rule_type_blocs = [1 1 1 1 1 1 1 1];% stim_rule_type_blocs=stim_rule_type_blocs(randperm(num_bloc));%1=rule after; 2=rule before
bloc_volatility_order = [1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1 ; 1 1 1];
bloc_volatility_order = bloc_volatility_order(randperm(num_bloc),:); % Random permutation of line order
n_trials_within_volatility = 36; %48;%18;%should be a multiple of three and two (and 4)
task_diff=0.5; %500 ms = initial task difficulty (good for training; not so good for experimental sessions)?
task_diff_bonus=0.2;

% Randomize number of non-switch trials for each volatility in a bloc
%--------------------------------------------------------------------------
num_nsw=[];                                                  % Definition
num_nsw(:,1)=repmat([3 4 5 6],1,n_trials_within_volatility/4); % Column 1 [3 4 5...]
num_nsw(:,1)=num_nsw(randperm(length(num_nsw(:,1))),1);      % Randomized column 1
num_nsw(1,1)=10; 

% Number of trials within a bloc
%--------------------------------------------------------------------------
ntrials=sum(num_nsw(:))+(size(num_nsw,1)*size(num_nsw,2)); % number of nsw + number of switch


% Variable intervals
%--------------------------------------------------------------------------
interv=[];
k=1; i=1;
for i=1:1:round((ntrials+4)/4)
    interv(k) = 0.5 + 0.5*(rand-0.5);   % 500ms +/- 250ms
    interv(k+1) = 1 + 0.5*(rand-0.5);   % 1s +/- 250 ms
    interv(k+2) = 1.5 + 0.5*(rand-0.5); % 1.5s +/- 250 ms
    interv(k+3) = 2 + 0.5*(rand-0.5); % 2s +/- 250 ms
    k=k+4;
end
k=[];i=[];
interv_S=interv(1: (size(num_nsw,1)*size(num_nsw,2)) );
interv_S=interv_S(randperm( length(interv_S) ));
interv_NS=interv(1+(size(num_nsw,1)*size(num_nsw,2)) : ntrials );
interv_NS=interv_NS(randperm( length(interv_NS) ));
ind_NS=1;
ind_S=1;


% Initialisation of Psychtoolbox
%==========================================================================
% Open the Psychtoolbox and display various general information about the
% experiment (participant, exp. condition, keyboard inputs)
%--------------------------------------------------------------------------
if participant.flags.with_fullscreen
    video = OpenPTBScreen([]);             % Screen Definition
else
    video = OpenPTBScreen;
end                                        
if DEBUG                                   % #03 DEBUG mode display and wait for keyboard input
    DrawFormattedText(video.h, 'DEBUG MODE', 'center', 'center', 1); Screen('Flip', video.h); KbStrokeWait;
end
if ~DEBUG         % Remove keyboard outputs to matlab screen: REMOVED BY JB TO DEBUG...
    HideCursor;    % Hide the mouse cursor
    FlushEvents;   % Remove events from the system even queue
    ListenChar(2); % 2 = listen to keyboard input and supress any output of keypresses
end

%==========================================================================
% Important section: defines the structures within and between blocs of
% trials. Store information in Passation.Data=Data;
%--------------------------------------------------------------------------

% Stimuli defintion
%==========================================================================
% STEP 1 : 20 pixel white fixation dot at screen center
% STEP 2 : rule or pre-cue display
%    2.1 : pre-cue (stim type) trials = first display peripheric pre-cues
%          and then the central rule
%    2.2 : pre-cue (rule type) trials = first display central rule and then
%          peripheric pre-cues (see the papers of Buchman and Miller in
%          Neuron)
% STEP 3 : 3 squares (stim+rule)
%--------------------------------------------------------------------------
% #1
fix_dot_Xpos = video.xCenter;                             % Center X position in pixels
fix_dot_Ypos = video.yCenter;                             % Center Y position in pixels

% #2.1
baseRect = [0 0 cue_size cue_size];                       % Rect dimension of 50 by 50 pixels
pre_cue_Xpos_tmp = [video.x*0.4, video.x*0.6];          % Screen X positions of the two pre-cue rectangles  % Adjust x coordinates of both pre-cues
pre_cue_Xpos_stim = nan(4, length(pre_cue_Xpos_tmp));     % Create a matrix for all the squares (4,:)
for i = 1:length(pre_cue_Xpos_tmp)                        % that contains (xmin,ymin,xmax,ymax) of each square
    pre_cue_Xpos_stim(:, i) = CenterRectOnPointd(baseRect, pre_cue_Xpos_tmp(i), video.yCenter); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues
pre_cue_colors(:,:,1)=[1 0 1; 1 1 0]';                    % magenta left; yellow right
pre_cue_colors(:,:,2)=[1 1 0;1 0 1 ]';                    % yellow left ; magenta right

% #2.2
pre_cue_Xpos_rule = CenterRectOnPointd(baseRect, video.x*0.5, video.yCenter);%
pre_cue_rule_color=[1 0 1; 1 1 0]';                       % first colomn= rule= magenta; second= yellow

% #3
cue_Xpos_tmp = [video.x*0.4, video.x*0.5, video.x*0.6]; % Screen X positions of our three rectangles
cue_Xpos = nan(4, length(cue_Xpos_tmp));                  % Create a matrix for all the squares (4,:)
for i = 1:length(cue_Xpos_tmp)                            % that contains (xmin,ymin,xmax,ymax) of each square
    cue_Xpos(:, i) = CenterRectOnPointd(baseRect, cue_Xpos_tmp(i), video.yCenter); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues (dirty code...)
cue_colors(:,:,1)=[1 0 1;1 0 1; 1 1 0]';                  % magenta left; yellow right; rule = magenta
cue_colors(:,:,2)=[1 0 1;1 1 0; 1 1 0]';                  % magenta left; yellow right; rule = yellow
cue_colors(:,:,3)=[1 1 0;1 0 1; 1 0 1]';                  % yellow left ; magenta right; rule = magenta
cue_colors(:,:,4)=[1 1 0;1 1 0; 1 0 1]';                  % yellow left ; magenta right; rule = yellow
% % %        cue_colors choice depends on both cue and side codes: is between 1 and 4
% % %        cue_color code=1 or 2 si rule = 0 par exemple mais = 3 ou 4 si on multiplie side par rule

% Initialisation port audio
%==========================================================================
InitializePsychSound(1)                 % Initialize Sounddriver
Snd_channel = 2;                       % Number of channels
Snd_freq = 48000;                       % Frequency of the sound
pahandle = PsychPortAudio('Open', [], 1, 1, Snd_freq, Snd_channel);
PsychPortAudio('Volume', pahandle, 0.5); % Set the volume

%if(1)
    
% #01 Display and wait for keyboard input
DrawFormattedText(video.h, 'DEBUT DE L''EXPERIENCE', 'center', video.y*0.4, 1); 
DrawFormattedText(video.h, 'Appuyez sur ENTREE pour continuer', 'center', video.y*0.9, 0.5);
Screen('Flip', video.h); 
key = WaitKeyPress([keyconfirm keystop]);
if isequal(key,2)   
    trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
    sca;    end


% LOOP 1 --- from 1 to num_bloc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for blocidx=1:num_bloc %befor this was : while seqidx <= nseq && nextblock %this should clearly be modified for switch
    
    stim_rule_type=stim_rule_type_blocs(blocidx); % [1} rule is before or [2] after the stimulus
    Points = 0;
    
    % If Rule after the stimulus (relax temporal pressur if rule is before stimulation)
    %----------------------------------------------------------------------
    if stim_rule_type==2 
            task_diff=task_diff2;
    end
    
    % If trainig mode activated
    %----------------------------------------------------------------------
    is_training = false; % Training data set
    if participant.flags.with_training
        is_training = true;
        ntrials = training.ntrials; % defined in task parameters
        % modify this section for training code, please: TO DO JB
        %     Data.Target    = num2cell(randi(2),2)';
        %     Data.Side      = num2cell(randi(2),2)';
    end
    

    itrial_data=0; % initialize this before the first trial of a bloc;
    
    % Prepare the LogFile and the logging variables (TO BE DEFINED, ALSO)
    %----------------------------------------------------------------------
    
    % Cell definition for num_bloc blocs to save the data in
    response = [];                              % Definition of response
    timecode = [];                              % Definition of timecode
    timecode.fix_onset  = cell(1,num_bloc);     % onset of fixation
    timecode.fix_offset = cell(1,num_bloc);     % offset of fixation
    timecode.precue_onset = cell(1,num_bloc);   % onset of precue (stim or rule)
    timecode.precue_offset = cell(1,num_bloc);  % offset of precue
    timecode.cue_onset = cell(1,num_bloc);      % onset of cue (stim or rule)
    timecode.cue_offset = cell(1,num_bloc);     % offset of cue
    timecode.resp_press = cell(1,num_bloc);     % button press
    timecode.resp_release = cell(1,num_bloc);   % button release
    timecode.feedback_onset= cell(1,num_bloc);  % feedback display on
    timecode.feedback_offset= cell(1,num_bloc); % feedback display off 
    
    % Array definition for 1 bloc to save the data in
    response.resp{blocidx}  = NaN*zeros(1,ntrials); % Response
    response.rt{blocidx}   = NaN*zeros(1,ntrials);  % Reaction Time (RT)
    response.accu{blocidx} = NaN*zeros(1,ntrials);  % Accurate
    timecode.fix_onset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.fix_offset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.precue_onset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.precue_offset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.cue_onset{blocidx} = NaN*zeros(1,ntrials);
    timecode.cue_offset{blocidx} = NaN*zeros(1,ntrials);
    timecode.resp_press{blocidx}  = NaN*zeros(1,ntrials);
    timecode.resp_release{blocidx}= NaN*zeros(1,ntrials);
    timecode.feedback_onset{blocidx}= NaN*zeros(1,ntrials);
    timecode.feedback_offset{blocidx}= NaN*zeros(1,ntrials);
    
    %We obviously also need to monitor, for each trial some event codes: 
    % side, rule, stim_rule_type, volatility, SW/NSW, correct/incorrect (NOT DONE YET)
    
    Passation.Data.Trials.stim_rule_type{blocidx} = NaN*zeros(1,ntrials);  % 1=rule after; 2=rule before
    Passation.Data.Trials.side{blocidx}   = NaN*zeros(1,ntrials);          % 1=MAGENTA left; 2=YELLOW left ??
    Passation.Data.Trials.rule{blocidx} = NaN*zeros(1,ntrials);            % 1=MAGENTA; 2=YELLOW  ??
    Passation.Data.Trials.volatility{blocidx} = NaN*zeros(1,ntrials);      % 1-3 low to high
    Passation.Data.Trials.switch{blocidx} = NaN*zeros(1,ntrials);          % 1 or 2 for NSW-SW
    Passation.Data.Trials.td{blocidx}=NaN*zeros(1,ntrials);                % 1 or 2 for NSW-SW ??
    Passation.Data.Trials.score{blocidx}=NaN*zeros(1,ntrials);
  
    
    % STEP 1:  start a new bloc of trials display 
    %----------------------------------------------------------------------
    fprintf('\n'); 
    fprintf('============== NEW BLOC ==============\n');
    fprintf('\n');
%     DrawFormattedText(video.h, ['Le bloc ' num2str(blocidx) ' est pr�t � commencer !'], 'center', video.y*0.4, 1); 
%     DrawFormattedText(video.h, 'Appuyez sur ENTREE pour commencer ou ECHAP pour quitter', 'center', video.y*0.9, 0.5);
%     Screen('Flip', video.h); 
%     key = WaitKeyPress([keyconfirm keystop]);
    
    % If key = KEYQUIT which is the 2nd choice possible in key
    %----------------------------------------------------------------------
    if isequal(key,2) % 
        DrawFormattedText(video.h, '�tes-vous s�r de vouloir interrompre l''exp�rience ?', 'center', video.y*0.4, 1);
        DrawFormattedText(video.h, '(ECHAP) OUI    /    NON (ENTREE)' , 'center', video.y*0.9, 0.5);
        Screen('Flip', video.h);
        key = WaitKeyPress([keyconfirm keystop]);
        if isequal(1)
            trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS 
            stopped = true;
            break;
        end
    end

    trig.bloc=30+blocidx; param.fun.trigger(trig.bloc, param.hport_trig);
    
    % LOOP 2 --- from 1 to 3 (max volatility level)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for volatility_level=1:1%3
        
        volatility=bloc_volatility_order(blocidx,volatility_level);%1: low; 2=mid; 3=HIGH
        %NOTE FOR LATTER perhaps should be consider to provide a short brake between volatility levels
        num_nsw_vl=num_nsw(:,volatility);                          % number of non-switch within a given volatility level
        rules=repmat([1 2],1,n_trials_within_volatility/2);        % here we make sure that the rule will change between the 18 trials
        pseudo_rd=randperm(length(rules));                         % Randomize the index to get the adequate response
        %% a) the switch trial will either correspond to the same response than the previous non-switch in 33 % of trials
        same_resp_idx=pseudo_rd(1:round(length(rules)*0.33));%%for same response_switch type, we will just have to adjust the side
%         other_resp_idx=pseudo_rd(round(length(rules)*0.33)+1:end);%TO fo this, we also need to know the last_non_switch side
        switch_seq_number=length(num_nsw_vl);
        if is_training
            switch_seq_number=training.switch_seq_number;
            volatility=training.volatility;
        end
        
        ind_NS=1;
        ind_S=1;
        
        % LOOP 3 --- from 1 to n_trials_within_volatility 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for switch_seq=1:length(num_nsw_vl) %18 "sequences of trials"/level of volatility
            numtrial=num_nsw_vl(switch_seq)+1;%number of trials = number of non-switch +1
            %             stim_rule_type=stim_rule_types(switch_seq);
            rule=rules(switch_seq);%will change if trial=num_trial

            % dirty code to randomize the side of the response :
            sides=repmat([1 2],1,round(numtrial/2));%Here I set a sequence of sides 
            sides=sides(randperm(length(sides))); %randomize the side
            
            % LOOP 4 --- from 1 to numtrials NSW+SW
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                
            %% Important loop over nsw+SW trials
             for itrial=1:numtrial %Loop over trials within agiven non-switch+switch sequence NOW
                itrial_data=itrial_data+1;
                
                if numtrial>=10 && itrial==1
                    DrawFormattedText(video.h, '- - BONUS (rappel) - - ', 'center',video.y*0.35, 1);
                    DrawFormattedText(video.h, ['R�pondez en moins de ' num2str(task_diff_bonus*1000) ' ms : '],video.x*0.33,video.y*0.45, 1); 
                    DrawFormattedText(video.h, '+5 points', video.x*0.6,  video.y*0.45, [0 1 0]);
                    DrawFormattedText(video.h, 'Appuyez sur ENTREE pour continuer', 'center', video.y*0.9, 0.5);
                    Screen('Flip', video.h); WaitKeyPress(keyconfirm);
                end
                
                
                
                 %% Parameters for switch same vs. different responses+ SW-NSW
                if itrial<numtrial
                    side=sides(itrial);%c�t� = al�atoire
                    Passation.Data.Trials.switch{itrial_data}=1;%non-switch trials
                elseif itrial==numtrial %% SWITCH TRIAL = rule change
                    Passation.Data.Trials.switch{itrial_data}=2; %switch trials
                    if rule==1  % Rule change (1->2) in the switch case
                        rule=2;
                    elseif rule==2 % Rule change (2->1) in the switch case
                        rule=1;
                    end
                    if ismember(switch_seq,same_resp_idx) %Same response 
                        %= update SIDE during SWitch
                        if side==1
                            side=2;
                        elseif side==2
                            side=1;
                        end
                    else
                        %don't update side variable to set a new response
                    end
                end
                
         %% Monitor few interesting event codes for the logfile
        Passation.Data.Trials.stim_rule_type{itrial_data}=stim_rule_type;
        Passation.Data.Trials.volatility{itrial_data}=volatility;
        Passation.Data.Trials.side{itrial_data}=side;
        Passation.Data.Trials.rule{itrial_data}=rule;   
        Passation.Data.Trials.td{itrial_data}=task_diff;

        %%%%%%%%%%%%%%%%%% STOP ou PAUSE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        if CheckKeyPress(keywait) % STOP
            DrawFormattedText(video.h, '�tes-vous pr�t � continuer ?', 'center', video.y*0.4, 1);
            DrawFormattedText(video.h, '-- Appuyez sur ENTREE pour continuer. --' , 'center', video.y*0.9, 0.5);
            trig.start=55;
            Screen('Flip', video.h); 
            param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
            key = WaitKeyPress([keyconfirm keystop]);
            if isequal(key,2) 
                trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
                stopped=true; break; 
            else trig.start=56; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
            end
        end
        
        %% OK: THERE IT's TIME TO PRESENT ONE TRIAL--------------------------
        
         %% 1. DISPLAY FIXATION POINT + SEND TRIGGER + record logfile data
                DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                % central dot - placeholder for rule
                Screen('DrawDots', video.h, ...
                    [fix_dot_Xpos fix_dot_Ypos], fix_dot_SizePix,...
                    fix_dot_Color, [0 0], 2);
               % Left/Rigth dots - placeholder for colored stim
                Screen('DrawDots', video.h, ...
                    [pre_cue_Xpos_tmp ; fix_dot_Ypos fix_dot_Ypos],...
                    [fix_dot_SizePix fix_dot_SizePix], ...
                    [fix_dot_Color'  fix_dot_Color'], [0 0], 2);  
                Screen('DrawingFinished',video.h);
                % Display / get the time 
                trig.fix=10; % FIXATION TRIGGERS
                tonset_fix = Screen('Flip',video.h);  %get the initial time stamp (not sure when to do this)
                param.fun.trigger(trig.fix, param.hport_trig);
                timecode.fix_onset{itrial_data} = tonset_fix;%LOGFILE DATA:fixation onset
                %%%%%%%%%%%%%%%%%%%%%%
                toffset_fix = Screen('Flip',video.h,tonset_fix+roundfp(timing1.fixduration(),video.ifi));%next flip = end of fixation...
                timecode.fix_offset{itrial_data}  = toffset_fix;  %LOGFILE DATA
               
                
         %% 2. Display pre-cue (fix+pre-cue or rule+pre-cues_absent)
                
                %2.1 DRAWING
                [trig.precue]=draw_precue(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                    pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Xpos_rule,rule,trig.fix);
                DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                %2.2 DISPLAY, trigger and logfile
                %a) get one time stamp to synch with screen
                vbl = Screen('Flip',video.h,toffset_fix); %displaying the pre-cue at this exact timing (tonset_precue)
                if participant.flags.with_triggers
                    trigger(trig.precue,hp2);  % Send trigger right after pre-cue stimulus display
                end
                timecode.precue_onset{itrial_data} = vbl;
                
                % Now we present the precue + we abort the trial in case of premature resp
                %precueTimeFrames=round(timing1.precueduration()/video.ifi); waitframes=1;
                if Passation.Data.Trials.switch{itrial_data}==1   % NON SWITCH trials
                    precueTimeFrames=round( interv_NS(ind_NS) /video.ifi);
                    ind_NS=ind_NS+1;
                elseif Passation.Data.Trials.switch{itrial_data}==2  % SWITCH trials
                    precueTimeFrames=round( interv_S(ind_S) /video.ifi);
                    ind_S=ind_S+1;
                end
                waitframes=1; 
                resp = 0;frame=0;
                
% % %  Clear the response button port, to collect response
        if participant.flags.with_response_lumina
            IOPort('Purge',hport_lum);
        end
% % %         
                while resp==0 && frame<(precueTimeFrames - 1)   %% check for responses during pre-cue drawings
                    for frame = 1:precueTimeFrames - 1
                        if ~resp && participant.flags.with_response_keyboard
                            [resp,t]=CheckKeyPress(keyresp);
                            if resp
                                param.fun.trigger(resp, param.hport_trig);
                                break %
                            end
                        end
                        
                        if ~resp && participant.flags.with_response_lumina
                            [dat, t] = IOPort('Read',hport_lum);
                            t = t(1);
                            if ~isempty(dat) && ismember(dat(1),datresp)
                                resp = find(datresp == dat(1));%this means a response ?
                                param.fun.trigger(resp, param.hport_trig);
                                break %
                            end
                        end
                        if ~resp && participant.flags.with_response_logitech
                           [~,t,Code,~] = KbCheck(gamepadIndices(1));
                           if any(Code(logresp))
                              resp = find(Code(logresp),1); 
                              param.fun.trigger(resp, param.hport_trig);
                              break %
                           end
                        end
                        % Draw the precue (if no response occured)
                        [trig.precue]=draw_precue(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                 pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Xpos_rule,rule,trig.fix);
             DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                        vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi);
                    end
                end
               timecode.precue_offset{itrial_data}  = vbl;   
                
                
         %% 3. DISPLAY cue (always RULE+STIM)
                %DRAWING the CUE
                if resp==0
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    draw_cue(video,rule,cue_colors,side,cue_Xpos); %Display the RULE for one time stamp first+send trigger
                    trig.cue=20; % FIXATION TRIGGERS
                    vbl = Screen('Flip',video.h,vbl);
                    param.fun.trigger(trig.cue, param.hport_trig);
                end
                timecode.cue_onset{itrial_data} = vbl;
                %%%%%%%%%%%%%%%%%%%%%%
                % Now we present the cue while monitoring response (cue disappears in that case ?
                cueTimeFrames=round(timing1.cueduration()/video.ifi);frame=0;
                
    while resp==0 && frame<(cueTimeFrames - 1)  %% check for responses during pre-cue drawings
        for frame = 1:cueTimeFrames - 1            
            if ~resp && participant.flags.with_response_keyboard
                [resp,t]=CheckKeyPress(keyresp);
                if resp
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_lumina
                [dat, t] = IOPort('Read',hport_lum);
                t = t(1);
                if ~isempty(dat) && ismember(dat(1),datresp)
                    resp = find(datresp == dat(1));%this means a response ?
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            if ~resp && participant.flags.with_response_logitech
               [~,t,Code,~] = KbCheck(gamepadIndices(1));
               if any(Code(logresp))
                  resp = find(Code(logresp),1); 
                  param.fun.trigger(resp, param.hport_trig);
                  break %
               end
            end
            
            % Draw the cue (if no response occured)
            draw_cue(video,rule,cue_colors,side,cue_Xpos);
            DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
            % Flip to the screen
            waitframes=2;
            vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi);
        end
    end
    
    %if we still wait the response after cue display time
     [trig.precue]=draw_precue(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                 pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Xpos_rule,rule,trig.fix);
     DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
     toffset_cue = Screen('Flip',video.h,vbl);%next flip = end of cue...
     timecode.cue_offset{itrial_data}  = toffset_cue;
        
     %we still wait for the response at this point
    %in addition, let's end the trial if no response occurs within a given time delay 
            tmp_t= GetSecs;
            while resp==0   %% check for responses during pre-cue drawings
                %first constraint: subject will have about 1 sec to press a button
                if GetSecs>tmp_t+1-(timecode.cue_offset{itrial_data}-timecode.cue_onset{itrial_data}) %0.8 %if GetSecs>tmp_t+0.8 
                    break % miss=1;%no response occured !
                end
                
                if ~resp && participant.flags.with_response_keyboard
                    [resp,t]=CheckKeyPress(keyresp);
                    if resp
                        param.fun.trigger(resp, param.hport_trig);
                    end
                end
                
                if ~resp && participant.flags.with_response_lumina
                    [dat, t] = IOPort('Read',hport_lum);
                    t = t(1);
                    if ~isempty(dat) && ismember(dat(1),datresp)
                        resp = find(datresp == dat(1));%this means a response ?
                        param.fun.trigger(resp, param.hport_trig);
                        break %
                    end
                end
                if ~resp && participant.flags.with_response_logitech
                   [~,t,Code,~] = KbCheck(gamepadIndices(1));
                   if any(Code(logresp))
                      resp = find(Code(logresp),1); 
                      param.fun.trigger(resp, param.hport_trig);
                      break %
                   end
                end
                
            end
            
     if resp==0     param.fun.trigger(resp, param.hport_trig);     end       
     DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);       
     toffset = Screen('Flip',video.h); %after response everything disappears from screen ?
                                     
                if timecode.precue_offset{itrial_data} == timecode.cue_onset{itrial_data} % TOO FAST ANSWER
                    rt = -(precueTimeFrames*video.ifi - timecode.precue_offset{itrial_data} + timecode.precue_onset{itrial_data});
                else
                    rt = t-timecode.cue_onset{itrial_data};
                end
                
                accu = ((side==rule)&&(resp==1)) ||...
                    (   (side~=rule)&&(resp==2));
                
                % Log data
                response.resp{itrial_data} = resp;
                response.rt{itrial_data} = rt;
                response.accu{itrial_data} = accu;
                timecode.stim_offset{itrial_data} = toffset;
                timecode.resp_press{itrial_data} = t;
                
                % Display on experimenter control monitor
                resptype    = 'N/A ';
                
                if resp==0
                    resptype=('miss       ');
                    trig.feedback=70;%slow or incorrect or miss
                else

                    if Passation.Data.Trials.switch{itrial_data}==1 % NON SWITCH
                        %if accu && mean_rt<=task_diff  %%%%%% NEW 2018.12.07
                        %    task_diff=task_diff-0.015; 
                        %elseif accu &&  mean_rt>task_diff
                        %    task_diff=task_diff+0.01; 
                        %end                            %%%%%%%%
                        if accu && rt<task_diff
                            resptype=('hit       ');
                            trig.feedback=80;%FAST correct
                        else
                            resptype=('error       ');
                            trig.feedback=70;%slow or incorrect or miss
                        end
                    
                        
                    elseif Passation.Data.Trials.switch{itrial_data}==2 % SWITCH
                        %for switch trial, don't punish slow RTs !
                        
                        if accu
                            resptype=('hit       ');
                            trig.feedback=85;%correct switch
                            %if task_diff>=.200 %300
                            %    task_diff=task_diff-0.05; %-0.04
                            %else %don't update task_diff
                            %end
                        else
                            resptype=('error       ');
                            trig.feedback=75;%incorrect switch
                            %task_diff=task_diff+0.05; %0.04
                        end
                        
                    end
                end
                fprintf('|RT:% 6dms',round(rt*1000));
                fprintf(' resp:[%d] = %s', resp, resptype);
                
                % Wait patient to release the buttons
                if participant.flags.with_response_lumina ...
                        && ~participant.flags.with_response_keyboard...
                        && ~participant.flags.with_response_mouse
                    % NB : in ASCII/MEDx mode, Lumina buttons send a single
                    % trigger when pressing the buttons i.e. cannot detect
                    % relase nor continuous press
                    fprintf(' [n/a with lumina] ');
                    timecode.resp_release{itrial_data} = NaN;
                    t=WaitSecs('UntilTime',t+timing1.response_release);
                else
                    pressed=true;
                    lastkeypress=t;
                    fprintf(' [waiting release... ');
                    while pressed || (t-lastkeypress) < timing1.response_release
                        pressed=0;
                        if participant.flags.with_response_keyboard
                            pressed = pressed || CheckKeyPress(keyresp);
                        end
                        
                        t = GetSecs;
                        if pressed
                            lastkeypress=t;
                        end
                    end
                    timecode.resp_release{itrial_data} = lastkeypress;
                    fprintf(' %03.0fms]',1000*(timecode.resp_release{itrial_data}-timecode.resp_press{itrial_data}));
                end %OK: button press relased !
                
                if CheckKeyPress(keystop) % STOP
                    sca;
                    PsychPortAudio('Close', pahandle); 
                end
                
                %============MEAN SPEED====================================
                
                if rt>0
                    rt2 = [rt2,rt];
                else
                    rt2 = rt2;
                end
                mean_rt= mean(rt2);
                
                %============TASK DIFF=====================================
                
                if itrial_data<10 %numtrial>=10 itrial<=numtrial-1
                    if rt<0
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) ' ms'], video.x*0.48, video.y*0.5, [1 0 0]); % En rouge
                        Points = Points; 
                    elseif rt>=0 && round(rt*1000)<=task_diff_bonus*1000
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) ' ms'], video.x*0.48, video.y*0.5, [0 1 0]); % En vert
                        Points = Points + 5;
                    else
                        DrawFormattedText(video.h, [num2str(round(rt*1000)) ' ms'], video.x*0.48, video.y*0.5, 1); % En blanc
                        Points = Points; 
                    end

                elseif itrial_data>=10
                    if itrial_data==10
                        task_diff=mean_rt;
                        DrawFormattedText(video.h, '� vous de jouer !', 'center','center', 1);
                    end
                    if rt<0 
                        Points = Points - 1;
                        task_diff = task_diff;      % Unchanged
                        Sound_ToFast(0,pahandle);
                    elseif Passation.Data.Trials.switch{itrial_data}==1 && accu && rt<=task_diff_bonus % NON SWITCH CORRECT VERY FAST
                        Points = Points + 2;
                        task_diff = task_diff;
                        Sound_Excellent(0,pahandle);
                    elseif Passation.Data.Trials.switch{itrial_data}==1 && accu && rt<=task_diff % NON SWITCH CORRECT FAST
                        Points = Points + 2;        % +1 point
                        task_diff=(mean_rt+rt)/2;   % Higher
                    elseif Passation.Data.Trials.switch{itrial_data}==1 && accu && rt>task_diff % NON SWITCH CORRECT SLOW
                        Points = Points - 1;            % -1 point
                        task_diff=mean_rt;              % Lower
                        Sound_Bad(0,pahandle);
                    elseif Passation.Data.Trials.switch{itrial_data}==1 && ~accu && rt<=task_diff % NON SWITCH NOT CORRECT FAST
                        Points = Points;                % 0 point
                        task_diff=mean_rt;              % Lower
                    elseif Passation.Data.Trials.switch{itrial_data}==1 && ~accu && rt>task_diff % NON SWITCH NOT CORRECT SLOW
                        Points = Points;                % 0 point
                        task_diff=mean_rt;              % Lower
                    elseif Passation.Data.Trials.switch{itrial_data}==2 && accu && rt<=task_diff % SWITCH CORRECT FAST
                        if rt>0
                            Points = Points + 4;        % +4 points
                            task_diff=(mean_rt+rt)/2;   % Higher
                        else
                            task_diff = task_diff;      % Unchanged
                        end
                    elseif Passation.Data.Trials.switch{itrial_data}==2 && accu && rt>task_diff % SWITCH CORRECT SLOW
                        Points = Points + 4;            % +4 points
                        task_diff=(mean_rt+min(rt2))/2; % Higher
                    elseif Passation.Data.Trials.switch{itrial_data}==2 && ~accu && rt<=task_diff % SWITCH NOT CORRECT FAST
                        Points = Points;                % 0 point
                        task_diff=task_diff;            % Unchanged
                    elseif Passation.Data.Trials.switch{itrial_data}==2 && ~accu && rt>task_diff % SWITCH NOT CORRECT SLOW
                        Points = Points;                % 0 point
                        task_diff=task_diff;            % Unchanged
                    end
                end 
                
                Passation.Data.Trials.score{itrial_data}=Points;
                % trials.score{itrial_data}=Points;
                
         %% 5. FEEDBACK
                if itrial_data<=10
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    tonset_feedback = Screen('Flip',video.h);%DRAW FEEDBACK and play sound (can this be simultaneous ?)
                else
                    tonset_feedback = toffset;
                end
                %param.fun.trigger(trig.feedback, param.hport_trig);

                if itrial_data<10 && rt>=0 && round(rt*1000)<=task_diff_bonus*1000
                    Sound_Excellent(0,pahandle);
                end
                
                timecode.feedback_onset{itrial_data} = tonset_feedback;
                if itrial_data<10
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    toffset_feedback = Screen('Flip',video.h,tonset_feedback+roundfp(timing1.feedbackduration,video.ifi));%next flip = end of pre-cue...
                elseif itrial_data==10
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    toffset_feedback = Screen('Flip',video.h,tonset_feedback+1.5*roundfp(timing1.feedbackduration,video.ifi));
                else
                    toffset_feedback = toffset;
                end
                
                timecode.feedback_offset{itrial_data}  = toffset_feedback;
                
             %% one trial DISPLAY = DONE (fix--pre_cue--cue--resp--feedback) = DONE
             
             if stopped==true; break; end   
             end % for itrial=1:numtrial
             % END of LOOP 4 --- from 1 to numtrials NSW+SW
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             
                            %% one NSW-SW trial sequence= DONE
        Passation.Data.Response = response;
        Passation.Data.Timecode = timecode;
        %Passation.Data.Trials = trials;

        if stopped==true; break; end
        end % for switch_seq=1:length(num_nsw_vl) %end of a switch-non-switch sequence
        % END of LOOP 3 --- from 1 to n_trials_within_volatility 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        if ~stopped
            save([Passation.Filename '_Bloc_' num2str(blocidx)],'Passation');
            assignin('base','Passation', Passation);
            fprintf('Session data are saved in: %s\n', [Passation.Filename '_Bloc_' num2str(blocidx)]);
            trig.start=60; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
        end

    if stopped==true; break; end    
    end % for volatility_level=1:3 %end of all volatility levels (basically, this is the end of one blox of trial)
    %%%%%%%%%%%%%%%%%%%%%%%
    % END of LOOP 2 --- from 1 to 3 (max volatility level)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Points_Exp1(iSujet+1,blocidx) = Points;
    [Record,Index] = sortrows(Points_Exp1,blocidx);
    DrawFormattedText(video.h, 'RESULTAT ET CLASSEMENT', 'center',video.y*0.15, 1);
    DrawFormattedText(video.h, ['Vous avez obtenu un score de ' num2str(Points) ' points !'] , 'center',video.y*0.25, 1);
    DrawFormattedText(video.h, ['Bloc 1     ' num2str(Points_Exp1(iSujet+1,1)) ' pts'] ,video.x*0.25,video.y*0.35, 0.8);
    DrawFormattedText(video.h, ['Bloc 2     ' num2str(Points_Exp1(iSujet+1,2)) ' pts'] ,video.x*0.25,video.y*0.39, 0.8);
    DrawFormattedText(video.h, ['Bloc 3     ' num2str(Points_Exp1(iSujet+1,3)) ' pts'] ,video.x*0.25,video.y*0.43, 0.8);
    DrawFormattedText(video.h, ['Bloc 4     ' num2str(Points_Exp1(iSujet+1,4)) ' pts'] ,video.x*0.25,video.y*0.47, 0.8);
    DrawFormattedText(video.h, ['Bloc 5     ' num2str(Points_Exp1(iSujet+1,5)) ' pts'] ,video.x*0.25,video.y*0.51, 0.8);
    DrawFormattedText(video.h, ['Bloc 6     ' num2str(Points_Exp1(iSujet+1,6)) ' pts'] ,video.x*0.25,video.y*0.55, 0.8);
    DrawFormattedText(video.h, ['Bloc 7     ' num2str(Points_Exp1(iSujet+1,7)) ' pts'] ,video.x*0.25,video.y*0.59, 0.8);
    DrawFormattedText(video.h, ['Bloc 8     ' num2str(Points_Exp1(iSujet+1,8)) ' pts'] ,video.x*0.25,video.y*0.63, 0.8);
    
    DrawFormattedText(video.h, ['1     ' Name{Index(end)} '     ' num2str(Record(end,blocidx)) ' pts'] ,video.x*0.55,video.y*0.35, 0.8);
    DrawFormattedText(video.h, ['2     ' Name{Index(end-1)} '     ' num2str(Record(end-1,blocidx)) ' pts'] ,video.x*0.55,video.y*0.39, 0.8);
    DrawFormattedText(video.h, ['3     ' Name{Index(end-2)} '     ' num2str(Record(end-2,blocidx)) ' pts'] ,video.x*0.55,video.y*0.43, 0.8);
    DrawFormattedText(video.h, ['4     ' Name{Index(end-3)} '     ' num2str(Record(end-3,blocidx)) ' pts'] ,video.x*0.55,video.y*0.47, 0.8);
    DrawFormattedText(video.h, ['5     ' Name{Index(end-4)} '     ' num2str(Record(end-4,blocidx)) ' pts'] ,video.x*0.55,video.y*0.51, 0.8);
    DrawFormattedText(video.h, ['6     ' Name{Index(end-5)} '     ' num2str(Record(end-5,blocidx)) ' pts'] ,video.x*0.55,video.y*0.55, 0.8);
    DrawFormattedText(video.h, ['7     ' Name{Index(end-6)} '     ' num2str(Record(end-6,blocidx)) ' pts'] ,video.x*0.55,video.y*0.59, 0.8);
    DrawFormattedText(video.h, ['8     ' Name{Index(end-7)} '     ' num2str(Record(end-7,blocidx)) ' pts'] ,video.x*0.55,video.y*0.63, 0.8);

    if blocidx<num_bloc
        DrawFormattedText(video.h, ['Le bloc ' num2str(blocidx+1) ' est pr�t � commencer !'], 'center',video.y*0.75, 1);
        DrawFormattedText(video.h, 'Appuyez sur ENTREE pour continuer', 'center', video.y*0.9, 0.5);
        Screen('Flip', video.h); WaitKeyPress(keyconfirm);
    elseif blocidx==num_bloc
        DrawFormattedText(video.h, 'FIN DE L''EXPERIENCE', video.y*0.8, 1);
        Screen('Flip', video.h); WaitKeyPress(keyconfirm);
    end

if stopped==true; break; end    
end % for blocidx=1:num_bloc %%%%%%%%%%%%%%%%  %this is the end of all bloc 
%end % if experiement
% END of LOOP 1 --- from 1 to num_bloc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
if participant.flags.with_eyetracker && ~is_training
    fprintf('Stopping Eyetracker ...');
    Eyelink('StopRecording');
    fprintf('recording stopped.\n');
end
if participant.flags.with_response_lumina
    IOPort('Close',hport_lum); % Close response port
end   
if participant.flags.with_triggers
    IOPort('Close',hport_trig); % close trigger port % CloseParPort;
end

% Save
if stopped    
    sufx = '_Bloc_stopped';
    Passation.Filename=[Passation.Filename sufx];
    save([Passation.Filename],'Passation'); 
    fprintf('\n Session data are saved in: %s\n', Passation.Filename);
    trig.start=60; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
end

% Close video etc.
PsychPortAudio('Close', pahandle); % Close the audio device
IOPort('CloseAll');
Priority(0);
Screen('CloseAll');
FlushEvents;
ListenChar(0); 
ShowCursor;
video = [];

return

%%%%%%%%%%%%% THIS IS THE END %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
