%==========================================================================
% Function : OnlineMonitoring
%==========================================================================

function OnlineMonitoring(data,iblock)
% Output text on-line en console: Acc locale: n=10 essais
% Rep target/nontarget
% info header
% graphe
% + RT/predicVve info (pour les hits)
% + sVm (eg. Bleu,S>S)
% + acVon (rouge,S>A)
%try
if isfield(data,'Data')
    data=data.Data;
end
if nargin<2
    iblock=find(~cellfun('isempty',data.Response.resp),1,'last');
end
accbloc = 100*meannan([data.Response.accu{iblock}]);
rt = 1000*[data.Response.rt{:}];
accu = [data.Response.accu{:}];
acctask = 100*meannan(accu);
fprintf('Accuracy for bloc (%d trials): %f%% / whole task: %f%%',sum(~isnan([data.Response.accu{iblock}])),accbloc,acctask);
fprintf('\n');
if isfield(data, 'IdealPred')
    pred = [data.IdealPred.Stim];
    pred = [pred.Actual];
    pred=pred(1:numel(rt));
    rt = rt(accu==1);
    pred = pred(accu==1);
    accu=accu(accu==1);
    % Plot RT/Pred for hits only
    [i,i]=sort(pred);
    edges=i(floor((0:.2:.99)*numel(i))+1);
    [c,i_c]=histc(pred(accu==1),[  pred(edges) Inf]);
    bar(1:5,[ groupfun(rt(accu==1),i_c,'mean') ]);
    hold on;
    for j=1:5;
        plot(j+rand(sum(i_c==j&accu==1),1)/2-.25,rt(i(i_c==j&accu==1))','ok');
    end;
    hold off
    xlabel('Predictability')
    ylabel('Reaction Time (ms)')
end