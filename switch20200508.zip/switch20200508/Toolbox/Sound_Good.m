%==========================================================================
% Function : Sound_Good
%==========================================================================

function Sound_Good(delay,pahandle)

%myBeep5 = MakeBeep(600, 1/8, 48000); % Create a beep
%PsychPortAudio('FillBuffer', pahandle, [myBeep5; myBeep5]); % Fill the audio playback buffer with the audio data
%PsychPortAudio('Start', pahandle, 1, delay, 1); % Start audio playback
%PsychPortAudio('Stop', pahandle, 1, 1);

myBeep6 = MakeBeep(1100, 1/8, 48000); % Create a beep
PsychPortAudio('FillBuffer', pahandle, [myBeep6; myBeep6]);
PsychPortAudio('Start', pahandle, 1, 0, 1); % Start audio playback
PsychPortAudio('Stop', pahandle, 1, 1);
