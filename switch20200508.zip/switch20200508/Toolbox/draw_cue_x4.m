%==========================================================================
% Function : draw_cue
%==========================================================================

function draw_cue_x4(video,rule,cue_colors,side,cue_Xpos)
 if rule==1 %adjust cue color
                    Screen('FillRect', video.h, cue_colors(:,:,side), cue_Xpos); %this takes from 1 to 4 color_codes
 elseif rule==2
                    Screen('FillRect', video.h, cue_colors(:,:,2*rule+side), cue_Xpos);%this takes from 5 to 8 color_codes
 end
 Screen('DrawingFinished',video.h); % No more drawing before the next Screen('Flip' or 'AsyncFlipBegin')
 
 % windowPtr = video.h