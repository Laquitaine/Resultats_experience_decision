%==========================================================================
% Function : switch_Experiment
%==========================================================================

function [Passation,errormsg] = switch_Experiment_v2(participant)

% Initialisation of Passation
%==========================================================================
% Definition of Passation DEBUG, Running, TaskParameters, Runner,
% Participant, DataFolder, Filename
%--------------------------------------------------------------------------
global DEBUG                                % Define DEBUG as a global variable
global Points;
global mean_rt;
rt2=[];
mean_rt=[];
Passation=[];                               % Define Passation
errormsg =[];                               % Define errormsg
Passation.DEBUG = DEBUG;                    % Define Passation.DEBUG
Passation.Running = dbstack;                % File information (file:Name.m ; name:Name ; line:999)
for i=1:length(Passation.Running)
    Passation.Running(i).fullpath = which(Passation.Running(i).file); % File location (C:\Users\Name\Documents\File.m)
    Passation.Running(i).filedate = getfield(dir(Passation.Running(i).fullpath),'date'); % Saving date (16-oct.-2018 15:07:49)
    Passation.Running(i).mcode    = ...     % Copy all the actual script
        textread(Passation.Running(i).fullpath,'%s','delimiter','\n');           
end
run('switch_TaskParameters');               % Define various parameters
Passation.TaskParameters = ...              % Copy all the TaskParameter script
    textread(which('switch_TaskParameters'),'%s','delimiter','\n');
Passation.Runner = ...                      % Copy all the Runner script
    textread(which('switch_Runner'),'%s','delimiter','\n');
Passation.Participant = participant;
Passation.DataFolder = fullfile(participant.folder,'Data',participant.identifier); %(C:\...\Matlab\switch) + \Data + \Participant_name
if not(exist(Passation.DataFolder, 'dir'))  % Saving data folder exist or not
    if DEBUG
        Passation.DataFolder = fullfile(fileparts(tempname)); % DEBUG => Save in temporary folder
    else
        error('switch:MssingDataFolder','Missing data folder! %s\n', Passation.DataFolder);
    end
end
Passation.Filename=fullfile(...             % Define the filename to save the info
    Passation.DataFolder,sprintf('switch_%s_%s',... % like 
    datestr(now,'yyyymmdd-HHMM'),...        % Datafolder\switch_20181017-1038_lfp
    participant.session));
stopped = false;
if participant.flags.with_response_logitech
    [gamepadIndices, productNames] = GetGamepadIndices;
end

% Save Diary (in ...\switch\data\TEST\switch_20181017-1038_lfp)
%==========================================================================
diary(Passation.Filename)                   % DIARY ON = begining of saving
fprintf('\n'); 
fprintf('=======================================\n');
fprintf('======= START OF THE EXPERIMENT =======\n');
fprintf('=======================================\n');
fprintf('\n');
trig.start=50; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS

% CLASSEMENT
%==========================================================================
for iSujet=1:1:15
    Name{iSujet}=strcat('Sujet_',num2str(iSujet));
end          
Points_Exp = [  313 , 313 , 313 , 313 , 313 , 313 , 313 , 313 ;... % 01 -- avec 48 switch p/ bloc (56') : 417*36/48
                239 , 239 , 239 , 239 , 239 , 239 , 239 , 239 ;... % 02 -- avec 42 switch p/ bloc (52') : 279*36/42
                249 , 249 , 249 , 249 , 249 , 249 , 249 , 249 ;... % 03 -- avec 36 switch p/ bloc (48')
                258 , 258 , 258 , 258 , 258 , 258 , 258 , 258 ;... % 04 -- (48')
                262 , 262 , 262 , 262 , 262 , 262 , 262 , 262 ;... % 05
                232 , 232 , 232 , 232 , 232 , 232 , 232 , 232 ;... % 06
                220 , 220 , 220 , 220 , 220 , 220 , 220 , 220 ;... % 07
                185 , 185 , 185 , 185 , 185 , 185 , 185 , 185 ;... % 08
                228 , 228 , 228 , 228 , 228 , 228 , 228 , 228 ;... % 09
                234 , 234 , 234 , 234 , 234 , 234 , 234 , 234 ;... % 10
                240 , 240 , 240 , 240 , 240 , 240 , 240 , 240 ;... % 11
                246 , 246 , 246 , 246 , 246 , 246 , 246 , 246 ;... % 12
                208 , 208 , 208 , 208 , 208 , 208 , 208 , 208 ;... % 13
                0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;... % 14
                0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;... % 15
                0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ];...% XX
Name{iSujet+1} = Passation.Participant.identifier;
Points_Exp(iSujet+1,:) = [ 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ];


% Configuarion
%==========================================================================
% Set important design parameters
%--------------------------------------------------------------------------
num_bloc = 6;                               % ideally, we would perform 4 blocs of switch trials (duration is about 1h)
stim_rule_type_blocs = [1 1 1 1 1 1 1 1];   % stim_rule_type_blocs=stim_rule_type_blocs(randperm(num_bloc));%1=rule before; 2=rule after
bloc_volatility_option{1} = [1 1 1 ; 2 2 2 ; 3 3 3 ; 1 1 1 ; 2 2 2 ; 3 3 3]; % N = 0 control | 0 LFP | 0 sEEG
bloc_volatility_option{2} = [3 3 3 ; 2 2 2 ; 1 1 1 ; 3 3 3 ; 2 2 2 ; 1 1 1]; % N = 0 control | 0 LFP | 0 sEEG
bloc_volatility_option{3} = [1 1 1 ; 3 3 3 ; 2 2 2 ; 1 1 1 ; 3 3 3 ; 2 2 2]; % N = 0 control | 0 LFP | 0 sEEG
bloc_volatility_option{4} = [3 3 3 ; 1 1 1 ; 2 2 2 ; 3 3 3 ; 1 1 1 ; 2 2 2]; % N = 0 control | 0 LFP | 0 sEEG
bloc_volatility_option{5} = [2 2 2 ; 3 3 3 ; 1 1 1 ; 2 2 2 ; 3 3 3 ; 1 1 1]; % N = 0 control | 0 LFP | 0 sEEG
bloc_volatility_option{6} = [2 2 2 ; 1 1 1 ; 3 3 3 ; 2 2 2 ; 1 1 1 ; 3 3 3]; % N = 0 control | 0 LFP | 0 sEEG
option_order = round(6*rand(1)+0.5); % nombre entier compris entre 1 et 6
bloc_volatility_order = bloc_volatility_option{option_order};
%bloc_volatility_order = bloc_volatility_order(randperm(num_bloc),:); % Random permutation of line order
n_trials_within_volatility = 48;%18;%should be a multiple of 2(rules) and 3(volatility level)
task_diff=0.5;                              %500 ms = initial task difficulty (good for training; not so good for experimental sessions)?
task_diff_bonus=0.2;

% Randomize number of non-switch trials for each volatility in a bloc
%--------------------------------------------------------------------------
num_nsw=[];  % Definition
num_nsw(:,1)=repmat([2 3 4],1,n_trials_within_volatility/3); % Column 1 [3 4 5...]
num_nsw(:,1)=num_nsw(randperm(length(num_nsw(:,1))),1);      % Randomized column 1
num_nsw(:,2)=repmat([2 3 4 4 5 6],1,n_trials_within_volatility/6); % Column 1 [3 4 5...]
num_nsw(:,2)=num_nsw(randperm(length(num_nsw(:,2))),2);      % Randomized column 1
num_nsw(:,3)=repmat([4 5 6],1,n_trials_within_volatility/3); % Column 2 [4 5 6...]
num_nsw(:,3)=num_nsw(randperm(length(num_nsw(:,3))),3);      % Randomized column 2

% Number of trials within a bloc
%--------------------------------------------------------------------------
ntrials=sum(num_nsw(:))+(size(num_nsw,1)*size(num_nsw,2)); % number of nsw + number of switch
ntrials_low = sum(num_nsw(:,1))+(size(num_nsw(:,1),1)*size(num_nsw(:,1),2));
ntrials_medium = sum(num_nsw(:,2))+(size(num_nsw(:,2),1)*size(num_nsw(:,2),2));
ntrials_high = sum(num_nsw(:,3))+(size(num_nsw(:,3),1)*size(num_nsw(:,3),2));

% Initialisation of Psychtoolbox
%==========================================================================
% Open the Psychtoolbox and display various general information about the
% experiment (participant, exp. condition, keyboard inputs)
%--------------------------------------------------------------------------
if participant.flags.with_fullscreen
    video = OpenPTBScreen([]);             % Screen Definition
else
    video = OpenPTBScreen;
end                                        
if DEBUG                                   % #03 DEBUG mode display and wait for keyboard input
    DrawFormattedText(video.h, 'DEBUG MODE', 'center', 'center', 1); Screen('Flip', video.h); KbStrokeWait;
end
if ~DEBUG         % Remove keyboard outputs to matlab screen: REMOVED BY JB TO DEBUG...
    HideCursor;    % Hide the mouse cursor
    FlushEvents;   % Remove events from the system even queue
    ListenChar(2); % 2 = listen to keyboard input and supress any output of keypresses
end

%==========================================================================
% Important section: defines the structures within and between blocs of
% trials. Store information in Passation.Data=Data;
%--------------------------------------------------------------------------

% Stimuli defintion
%==========================================================================
% STEP 1 : 20 pixel white fixation dot at screen center
% STEP 2 : rule or pre-cue display
%    2.1 : pre-cue (stim type) trials = first display peripheric pre-cues
%          and then the central rule
%    2.2 : pre-cue (rule type) trials = first display central rule and then
%          peripheric pre-cues (see the papers of Buchman and Miller in
%          Neuron)
% STEP 3 : 3 squares (stim+rule)
%--------------------------------------------------------------------------
% LEFT = left ligne 1 // RIGHT = right ligne 1
% UP = left ligne 2 // DOWN = right ligne 2

% #1 Fixation position
fix_dot_Xpos = video.xCenter;                             % Center X position in pixels
fix_dot_Ypos = video.yCenter;                             % Center Y position in pixels

% #2.1 Pre-cue position and color
baseRect = [0 0 cue_size cue_size];                       % Rect dimension of 50 by 50 pixels
pre_cue_Xpos_tmp = [video.x*0.35, video.x*0.65, video.x*0.43, video.x*0.57];  % Screen X/Y positions of the two pre-cue rectangles  
pre_cue_Ypos_tmp = [video.y*0.4, video.y*0.4, video.y*0.6, video.y*0.6];  % Adjust X/Y coordinates of both pre-cues
pre_cue_Xpos_stim = nan(4, length(pre_cue_Xpos_tmp));     % Create a matrix for all the squares (4,:)
for i = 1:length(pre_cue_Xpos_tmp)                        % that contains (xmin,ymin,xmax,ymax) of each square
    pre_cue_Xpos_stim(:, i) = CenterRectOnPointd(baseRect, pre_cue_Xpos_tmp(i), pre_cue_Ypos_tmp(i)); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues
%                       LEFT / RIGHT /  UP  / DOWN
pre_cue_colors(:,:,1)=[1 0 1 ; 1 1 0 ; 1 0 1 ; 1 1 0]';   % magenta left; yellow right ; magenta up; yellow down
pre_cue_colors(:,:,2)=[1 0 1 ; 1 1 0 ; 1 1 0 ; 1 0 1]';   % magenta left; yellow right ; yellow up ; magenta down
pre_cue_colors(:,:,3)=[1 1 0 ; 1 0 1 ; 1 1 0 ; 1 0 1]';   % yellow left ; magenta right; yellow up ; magenta down
pre_cue_colors(:,:,4)=[1 1 0 ; 1 0 1 ; 1 0 1 ; 1 1 0]';   % yellow left ; magenta right; magenta up; yellow down

% #2.2 Pre-cue rule position and color
pre_cue_Xpos_rule = CenterRectOnPointd(baseRect, video.x*0.5, video.yCenter);%
pre_cue_rule_color=[1 0 1; 1 1 0]';                       % first colomn= rule= magenta; second= yellow

% #3 Cue position and color
cue_Xpos_tmp = [video.x*0.35, video.x*0.5, video.x*0.65, video.x*0.43, video.x*0.57]; % Screen X positions of our three rectangles
cue_Ypos_tmp = [video.y*0.4, video.yCenter, video.y*0.4, video.y*0.6, video.y*0.6];
cue_Xpos = nan(4, length(cue_Xpos_tmp));                  % Create a matrix for all the squares (4,:)
for i = 1:length(cue_Xpos_tmp)                            % that contains (xmin,ymin,xmax,ymax) of each square
    cue_Xpos(:, i) = CenterRectOnPointd(baseRect, cue_Xpos_tmp(i), cue_Ypos_tmp(i)); % centered around an (x,y) position
end                                                       % Possible colors for the pre-cues
%                   LEFT / RULE / RIGHT / UP / DOWN
cue_colors(:,:,1)=[1 0 1 ; 1 0 1 ; 1 1 0 ; 1 0 1 ; 1 1 0]';  % magenta left+up; yellow right+down; rule = magenta
cue_colors(:,:,2)=[1 0 1 ; 1 0 1 ; 1 1 0 ; 1 1 0 ; 1 0 1]';  % magenta left+down; yellow right+up; rule = magenta
cue_colors(:,:,3)=[1 1 0 ; 1 0 1 ; 1 0 1 ; 1 1 0 ; 1 0 1]';  % yellow left+up ; magenta right+down; rule = magenta
cue_colors(:,:,4)=[1 1 0 ; 1 0 1 ; 1 0 1 ; 1 0 1 ; 1 1 0]';  % yellow left+down ; magenta right+up; rule = magenta
cue_colors(:,:,5)=[1 0 1 ; 1 1 0 ; 1 1 0 ; 1 0 1 ; 1 1 0]';  % magenta left+up; yellow right+down; rule = yellow
cue_colors(:,:,6)=[1 0 1 ; 1 1 0 ; 1 1 0 ; 1 1 0 ; 1 0 1]';  % magenta left+down; yellow right+up; rule = yellow
cue_colors(:,:,7)=[1 1 0 ; 1 1 0 ; 1 0 1 ; 1 1 0 ; 1 0 1]';  % yellow left+up ; magenta right+down; rule = yellow
cue_colors(:,:,8)=[1 1 0 ; 1 1 0 ; 1 0 1 ; 1 0 1 ; 1 1 0]';  % yellow left+down ; magenta right+up; rule = yellow

% % %        cue_colors choice depends on both cue and side codes: is between 1 and 4
% % %        cue_color code=1 or 2 si rule = 0 par exemple mais = 3 ou 4 si on multiplie side par rule

% #4 Post-cue (=axe) position and color 
baseRect_HV = [0 0 650  post_cue_short ;...   % Rect dimension of horizonzal axe
               0 0 645  post_cue_short-5 ;... % Rect dimension of horizonzal axe
               0 0 350  post_cue_short ;...   % Rect dimension of horizonzal axe
               0 0 345  post_cue_short-5 ]; % Rect dimension of horizonzal axe
post_cue_Xpos_tmp = [video.xCenter, video.xCenter, video.xCenter, video.xCenter]; % Screen X/Y positions of the two post-cue rectangles  
post_cue_Ypos_tmp = [video.y*0.4, video.y*0.4, video.y*0.6, video.y*0.6]; % Adjust X/Y coordinates of both post-cues
post_cue_Xpos_stim = nan(4, length(post_cue_Xpos_tmp)); % Create a matrix for all the squares (4,:)
for i = 1:length(post_cue_Xpos_tmp)                     % that contains (xmin,ymin,xmax,ymax) of each square
    post_cue_Xpos_stim(:, i) = CenterRectOnPointd(baseRect_HV(i,:), post_cue_Xpos_tmp(i), post_cue_Ypos_tmp(i)); % centered around an (x,y) position
end                                                     % Possible colors for the pre-cues
%                       H white / H black  / V white / V black
post_cue_colors(:,:)=[1 1 1 ; 0 0 0 ; 1 1 1 ; 0 0 0]';  % white horizontal/vertical ; black horizontal/vertical

% Initialisation port audio
%==========================================================================
InitializePsychSound(1)                 % Initialize Sounddriver
Snd_channel = 2;                       % Number of channels
Snd_freq = 48000;                       % Frequency of the sound
pahandle = PsychPortAudio('Open', [], 1, 1, Snd_freq, Snd_channel);
PsychPortAudio('Volume', pahandle, 0.5); % Set the volume

% Initialisation text
%==========================================================================
[text_fr,text_en,text_sv,text_cs] = switch_text_structure('Experiment_v2');
if participant.language==0,     text=text_en.exp; % Anglais
elseif participant.language==1, text=text_fr.exp; % Fran�ais
elseif participant.language==2, text=text_sv.exp; % Suedois
elseif participant.language==3, text=text_cs.exp; % Tch�que
end

% #01 Display and wait for keyboard input
DrawFormattedText(video.h, text{1}, 'center', video.y*0.3, 1);
DrawFormattedText(video.h, text{2}, 'center', video.y*0.9, 0.5);
Screen('Flip', video.h); 
key = WaitKeyPress([keyconfirm keystop]);
if isequal(key,2)   
    trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
    sca;    end


% LOOP 1 --- from 1 to num_bloc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for blocidx=1:num_bloc %befor this was : while seqidx <= nseq && nextblock %this should clearly be modified for switch
    
    stim_rule_type=stim_rule_type_blocs(blocidx); % [1} rule is before or [2] after the stimulus
    Points = 0;
    
    % If Rule after the stimulus (relax temporal pressur if rule is before stimulation)
    %----------------------------------------------------------------------
    if stim_rule_type==2 
            task_diff=task_diff2;
    end
    
    itrial_data=0; % initialize this before the first trial of a bloc;
    if bloc_volatility_order(blocidx,1)==1 % low volatility only
        ntrials = ntrials_low;
    elseif bloc_volatility_order(blocidx,1)==2 % medium volatility only
        ntrials = ntrials_medium;
    elseif bloc_volatility_order(blocidx,1)==3 % high volatility only
        ntrials = ntrials_high;
    end
    
    % Prepare the LogFile and the logging variables (TO BE DEFINED, ALSO)
    %----------------------------------------------------------------------
    
    % Cell definition for num_bloc blocs to save the data in
    response = [];                              % Definition of response
    timecode = [];                              % Definition of timecode
    trials = [];
    timecode.fix_onset  = cell(1,num_bloc);     % onset of fixation
    timecode.fix_offset = cell(1,num_bloc);     % offset of fixation
    timecode.precue_onset = cell(1,num_bloc);   % onset of precue (stim or rule)
    timecode.precue_offset = cell(1,num_bloc);  % offset of precue
    timecode.cue_onset = cell(1,num_bloc);      % onset of cue (stim or rule)
    timecode.cue_offset = cell(1,num_bloc);     % offset of cue
    timecode.postcue_onset = cell(1,num_bloc);  % onset of postcue (axe H/V)
    timecode.postcue_offset = cell(1,num_bloc); % offset of postcue
    timecode.stim_onset = cell(1,num_bloc);  % onset of answer window
    timecode.stim_offset = cell(1,num_bloc);  % offset of answer window
    timecode.resp_press = cell(1,num_bloc);     % button press
    timecode.resp_release = cell(1,num_bloc);   % button release
    timecode.feedback_onset= cell(1,num_bloc);  % feedback display on
    timecode.feedback_offset= cell(1,num_bloc); % feedback display off 
    
    % Array definition for 1 bloc to save the data in
    response.resp{blocidx}  = NaN*zeros(1,ntrials); % Response
    response.rt{blocidx}   = NaN*zeros(1,ntrials);  % Reaction Time (RT)
    response.accu{blocidx} = NaN*zeros(1,ntrials);  % Accurate
    timecode.fix_onset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.fix_offset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.precue_onset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.precue_offset{blocidx}  = NaN*zeros(1,ntrials);
    timecode.cue_onset{blocidx} = NaN*zeros(1,ntrials);
    timecode.cue_offset{blocidx} = NaN*zeros(1,ntrials);
    timecode.postcue_onset{blocidx} = NaN*zeros(1,ntrials);
    timecode.postcue_offset{blocidx} = NaN*zeros(1,ntrials);
    timecode.stim_onset{blocidx} = NaN*zeros(1,ntrials);
    timecode.stim_offset{blocidx} = NaN*zeros(1,ntrials);
    timecode.resp_press{blocidx}  = NaN*zeros(1,ntrials);
    timecode.resp_release{blocidx}= NaN*zeros(1,ntrials);
    timecode.feedback_onset{blocidx}= NaN*zeros(1,ntrials);
    timecode.feedback_offset{blocidx}= NaN*zeros(1,ntrials);
    
    trials.stim_rule_type{blocidx} = NaN*zeros(1,ntrials);  % 1=rule before; 2=rule after
    trials.side{blocidx}   = NaN*zeros(1,ntrials);          % 1=MAGENTA left/up; 2=YELLOW left/down; 3=right/down; 4=right/up
    trials.rule{blocidx} = NaN*zeros(1,ntrials);            % 1=MAGENTA; 2=YELLOW
    trials.axe{blocidx} = NaN*zeros(1,ntrials);             % 1=HORIZONTAL; 2=VERTICAL
    trials.volatility{blocidx} = NaN*zeros(1,ntrials);      % 1-3 low to high
    trials.switch{blocidx} = NaN*zeros(1,ntrials);          % 1=NSM; 2=SW
    trials.td{blocidx}=NaN*zeros(1,ntrials);                % task difficulty (delay allowed)
    trials.score{blocidx}=NaN*zeros(1,ntrials);             % score
    
    % STEP 1:  start a new bloc of trials display 
    %----------------------------------------------------------------------
    fprintf('\n'); 
    fprintf('============== NEW BLOC ==============\n');
    fprintf('\n');
        
    DrawFormattedText(video.h, [text{3} num2str(blocidx)'], 'center', video.y*0.3, 1);
    if bloc_volatility_order(blocidx,1)==1
        DrawFormattedText(video.h, text{4},video.x*0.35 ,video.y*0.4, 1);
    elseif bloc_volatility_order(blocidx,1)==2
        DrawFormattedText(video.h, text{5},video.x*0.35 ,video.y*0.4, 1);
    elseif bloc_volatility_order(blocidx,1)==3
        DrawFormattedText(video.h, text{6},video.x*0.35 ,video.y*0.4, 1);
    end
    DrawFormattedText(video.h, text{7},video.x*0.35 ,video.y*0.5, 1);
    DrawFormattedText(video.h, text{8},video.x*0.35 ,video.y*0.6, 1);
    DrawFormattedText(video.h, text{9}, 'center', video.y*0.9, 0.5);
    Screen('Flip', video.h); 
    key = WaitKeyPress([keyconfirm keystop]);
    if isequal(key,1)
        nominalFrameRate = Screen('NominalFrameRate', video.h); % Get the nominal framerate of the monitor.
        presSecs = sort(repmat(1:3, 1, nominalFrameRate), 'descend'); % list of the number we are going to present on each frame.
        for i = 1:length(presSecs) % Here is our drawing loop
           numberString = num2str(presSecs(i)); % Convert number into a string
           DrawFormattedText(video.h, numberString, 'center', 'center', 1); % Draw our number to the screen
           Screen('Flip', video.h); % Flip to the screen
        end
        trig.bloc=30+blocidx; param.fun.trigger(trig.bloc, param.hport_trig);
    elseif isequal(key,2)   
        trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
        sca;    
    end
    
    % LOOP 2 --- from 1 to 3 (max volatility level)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for volatility_level=1:1
        
        volatility=bloc_volatility_order(blocidx,volatility_level); %1: low; 2=mid; 3=HIGH
        num_nsw_vl=num_nsw(:,volatility);                           % number of non-switch within a given volatility level
        rules=repmat([1 2],1,n_trials_within_volatility/2);         % here we make sure that the rule will change between the 18 trials
        pseudo_rd=randperm(length(rules));                          % Randomize the index to get the adequate response
        
        % a) the switch axe will correspond to the same axe than the previous non-switch in 50 % of trials
        same_axe_idx=pseudo_rd(1:round(length(rules)*0.5));     % H-H or V-V cases
        diff_axe_idx=pseudo_rd(round(length(rules)*0.5)+1:end); % H-V or V-H cases
        
        % b) the switch side will correspond to the same side than the previous non-switch in 50 % of trials
        same_resp_same_side_idx=[];                                                 % 0 repeat + same H side and same V side
        same_resp_diff_side_idx=same_axe_idx(1:round(length(same_axe_idx)*0.67));   % 0.67 repeat + same H (or V) side and different V (or H) side (diffculty variation)
        diff_resp_same_side_idx=same_axe_idx(round(length(same_axe_idx)*0.67)+1:end); % 0.33 alternate + same H side and same V side
        diff_resp_diff_side_idx=[];                                                 % 0 alternate + same H (or V) side and different V (or H) side (diffculty variation)
        
        % c) the switch response will correspond to the same side than the previous non-switch in 33 % of trials
        diff_side0_idx=diff_axe_idx(1:round(length(diff_axe_idx)*0.5));             % 0.5 for 0 axe different from previous
        diff_side1_on_idx=[];                                                       % 0 for 1 axe different from previous = selected axe (diffculty variation)
        diff_side1_off_idx=[];                                                      % 0 for 1 axe different from previous (=/) selected axe (diffculty variation)
        diff_side2_idx=diff_axe_idx(round(length(diff_axe_idx)*0.5)+1:end);         % 0.5 for 2 axe different from previous

        switch_seq_number=length(num_nsw_vl);
        
        % LOOP 3 --- from 1 to n_trials_within_volatility 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for switch_seq=1:length(num_nsw_vl)     % 18 "sequences of trials"/level of volatility
            numtrial=num_nsw_vl(switch_seq)+1;  % number of trials = number of non-switch +1
            rule=rules(switch_seq);             % will change if trial=num_trial
            sides=repmat([1 2 3 4],1,round(numtrial/4)); % Here I set a sequence of sides
            sides=sides(randperm(length(sides))); % randomize the side
            axes=repmat([1 2],1,round(numtrial/2)); % Here I set a sequence of axe Horizontal or Vertical
            axes=axes(randperm(length(axes))); % randomize the side
            
            % LOOP 4 --- from 1 to numtrials NSW+SW
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                
            % Important loop over nsw+SW trials
             for itrial=1:numtrial % Loop over trials within agiven non-switch+switch sequence NOW
                itrial_data=itrial_data+1;
                
                % Parameters for switch same vs. different responses+ SW-NSW
                if itrial<numtrial
                    side=sides(itrial); % c�t� = al�atoire
                    axe=axes(itrial);   % c�t� = al�atoire
                    trials.switch{itrial_data}=1; % non-switch trials
                elseif itrial==numtrial % SWITCH TRIAL = rule change
                    trials.switch{itrial_data}=2; % switch trials
                    if rule==1  % Rule change (1->2) in the switch case
                        rule=2;
                    elseif rule==2 % Rule change (2->1) in the switch case
                        rule=1;
                    end
                    
                    %%%%%%%%% 1 if the same than previous trial (0 if not) %%%%%%%%%%%%
                    
                    if ismember(switch_seq,same_resp_same_side_idx)     % AXE=1 / RESP=1 / SIDE=1
                        if side==1      if axe==1 side=4; elseif axe==2 side=2; end
                        elseif side==2  if axe==1 side=3; elseif axe==2 side=1; end
                        elseif side==3  if axe==1 side=2; elseif axe==2 side=4; end
                        elseif side==4  if axe==1 side=1; elseif axe==2 side=3; end
                        end
                    elseif ismember(switch_seq,same_resp_diff_side_idx) % AXE=1 / RESP=1 / SIDE=0
                        if side==1      side=3; 
                        elseif side==2  side=4;
                        elseif side==3  side=1;
                        elseif side==4  side=2;
                        end
                    elseif ismember(switch_seq,diff_resp_same_side_idx) % AXE=1 / RESP=0 / SIDE=1
                        % Don't need to update side variable to set a new response
                    elseif ismember(switch_seq,diff_resp_diff_side_idx) % AXE=1 / RESP=0 / SIDE=0
                        if side==1      if axe==1 side=2; elseif axe==2 side=4; end
                        elseif side==2  if axe==1 side=1; elseif axe==2 side=3; end
                        elseif side==3  if axe==1 side=4; elseif axe==2 side=2; end
                        elseif side==4  if axe==1 side=3; elseif axe==2 side=1; end
                        end
                    elseif ismember(switch_seq,diff_side0_idx)          % AXE=0 / SIDE=1 with 0 different axis
                        if axe==1       axe=2;
                        elseif axe==2   axe=1;
                        end
                    elseif ismember(switch_seq,diff_side1_on_idx)       % AXE=0 / SIDE=0 with 1 different axis
                        if side==1      if axe==1 axe=2; side=2; elseif axe==2 axe=1; side=4; end
                        elseif side==2  if axe==1 axe=2; side=1; elseif axe==2 axe=1; side=3; end
                        elseif side==3  if axe==1 axe=2; side=4; elseif axe==2 axe=1; side=2; end
                        elseif side==4  if axe==1 axe=2; side=3; elseif axe==2 axe=1; side=1; end
                        end
                    elseif ismember(switch_seq,diff_side1_off_idx)      % AXE=0 / SIDE=0 with 1 different axis
                        if side==1      if axe==1 axe=2; side=4; elseif axe==2 axe=1; side=2; end
                        elseif side==2  if axe==1 axe=2; side=3; elseif axe==2 axe=1; side=1; end
                        elseif side==3  if axe==1 axe=2; side=2; elseif axe==2 axe=1; side=4; end
                        elseif side==4  if axe==1 axe=2; side=1; elseif axe==2 axe=1; side=3; end
                        end
                    elseif ismember(switch_seq,diff_side2_idx)          % AXE=0 / SIDE=0 with 2 different axis
                        if axe==1       axe=2;
                        elseif axe==2   axe=1;
                        end
                        if side==1      side=3;
                        elseif side==2  side=4;
                        elseif side==3  side=1;
                        elseif side==4  side=2;
                        end
                    end
                end
                
        % Monitor few interesting event codes for the logfile %%%%%%%%%%%%%
        trials.stim_rule_type{itrial_data}=stim_rule_type;
        trials.volatility{itrial_data}=volatility;
        trials.side{itrial_data}=side;
        trials.rule{itrial_data}=rule;
        trials.axe{itrial_data}=axe;
        trials.td{itrial_data}=task_diff;

%%%%%%%%%%%%%%%%%% STOP ou PAUSE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        if CheckKeyPress(keywait) % STOP
            DrawFormattedText(video.h, text{10}, 'center', video.y*0.4, 1);
            DrawFormattedText(video.h, text{9} , 'center', video.y*0.9, 0.5);
            trig.start=55;
            Screen('Flip', video.h); 
            param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
            key = WaitKeyPress([keyconfirm keystop]);
            if isequal(key,2) 
                trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
                stopped=true; break; 
            else trig.start=56; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
            end
        end
        
        % OK: THERE IT's TIME TO PRESENT ONE TRIAL %%%%%%%%%%%%%%%%%%%%%%%%
        
%%%%%%%%%%%%% 1. DISPLAY FIXATION POINT + SEND TRIGGER + record logfile data    
            % 1.1 DRAW INSTRUCTIONS
                DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1); % Points
                Screen('DrawDots', video.h, ... % central dot - placeholder for rule
                    [fix_dot_Xpos fix_dot_Ypos], fix_dot_SizePix,...
                    fix_dot_Color, [0 0], 2);
                Screen('DrawDots', video.h, ... % Left/Rigth dots - placeholder for colored stim
                    [pre_cue_Xpos_tmp ; pre_cue_Ypos_tmp],...
                    [fix_dot_SizePix fix_dot_SizePix fix_dot_SizePix fix_dot_SizePix], ...
                    [fix_dot_Color'  fix_dot_Color' fix_dot_Color' fix_dot_Color'], [0 0], 2);  
                Screen('DrawingFinished',video.h);
            % 1.2 DRAW DISPLAY ON : display and get the time 
                trig.fix=10; % FIXATION TRIGGERS
                tonset_fix = Screen('Flip',video.h);  %get the initial time stamp (not sure when to do this)
                param.fun.trigger(trig.fix, param.hport_trig);
                timecode.fix_onset{itrial_data} = tonset_fix;%LOGFILE DATA:fixation onset
            %%%%%%%%%%%%%%%%%%%%%%
                toffset_fix = Screen('Flip',video.h, tonset_fix + roundfp(timing2.fixduration(),video.ifi));%next flip = end of fixation...
                timecode.fix_offset{itrial_data}  = toffset_fix;  %LOGFILE DATA
                
%%%%%%%%%%%%% 2. Display pre-cue (fix+pre-cue or rule+pre-cues_absent)
            % 2.1 DRAW INSTRUCTIONS
                DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                [trig_precue]=draw_precue_x4(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                    pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Ypos_tmp,pre_cue_rule_color,rule,pre_cue_Xpos_rule,trig.fix);
            % 2.2 DRAW DISPLAY ON : display and get the time (HERE get one time stamp to synch with screen= 17ms)
                vbl = Screen('Flip',video.h,toffset_fix); %displaying the pre-cue at this exact timing (tonset_precue)
                timecode.precue_onset{itrial_data} = vbl;
            %%%%%%%%%%%%%%%%%%%%%%
                % Now we present the precue + we abort the trial in case of premature resp
                precueTimeFrames=round(timing2.precueduration()/video.ifi); 
                waitframes=1; resp=0; frame=0;
% % %  Clear the response button port, to collect response
        if participant.flags.with_response_lumina
            IOPort('Purge',hport_lum);
        end
% % %         
                while resp==0 && frame<(precueTimeFrames - 1)   %% check for responses during pre-cue drawings
                    for frame = 1:precueTimeFrames - 1
                        if ~resp && participant.flags.with_response_keyboard
                            [resp,t]=CheckKeyPress(keyresp);
                            if resp
                                param.fun.trigger(resp, param.hport_trig);
                                break %
                            end
                        end
                        
                        if ~resp && participant.flags.with_response_lumina
                            [dat, t] = IOPort('Read',hport_lum);
                            t = t(1);
                            if ~isempty(dat) && ismember(dat(1),datresp)
                                resp = find(datresp == dat(1));%this means a response ?  %CHECK LUMINA RESPONSE HERE:
                                param.fun.trigger(resp, param.hport_trig);
                                break %
                            end
                        end
                        
                        if ~resp && participant.flags.with_response_logitech
                           [~,t,Code,~] = KbCheck(gamepadIndices(1));
                           if any(Code(logresp))
                              resp = find(Code(logresp),1); 
                              param.fun.trigger(resp, param.hport_trig);
                              break %
                           end
                        end
                        
                        % Draw the precue (if no response occured)
                        [trig_precue]=draw_precue_x4(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
                        pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Ypos_tmp, pre_cue_rule_color,rule,pre_cue_Xpos_rule,trig.fix);
                        DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                        vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi);
                    end
                end
               timecode.precue_offset{itrial_data}  = vbl;   
                
                
%%%%%%%%%%%%% 3. DISPLAY cue (always RULE+STIM)
            % 3.1 DRAW INSTRUCTIONS 
                if resp==0
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    draw_cue_x4(video,rule,cue_colors,side,cue_Xpos); %Display the RULE for one time stamp first+send trigger
            % 3.2 DRAW DISPLAY ON
                    trig.cue=20; % FIXATION TRIGGERS
                    vbl = Screen('Flip',video.h,vbl); 
                    param.fun.trigger(trig.cue, param.hport_trig);
                end
                timecode.cue_onset{itrial_data} = vbl;
            %%%%%%%%%%%%%%%%%%%%%%   
                % Now we present the cue while monitoring response (cue disappears in that case ?
                cueTimeFrames=round(timing2.cueduration()/video.ifi);frame=0;

    while resp==0 && frame<(cueTimeFrames - 1)  %% check for responses during pre-cue drawings
        for frame = 1:cueTimeFrames - 1            
            if ~resp && participant.flags.with_response_keyboard
                [resp,t]=CheckKeyPress(keyresp);
                if resp
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_lumina
                [dat, t] = IOPort('Read',hport_lum);
                t = t(1);
                if ~isempty(dat) && ismember(dat(1),datresp)
                    resp = find(datresp == dat(1));%this means a response ?
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_logitech
               [~,t,Code,~] = KbCheck(gamepadIndices(1));
               if any(Code(logresp))
                  resp = find(Code(logresp),1); 
                  param.fun.trigger(resp, param.hport_trig);
                  break %
               end
            end
            
            % Draw the cue (if no response occured)
            draw_cue_x4(video,rule,cue_colors,side,cue_Xpos);
            DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
            vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi); % Flip to the screen
        end
    end
    timecode.cue_offset{itrial_data}  = vbl; 
     
 
%%%%%%%%%%%%% 4. DISPLAY post-cue (always RULE+STIM+AXE)
            % 4.1 DRAW INSTRUCTIONS 
                if resp==0
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    draw_postcue_x4(video,axe,rule,post_cue_colors,cue_colors,side,post_cue_Xpos_stim,cue_Xpos); %Display the RULE for one time stamp first+send trigger
            % 4.2 DRAW DISPLAY ON
                    trig.postcue=30; % FIXATION TRIGGERS
                    vbl = Screen('Flip',video.h,vbl);
                    param.fun.trigger(trig.postcue, param.hport_trig);
                end
                timecode.postcue_onset{itrial_data} = vbl;
            %%%%%%%%%%%%%%%%%%%%%%   
                % Now we present the cue while monitoring response (cue disappears in that case ?
                postcueTimeFrames=round(timing2.postcueduration()/video.ifi);frame=0;
                
    while resp==0 && frame<(postcueTimeFrames - 1)  %% check for responses during pre-cue drawings
        for frame = 1:postcueTimeFrames - 1            
            if ~resp && participant.flags.with_response_keyboard
                [resp,t]=CheckKeyPress(keyresp);
                if resp
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_lumina
                [dat, t] = IOPort('Read',hport_lum);
                t = t(1);
                if ~isempty(dat) && ismember(dat(1),datresp)
                    resp = find(datresp == dat(1));%this means a response ?
                    param.fun.trigger(resp, param.hport_trig);
                    break %
                end
            end
            
            if ~resp && participant.flags.with_response_logitech
               [~,t,Code,~] = KbCheck(gamepadIndices(1));
               if any(Code(logresp))
                  resp = find(Code(logresp),1); 
                  param.fun.trigger(resp, param.hport_trig);
                  break %
               end
            end
            
            % Draw the cue (if no response occured)
            draw_postcue_x4(video,axe,rule,post_cue_colors,cue_colors,side,post_cue_Xpos_stim,cue_Xpos);
            DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
            vbl = Screen('Flip', video.h, vbl + (waitframes - 0.5) * video.ifi); % Flip to the screen
        end
    end
    timecode.postcue_offset{itrial_data}  = vbl;
    
    %if we still wait the response after cue display time 
     draw_cue_x4(video,rule,cue_colors,side,cue_Xpos);
     DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
     tonset = Screen('Flip',video.h,vbl);%next flip = end of cue...
     timecode.stim_onset{itrial_data} = tonset;
     
    %%%%%%%%%%%%%
     %we still wait for the response at this point
    %in addition, let's end the trial if no response occurs within a given time delay 
            tmp_t= GetSecs;
            while resp==0   % check for responses during pre-cue drawings
                %first constraint: subject will have about 1 sec to press a button
                if GetSecs>tmp_t+1.5-(timecode.postcue_offset{itrial_data}-timecode.postcue_onset{itrial_data}) %0.8
                    break % miss=1;%no response occured !
                end
                
                if ~resp && participant.flags.with_response_keyboard
                    [resp,t]=CheckKeyPress(keyresp);
                    if resp
                        param.fun.trigger(resp, param.hport_trig);
                    end
                end
                
                if ~resp && participant.flags.with_response_lumina
                    [dat, t] = IOPort('Read',hport_lum);
                    t = t(1);
                    if ~isempty(dat) && ismember(dat(1),datresp)
                        resp = find(datresp == dat(1));%this means a response ? %CHECK LUMINA RESPONSE HERE:
                        param.fun.trigger(resp, param.hport_trig);
                        break %
                    end
                end
                
                if ~resp && participant.flags.with_response_logitech
                   [~,t,Code,~] = KbCheck(gamepadIndices(1));
                   if any(Code(logresp))
                      resp = find(Code(logresp),1); 
                      param.fun.trigger(resp, param.hport_trig);
                      break %
                   end
                end
                
            end
            
     if resp==0     param.fun.trigger(resp, param.hport_trig);     end
     DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);       
     toffset = Screen('Flip',video.h,tonset); %after response everything disappears from screen ?
     timecode.stim_offset{itrial_data} = toffset;
                                     
                if timecode.precue_offset{itrial_data} == timecode.cue_onset{itrial_data} % TOO FAST ANSWER (before cue display)
                    rt = t - (precueTimeFrames + cueTimeFrames)*video.ifi - timecode.precue_onset{itrial_data};
                elseif timecode.cue_offset{itrial_data} == timecode.postcue_onset{itrial_data} % TOO FAST ANSWER (before postcue display)
                    rt = t - cueTimeFrames*video.ifi - timecode.cue_onset{itrial_data};
                else % GOOD (after postcue display)
                    rt = t - timecode.postcue_onset{itrial_data};
                end
                                            
                if axe==1 && rule==1
                    if (side==1 || side==2) && resp==1      accu=1;
                    elseif (side==3 || side==4) && resp==2  accu=1;
                    else accu=0;
                    end
                elseif axe==1 && rule==2
                    if (side==1 || side==2) && resp==2      accu=1;
                    elseif (side==3 || side==4) && resp==1  accu=1;
                    else accu=0;
                    end                    
                elseif axe==2 && rule==1
                    if (side==1 || side==4) && resp==3      accu=1;
                    elseif (side==2 || side==3) && resp==4  accu=1;
                    else accu=0;
                    end                      
                elseif axe==2 && rule==2
                    if (side==1 || side==4) && resp==4      accu=1;
                    elseif (side==2 || side==3) && resp==3  accu=1;
                    else accu=0;
                    end   
                end
                
                % Log data
                response.resp{itrial_data} = resp;
                response.rt{itrial_data} = rt;
                response.accu{itrial_data} = accu;
                timecode.resp_press{itrial_data} = t;
                
                % Display on experimenter control monitor
                resptype    = 'N/A ';
                
                if resp==0
                    resptype=('miss       ');
                    trig.feedback=70;%slow or incorrect or miss
                else

                    if trials.switch{itrial_data}==1 % NON SWITCH
                        if accu && rt<task_diff
                            resptype=('hit       ');    trig.feedback=80; % FAST correct
                        else
                            resptype=('error       ');  trig.feedback=70; % SLOW or incorrect or miss
                        end
                    elseif trials.switch{itrial_data}==2 % SWITCH   %for switch trial, don't punish slow RTs !
                        if accu
                            resptype=('hit       ');    trig.feedback=85; % correct switch
                        else
                            resptype=('error       ');  trig.feedback=75;%incorrect switch
                        end
                    end
                end
                
                fprintf('\n');
                fprintf('|RT:% 6dms',round(rt*1000));
                fprintf(' resp:[%d] = %s', resp, resptype);
                
                % Wait patient to release the buttons
                if participant.flags.with_response_lumina ...
                        && ~participant.flags.with_response_keyboard...
                        && ~participant.flags.with_response_mouse
                    % NB : in ASCII/MEDx mode, Lumina buttons send a single
                    % trigger when pressing the buttons i.e. cannot detect
                    % relase nor continuous press
                    fprintf(' [n/a with lumina] ');
                    timecode.resp_release{itrial_data} = NaN;
                    t=WaitSecs('UntilTime',t+timing2.response_release);
                else
                    pressed=true;
                    lastkeypress=t;
                    fprintf(' [waiting release... ');
                    while pressed || (t-lastkeypress) < timing2.response_release
                        pressed=0;
                        if participant.flags.with_response_keyboard
                            pressed = pressed || CheckKeyPress(keyresp);
                        end
                        
                        t = GetSecs;
                        if pressed
                            lastkeypress=t;
                        end
                    end
                    timecode.resp_release{itrial_data} = lastkeypress;
                    fprintf(' %03.0fms]',1000*(timecode.resp_release{itrial_data}-timecode.resp_press{itrial_data}));
                end %OK: button press relased !
                
                %============MEAN SPEED====================================
                
                if rt>0
                    rt2 = [rt2,rt];
                else
                    rt2 = rt2;
                end
                mean_rt= mean(rt2);
                
                %============TASK DIFF=====================================
                
                % NEGATIVE TIMING %----------------------------------------
                if rt<=0 
                    Points = Points - 1;        % -1 point
                    task_diff = task_diff;      % Unchanged
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                
                % NON SWITCH CORRECT VERY FAST %---------------------------
                elseif trials.switch{itrial_data}==1 && accu && rt<=task_diff_bonus 
                    Points = Points + 4;        % +4 points
                    task_diff = task_diff;      % Unchanged
                    Sound_Excellent(0,pahandle);% Excellent timing
                
                % NON SWITCH CORRECT FAST %--------------------------------
                elseif trials.switch{itrial_data}==1 && accu && rt<=task_diff 
                    Points = Points + 2;        % +1 point
                    task_diff=(mean_rt+rt)/2;   % Higher
                    Sound_Good(0,pahandle);% Good timing
                
                % NON SWITCH CORRECT SLOW %--------------------------------
                elseif trials.switch{itrial_data}==1 && accu && rt>task_diff 
                    Points = Points - 1;        % -1 point
                    task_diff=mean_rt;          % Lower
                    Sound_Bad(0,pahandle);      % Unvalided timing
                
                % NON SWITCH NOT CORRECT FAST %----------------------------
                elseif trials.switch{itrial_data}==1 && ~accu && rt<=task_diff 
                    Points = Points;                % 0 point
                    task_diff=mean_rt;              % Lower
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                
                % NON SWITCH NOT CORRECT SLOW %----------------------------
                elseif trials.switch{itrial_data}==1 && ~accu && rt>task_diff 
                    Points = Points;                % 0 point
                    task_diff=(mean_rt+rt)/2;       % Lower
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
   
                % SWITCH CORRECT VERY FAST %------------------------------------
                elseif trials.switch{itrial_data}==2 && accu && rt<=task_diff_bonus 
                    Points = Points + 4;        % +4 points
                    task_diff=(mean_rt+rt)/2;   % Higher
                    Sound_Excellent(0,pahandle);% Excellent timing
                    
                % SWITCH CORRECT FAST %------------------------------------
                elseif trials.switch{itrial_data}==2 && accu && rt<=task_diff 
                    Points = Points + 4;        % +4 points
                    task_diff=(mean_rt+rt)/2;   % Higher
                    Sound_Good(0,pahandle);% Good timing
                    
                % SWITCH CORRECT SLOW %------------------------------------
                elseif trials.switch{itrial_data}==2 && accu && rt>task_diff 
                    Points = Points + 4;            % +4 points
                    task_diff=(mean_rt+min(rt2))/2; % Higher
                    Sound_Bad(0,pahandle);      % Unvalided timing
                
                % SWITCH NOT CORRECT FAST %--------------------------------
                elseif trials.switch{itrial_data}==2 && ~accu && rt<=task_diff 
                    Points = Points;                % 0 point
                    task_diff=task_diff;            % Unchanged
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                
                % SWITCH NOT CORRECT SLOW %--------------------------------
                elseif trials.switch{itrial_data}==2 && ~accu && rt>task_diff 
                    Points = Points;                % 0 point
                    task_diff=task_diff;            % Unchanged
                    Sound_ToFast(0,pahandle);   % Unvalided timing or error
                end

                trials.score{itrial_data}=Points;
                
                
%%%%%%%%%%%%% 5. FEEDBACK
                if (0) % Feeback or not
                    DrawFormattedText(video.h, [num2str(round(rt*1000)) text{11}], video.x*0.48, video.y*0.5, 1); % En blanc
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    tonset_feedback = Screen('Flip',video.h);%DRAW FEEDBACK and play sound (can this be simultaneous ?)
                else
                    tonset_feedback = toffset;
                end
                timecode.feedback_onset{itrial_data} = tonset_feedback;

                if (0) % Feeback or not
                    DrawFormattedText(video.h, [num2str(round(rt*1000)) text{11}], video.x*0.48, video.y*0.5, 1); % En blanc
                    DrawFormattedText(video.h, [num2str(itrial_data) ' / ' num2str(ntrials)] ,0.9*video.x,0.1*video.y,0.1);
                    toffset_feedback = Screen('Flip',video.h,tonset_feedback+roundfp(timing2.feedbackduration,video.ifi));%next flip = end of pre-cue...
                else
                    toffset_feedback = toffset;
                end
                timecode.feedback_offset{itrial_data}  = toffset_feedback; 
                
             if stopped==true; break; end   
             end % for itrial=1:numtrial
             % END of LOOP 4 --- from 1 to numtrials NSW+SW
             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             
        Passation.Data.Response = response;
        Passation.Data.Timecode = timecode;
        Passation.Data.Trials = trials;

        if stopped==true; break; end
        end % for switch_seq=1:length(num_nsw_vl) %end of a switch-non-switch sequence
        % END of LOOP 3 --- from 1 to n_trials_within_volatility 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if ~stopped
            save([Passation.Filename '_Bloc_' num2str(blocidx)],'Passation');
            assignin('base','Passation', Passation);
            fprintf('Session data are saved in: %s\n', [Passation.Filename '_Bloc_' num2str(blocidx)]);
            trig.start=60; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
        end
        
    if stopped==true; break; end    
    end % for volatility_level=1:3 %end of all volatility levels (basically, this is the end of one blox of trial)
    % END of LOOP 2 --- from 1 to 3 (max volatility level)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Points_Exp(iSujet+1,blocidx) = Points;
    [Record,Index] = sortrows(Points_Exp,blocidx);
    DrawFormattedText(video.h, text{12}, 'center',video.y*0.1, 1);
    DrawFormattedText(video.h, [text{13} num2str(Points) text{14}] , 'center',video.y*0.15, 1);
    DrawFormattedText(video.h, text{15}, 'center',video.y*0.25, 1);
    DrawFormattedText(video.h, [text{16} '1     ' num2str(Points_Exp(iSujet+1,1)) text{17}] ,video.x*0.33,video.y*0.35, 0.8);
    DrawFormattedText(video.h, [text{16} '2     ' num2str(Points_Exp(iSujet+1,2)) text{17}] ,video.x*0.33,video.y*0.39, 0.8);
    DrawFormattedText(video.h, [text{16} '3     ' num2str(Points_Exp(iSujet+1,3)) text{17}] ,video.x*0.33,video.y*0.43, 0.8);
    DrawFormattedText(video.h, [text{16} '4     ' num2str(Points_Exp(iSujet+1,4)) text{17}] ,video.x*0.33,video.y*0.47, 0.8);
    DrawFormattedText(video.h, [text{16} '5     ' num2str(Points_Exp(iSujet+1,5)) text{17}] ,video.x*0.33,video.y*0.51, 0.8);
    DrawFormattedText(video.h, [text{16} '6     ' num2str(Points_Exp(iSujet+1,6)) text{17}] ,video.x*0.33,video.y*0.55, 0.8);
    %DrawFormattedText(video.h, [text{16} '7     ' num2str(Points_Exp(iSujet+1,7)) text{17}] ,video.x*0.33,video.y*0.59, 0.8);
    %DrawFormattedText(video.h, [text{16} '8     ' num2str(Points_Exp(iSujet+1,8)) text{17}] ,video.x*0.33,video.y*0.63, 0.8);
    
    DrawFormattedText(video.h, ['1     ' Name{Index(end)} '     ' num2str(Record(end,blocidx)) text{17}] ,video.x*0.53,video.y*0.31, 0.8);
    DrawFormattedText(video.h, ['2     ' Name{Index(end-1)} '     ' num2str(Record(end-1,blocidx)) text{17}] ,video.x*0.53,video.y*0.35, 0.8);
    DrawFormattedText(video.h, ['3     ' Name{Index(end-2)} '     ' num2str(Record(end-2,blocidx)) text{17}] ,video.x*0.53,video.y*0.39, 0.8);
    DrawFormattedText(video.h, ['4     ' Name{Index(end-3)} '     ' num2str(Record(end-3,blocidx)) text{17}] ,video.x*0.53,video.y*0.43, 0.8);
    DrawFormattedText(video.h, ['5     ' Name{Index(end-4)} '     ' num2str(Record(end-4,blocidx)) text{17}] ,video.x*0.53,video.y*0.47, 0.8);
    DrawFormattedText(video.h, ['6     ' Name{Index(end-5)} '     ' num2str(Record(end-5,blocidx)) text{17}] ,video.x*0.53,video.y*0.51, 0.8);
    DrawFormattedText(video.h, ['7     ' Name{Index(end-6)} '     ' num2str(Record(end-6,blocidx)) text{17}] ,video.x*0.53,video.y*0.55, 0.8);
    DrawFormattedText(video.h, ['8     ' Name{Index(end-7)} '     ' num2str(Record(end-7,blocidx)) text{17}] ,video.x*0.53,video.y*0.59, 0.8);
    DrawFormattedText(video.h, ['9     ' Name{Index(end-8)} '     ' num2str(Record(end-8,blocidx)) text{17}] ,video.x*0.53,video.y*0.63, 0.8);
    DrawFormattedText(video.h, ['10     ' Name{Index(end-9)} '     ' num2str(Record(end-9,blocidx)) text{17}] ,video.x*0.53,video.y*0.67, 0.8);

    if blocidx<num_bloc
        DrawFormattedText(video.h, [text{18} num2str(blocidx+1) text{19}], 'center',video.y*0.75, 1);
        DrawFormattedText(video.h, text{20}, 'center', video.y*0.9, [1 0 0]);
        Screen('Flip', video.h); key = WaitKeyPress([keyconfirm keystop]);
        if isequal(key,2)
            trig.start=59; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
            stopped=true; 
        end
    elseif blocidx==num_bloc
        DrawFormattedText(video.h, text{21}, video.y*0.8, 1);
        Screen('Flip', video.h); key = WaitKeyPress([keyconfirm]);
    end
    
if stopped==true; break; end    
end % for blocidx=1:num_bloc %%%%%%%%%%%%%%%%  %this is the end of all bloc 
%end % if experiement
% END of LOOP 1 --- from 1 to num_bloc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
if participant.flags.with_eyetracker && ~is_training
    fprintf('Stopping Eyetracker ...');
    Eyelink('StopRecording');
    fprintf('recording stopped.\n');
end
if participant.flags.with_response_lumina
    IOPort('Close',hport_lum); % Close response port
end   
if participant.flags.with_triggers
    IOPort('Close',hport_trig); % close trigger port % CloseParPort;
end

% Save
if stopped    
    sufx = '_Bloc_stopped';
    Passation.Filename=[Passation.Filename sufx];
    save([Passation.Filename],'Passation'); 
    fprintf('\n Session data are saved in: %s\n', Passation.Filename);
    trig.start=60; param.fun.trigger(trig.start, param.hport_trig); % START TRIGGERS
end

% Close video etc.
PsychPortAudio('Close', pahandle); % Close the audio device
IOPort('CloseAll');
Priority(0);
Screen('CloseAll');
FlushEvents;
ListenChar(0); 
ShowCursor;
video = [];

return

%%%%%%%%%%%%% THIS IS THE END %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
