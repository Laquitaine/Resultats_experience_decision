%==========================================================================
% Function : Sound_Bad
%==========================================================================
 
function Sound_ToFast(delay,pahandle)

myBeep8 = MakeBeep(400, 1/8, 48000); % Create a beep
PsychPortAudio('FillBuffer', pahandle, [myBeep8; myBeep8]); % Fill the audio playback buffer with the audio data
PsychPortAudio('Start', pahandle, 1, delay, 1); % Start audio playback
PsychPortAudio('Stop', pahandle, 1, 1);

myBeep9 = MakeBeep(380, 1/6, 48000); % Create a beep
PsychPortAudio('FillBuffer', pahandle, [myBeep9; myBeep9]); % Fill the audio playback buffer with the audio data
PsychPortAudio('Start', pahandle, 1, delay, 1); % Start audio playback
PsychPortAudio('Stop', pahandle, 1, 1);