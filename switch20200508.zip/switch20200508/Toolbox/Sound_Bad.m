%==========================================================================
% Function : Sound_Bad
%==========================================================================
 
function Sound_Bad(delay,pahandle)

myBeep7 = MakeBeep(400, 1/6, 48000); % Create a beep
PsychPortAudio('FillBuffer', pahandle, [myBeep7; myBeep7]); % Fill the audio playback buffer with the audio data
PsychPortAudio('Start', pahandle, 1, delay, 1); % Start audio playback
PsychPortAudio('Stop', pahandle, 1, 1);