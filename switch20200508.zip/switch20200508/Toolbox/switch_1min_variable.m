% INITIALISATION DES VARIABLES
%==========================================================================
N = 60;                             % Dur�e de l'�chantillon (60s)
Te = 0.017;                         % P�riode d'�chantillonnage = video.ifi
tt = [0:Te:N];                      % Vecteur temps
L = round(N/Te)-2;
% Fr�quences --------------------------------------------------------------
f_delta = 0.5;          % 0.5 - 4 Hz
f_theta = 5;            % 4 - 8 Hz
f_alpha = 10;            % 8 - 13 Hz
f_beta  = 30;           % 13 - 30 Hz
f_gamma = 60;           % 30 - 100 Hz
tt_pi = [0:Te:1/f_delta];                  % Vecteur temps sur pi
% Phases ------------------------------------------------------------------
phi_delta = pi/2;
phi_theta = 2*pi * rand(1,1);
phi_alpha = 2*pi * rand(1,1);
phi_beta  = 2*pi * rand(1,1);
phi_gamma = 2*pi * rand(1,1);
% Initialisation ----------------------------------------------------------
S_delta=[]; S_theta=[]; S_alpha=[]; S_beta=[]; S_gamma=[]; S_all=[];

for i=1:1:round(N*f_delta)
    
    % Amplitudes ----------------------------------------------------------
    A_delta = 200*(1 + 1*randn);    % 200 �V
    A_theta = 100*randn;            % 100 �V
    A_alpha = 50*rand;              % 50 �V
    A_beta  = 30*(1 + 0.5*randn);   % 30 �V
    A_gamma = 10*(1 + 0.5*randn);   % 10 �V
    % Signaux partiels ----------------------------------------------------
    s_delta = @(t) A_delta * cos(2*pi*f_delta*t + phi_delta);
    s_theta = @(t) A_theta * cos(2*pi*f_theta*t + phi_theta);
    s_alpha = @(t) A_alpha * cos(2*pi*f_alpha*t + phi_alpha);
    s_beta  = @(t) A_beta  * cos(2*pi*f_beta*t  + phi_beta) ;
    s_gamma = @(t) A_gamma * cos(2*pi*f_gamma*t + phi_gamma);
    s_all   = @(t) s_delta(t) + s_theta(t) + s_alpha(t) + s_beta(t) + s_gamma(t);
    % Signaux complets ----------------------------------------------------
    S_delta = [S_delta , s_delta(tt_pi).^2];
    S_theta = [S_theta , s_theta(tt_pi).^2];
    S_alpha = [S_alpha , s_alpha(tt_pi).^2];
    S_beta  = [S_beta  , s_beta(tt_pi).^2];
    S_gamma = [S_gamma , s_gamma(tt_pi).^2];
    S_all = [S_all , s_all(tt_pi).^2];
end

figure();
subplot(2,3,1);
    plot(tt(1:L), S_delta(1:L));
    title('Delta - 0.5Hz'); xlabel(['Time (s)']); ylabel('Power (�V�)'); 
    if ~ishold  
        hold on; grid on; grid minor;
    end    
subplot(2,3,2);
    plot(tt(1:L), S_theta(1:L));
    title('Theta - 5Hz'); xlabel(['Time (s)']); ylabel('Power (�V�)'); 
    if ~ishold  
        hold on; grid on; grid minor;
    end
subplot(2,3,3);
    plot(tt(1:L), S_alpha(1:L));
    title('Alpha - 10Hz'); xlabel(['Time (s)']); ylabel('Power (�V�)'); 
    if ~ishold  
        hold on; grid on; grid minor;
    end
subplot(2,3,4);
    plot(tt(1:L), S_beta(1:L));
    title('Beta - 30Hz'); xlabel(['Time (s)']); ylabel('Power (�V�)'); 
    if ~ishold  
        hold on; grid on; grid minor;
    end
subplot(2,3,5);
    plot(tt(1:L), S_gamma(1:L));
    title('Gamma - 60Hz'); xlabel(['Time (s)']); ylabel('Power (�V�)'); 
    if ~ishold  
        hold on; grid on; grid minor;
    end
subplot(2,3,6);
    plot(tt(1:L), S_all(1:L));
    title('Oscillations'); xlabel(['Time (s)']); ylabel('Power (�V�)'); 
    if ~ishold  
        hold on; grid on; grid minor;
    end

%PATHSTR_root = load('PATHSTR.mat');     % Load the directory path
%switchfolder = PATHSTR_root.PATHSTR    % Current code file path
%save(fullfile(switchfolder,'Data\S_all'),'S_all')

