%==========================================================================
% Function : SendTriggerWin2
%==========================================================================

function trig=SendTriggerWin2(trig,hport2) %serial port code
IOPort('Write', hport2, char(trig)); %% Added 16112017 --- 