%==========================================================================
% Function : draw_precue
%==========================================================================

function [trig_precue]=draw_precue(video,stim_rule_type,fix_dot_Xpos,fix_dot_Ypos,fix_dot_SizePix,fix_dot_Color,...
     pre_cue_colors,side,pre_cue_Xpos_stim,pre_cue_Xpos_tmp,pre_cue_Xpos_rule,rule,trig_fix)
 %2.1 DRAWING
    if stim_rule_type==1 %one central dot and two peripheral squares
        Screen('DrawDots', video.h, [fix_dot_Xpos fix_dot_Ypos], fix_dot_SizePix, fix_dot_Color, [], 2);
        Screen('FillRect', video.h, pre_cue_colors(:,:,side), pre_cue_Xpos_stim);
        trig_precue=trig_fix+side;
    elseif stim_rule_type==2 %one central square and two peripheral dots
        Screen('DrawDots', video.h, [pre_cue_Xpos_tmp ; fix_dot_Ypos fix_dot_Ypos], [fix_dot_SizePix fix_dot_SizePix], [fix_dot_Color'  fix_dot_Color'], [], 2);
        Screen('FillRect', video.h, pre_cue_colors(:,rule,1), pre_cue_Xpos_rule);
        trig_precue=trig_fix+rule;
    end
    Screen('DrawingFinished',video.h);