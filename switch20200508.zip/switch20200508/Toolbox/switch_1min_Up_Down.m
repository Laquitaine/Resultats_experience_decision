
function [Passation,errormsg] = switch_1min_Up_Down(participant)

% Initialisation
%==========================================================================
DEBUG=0; dt=0.05;
Passation=[];                               % Define Passation
errormsg =[];                               % Define errormsg
Passation.Running = dbstack;                % File information (file:Name.m ; name:Name ; line:999)
for i=1:length(Passation.Running)
    Passation.Running(i).fullpath = which(Passation.Running(i).file); % File location (C:\Users\Name\Documents\File.m)
    Passation.Running(i).filedate = getfield(dir(Passation.Running(i).fullpath),'date'); % Saving date (16-oct.-2018 15:07:49)
    Passation.Running(i).mcode    = ...     % Copy all the actual script
        textread(Passation.Running(i).fullpath,'%s','delimiter','\n');           
end
run('switch_TaskParameters');               % Define various parameters
Passation.TaskParameters = ...              % Copy all the TaskParameter script
    textread(which('switch_TaskParameters'),'%s','delimiter','\n');
Passation.Participant = participant;
Passation.DataFolder = fullfile(participant.folder,'Data',participant.identifier);
if not(exist(Passation.DataFolder, 'dir'))  % Saving data folder exist or not
    if DEBUG
        Passation.DataFolder = fullfile(fileparts(tempname)); % DEBUG => Save in temporary folder
    else
        error('switch:MssingDataFolder','Missing data folder! %s\n', Passation.DataFolder);
    end
end
Passation.Filename=fullfile(...             % Define the filename to save the info
    Passation.DataFolder,sprintf('switch_%s_%s',... % like 
    datestr(now,'yyyymmdd-HHMM'),...        % Datafolder\switch_20181017-1038_lfp
    participant.session));
diary(Passation.Filename)                   % save diary (in ...\switch\data\TEST\switch_20181017-1038_lfp)
%--------------------------------------------------------------------------
if participant.flags.with_fullscreen        % Initialisation of Psychtoolbox
    video = OpenPTBScreen([]);              % Screen Definition
else
    video = OpenPTBScreen;
end
%--------------------------------------------------------------------------
% Initialisation of I/O ports
%==========================================================================
IOPort('CloseAll'); % Close all input/output (USB, serial, parallel..etc)

% LUMINA buttons
if participant.flags.with_response_lumina           % Open port to be used with LUMINA buttons
    if IsWin                                        % NB : Baud rate is set to 115200
        [hport] = IOPort('OpenSerialPort','COM10'); % Mode should be 'ASCII/MEDx' on the LSC-400B Controller
    elseif IsLinux
        hport = IOPort('OpenSerialPort','/dev/ttyS0');
    end
    IOPort('ConfigureSerialPort',hport,'BaudRate=115200');
    IOPort('Purge',hport);
else
    hport = [];
end

% With triggers
if participant.flags.with_triggers  % Open trigger port & define sendtrigger
    if ispc && participant.flags.serial_triggers==0
        %PARRALLEL PORT CASE: to be coded !!!
        CloseParPort;
        OpenParPort;
        hp2=[];
        trigger = @(trig,hp2) SendTriggerWin(trig,hp2);
        %SERIAL PORT CASE:
    elseif ispc && participant.flags.serial_triggers==1
        [hp2] = IOPort('OpenSerialPort','COM8');  % COMxx is the name of the port in window setup panel  
        IOPort('ConfigureSerialPort',hp2,'BaudRate=9600'); % adjust according to windows setup panel value
        IOPort('Purge',hp2);
        trigger = @(trig,hp2) SendTriggerWin2(trig,hp2);
    elseif IsLinux
        trigger = @(trig) SendTriggerLinux(trig);
    end 
else 
    trigger = @(x)[]; % Do nothing on trigger() function calls
end

 if ~DEBUG         % Remove keyboard outputs to matlab screen: REMOVED BY JB TO DEBUG...
    HideCursor;    % Hide the mouse cursor
    FlushEvents;   % Remove events from the system even queue
    ListenChar(2); % 2 = listen to keyboard input and supress any output of keypresses
 end
 
% Display and wait for keyboard input
DrawFormattedText(video.h, 'DEBUT DU TEST', 'center', video.y*0.4, 1); 
DrawFormattedText(video.h, 'Appuyez sur ENTREE pour continuer', 'center', video.y*0.9, 0.5); 
VBLTimestamp = Screen('Flip', video.h); WaitKeyPress(keyconfirm);

% Load 1min of created signal
signal = load('S_all.mat');
Signal = signal.S_all/max(signal.S_all);
dotSizePix = 5;
dotColor = [ 1 1 1];
VBLTimestamp = Screen('Flip', video.h);
for var_idx=1:1:1e3
    %DrawFormattedText(video.h, [ num2str(Signal(var_idx))] ,video.x*(var_idx)*0.1,'center', 1);
    dotXpos = video.x*(var_idx)/1e3;
    dotYpos = video.y*(1-Signal(var_idx));
    Screen('DrawDots', video.h, [dotXpos dotYpos], dotSizePix, dotColor, [], 2);
    VBLTimestamp = Screen('Flip', video.h, VBLTimestamp+roundfp(video.ifi,video.ifi),1);  
end
VBLTimestamp = Screen('Flip', video.h, VBLTimestamp+roundfp(5,video.ifi)); 




 
save(Passation.Filename,'Passation');
sca;
Priority(0);
Screen('CloseAll');
FlushEvents;
ListenChar(0);
ShowCursor;
video = [];
return

