How does it work...

1 - Launch the START.m file (a graphical interface should open)
2 - Select the LANGUAGE you prefer and then fill in the NAME and AGE (the rest is not obligatory)
3 - Click on DATA VALIDATION
4 - Select the session (+start) = start the experiment itself (contains 15' of training and 6 blocs of 8min for the experiment)
    
Notes : 
The keyboard keys to answer are [a,s,l,p].
During the experiment, there will be various breaks. 
In any case, it is possible to leave the psychtoolbox by maintaining SPACE 1-2 second after any trial.
Synchronization problems could occur. Ignore them and repeat the process.