%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% START.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%========================================================================== 
% Initialize matlab before running the experiment
%==========================================================================

% Setup the workspace -----------------------------------------------------
clc;                                        % Clear the command window
sca;                                        % Close all screens, windows, textures, movies and videos 
clear classes; % = import, global, all      % Clear all variables, globals, functions, MEX links, global variables
clear java;                                 % Clear java classes on the dynamic java path
close all;                                  % Close all open figure windows
Screen('CloseAll');                         % Close all open onscreen and offscreen
profile on;                                 % Profile execution time (see profile viewer and save)
Priority(2);                                % 2 is "real time priority level"
set(0,'defaultfigurewindowstyle','docked'); % Resizes the figures

% Add paths to the Matlab search directory --------------------------------
PATHSTR = fileparts(mfilename('fullpath')); % Current code file path C:\Users\...\switch2019514
cd(PATHSTR);                                % Change current folder
addpath(PATHSTR);                           % Give access to all the  
addpath(fullfile(PATHSTR,'Toolbox'));       % file.m of these folders
addpath(fullfile(PATHSTR,'Data'));
save(fullfile(PATHSTR,'Data\PATHSTR'),'PATHSTR'); % Save the current code file path C:\Users\...\switch2019514
diary(fullfile(PATHSTR,'Data\diary'));      % Save text of Matlab session in the Data folder 


% Experiment --------------------------------------------------------------
try
    switch_GUI;                             % Open the Graphic User Interface
    %errormsg ='>> Function executed without error'; % Error message initialisation
    %disp(errormsg);                             % Display error message
    
catch ME                                    % Execution ONLY f an error occurs in "try" section
    Priority(0);                            % 0 is "normal priority level"
    Screen('CloseAll');                     % Close screens, windows, textures, videos
    FlushEvents;                            % Remove events from the system event queue
    ListenChar(0);                          % 0 = stop listening to keyboard input
    ShowCursor;                             % re-displays the mouse after a "HideCursor"
    disp(ME);                               % Display command
    rethrow(ME);                            % Reissue error
    return;                                 % Force an early return to the invoking function
end

diary off;                                  % Save text of Matlab session
profile off;                                % Profile execution time (see profile viewer and save)
return;
